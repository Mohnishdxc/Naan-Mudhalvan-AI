a="""
hi, how are you doing?	i'm fine. how about yourself?
i'm fine. how about yourself?	i'm pretty good. thanks for asking.
i'm pretty good. thanks for asking.	no problem. so how have you been?
no problem. so how have you been?	i've been great. what about you?
i've been great. what about you?	i've been good. i'm in school right now.
i've been good. i'm in school right now.	what school do you go to?
what school do you go to?	i go to pcc.
i go to pcc.	do you like it there?
do you like it there?	it's okay. it's a really big campus.
it's okay. it's a really big campus.	good luck with school.
good luck with school.	thank you very much.
how's it going?	i'm doing well. how about you?
i'm doing well. how about you?	never better, thanks.
never better, thanks.	so how have you been lately?
so how have you been lately?	i've actually been pretty good. you?
i've actually been pretty good. you?	i'm actually in school right now.
i'm actually in school right now.	which school do you attend?
which school do you attend?	i'm attending pcc right now.
i'm attending pcc right now.	are you enjoying it there?
are you enjoying it there?	it's not bad. there are a lot of people there.
it's not bad. there are a lot of people there.	good luck with that.
good luck with that.	thanks.
how are you doing today?	i'm doing great. what about you?
i'm doing great. what about you?	i'm absolutely lovely, thank you.
i'm absolutely lovely, thank you.	everything's been good with you?
everything's been good with you?	i haven't been better. how about yourself?
i haven't been better. how about yourself?	i started school recently.
i started school recently.	where are you going to school?
where are you going to school?	i'm going to pcc.
i'm going to pcc.	how do you like it so far?
how do you like it so far?	i like it so far. my classes are pretty good right now.
i like it so far. my classes are pretty good right now.	i wish you luck.
it's an ugly day today.	i know. i think it may rain.
i know. i think it may rain.	it's the middle of summer, it shouldn't rain today.
it's the middle of summer, it shouldn't rain today.	that would be weird.
that would be weird.	yeah, especially since it's ninety degrees outside.
yeah, especially since it's ninety degrees outside.	i know, it would be horrible if it rained and it was hot outside.
i know, it would be horrible if it rained and it was hot outside.	yes, it would be. 
yes, it would be. 	i really wish it wasn't so hot every day. 
i really wish it wasn't so hot every day. 	me too. i can't wait until winter.
me too. i can't wait until winter.	i like winter too, but sometimes it gets too cold.
i like winter too, but sometimes it gets too cold.	i'd rather be cold than hot.
i'd rather be cold than hot.	me too.
it doesn't look very nice outside today.	you're right. i think it's going to rain later.
you're right. i think it's going to rain later.	in the middle of the summer, it shouldn't be raining.
in the middle of the summer, it shouldn't be raining.	that wouldn't seem right.
that wouldn't seem right.	considering that it's over ninety degrees outside, that would be weird.
considering that it's over ninety degrees outside, that would be weird.	exactly, it wouldn't be nice if it started raining. it's too hot.
exactly, it wouldn't be nice if it started raining. it's too hot.	i know, you're absolutely right.
i know, you're absolutely right.	i wish it would cool off one day.
i wish it would cool off one day.	that's how i feel, i want winter to come soon.
that's how i feel, i want winter to come soon.	i enjoy the winter, but it gets really cold sometimes.
i enjoy the winter, but it gets really cold sometimes.	i know what you mean, but i'd rather be cold than hot.
i know what you mean, but i'd rather be cold than hot.	that's exactly how i feel.
i wish it was a nicer day today.	that is true. i hope it doesn't rain.
that is true. i hope it doesn't rain.	it wouldn't rain in the middle of the summer.
it wouldn't rain in the middle of the summer.	it wouldn't seem right if it started raining right now.
it wouldn't seem right if it started raining right now.	it would be weird if it started raining in ninety degree weather.
it would be weird if it started raining in ninety degree weather.	any rain right now would be pointless.
any rain right now would be pointless.	that's right, it really would be.
that's right, it really would be.	i want it to cool down some.
i want it to cool down some.	i know what you mean, i can't wait until it's winter.
i know what you mean, i can't wait until it's winter.	winter is great. i wish it didn't get so cold sometimes though.
winter is great. i wish it didn't get so cold sometimes though.	i would rather deal with the winter than the summer.
it's such a nice day.	yes, it is.
yes, it is.	it looks like it may rain soon.
it looks like it may rain soon.	yes, and i hope that it does.
yes, and i hope that it does.	why is that?
why is that?	i really love how rain clears the air.
i really love how rain clears the air.	me too. it always smells so fresh after it rains.
me too. it always smells so fresh after it rains.	yes, but i love the night air after it rains.
yes, but i love the night air after it rains.	really? why is it?
really? why is it?	because you can see the stars perfectly.
because you can see the stars perfectly.	i really hope it rains today.
i really hope it rains today.	yeah, me too.
isn't it a nice day?	it really is.
it really is.	it seems that it may rain today.
it seems that it may rain today.	hopefully it will.
hopefully it will.	how come?
how come?	i like how clear the sky gets after it rains.
i like how clear the sky gets after it rains.	i feel the same way. it smells so good after it rains.
i feel the same way. it smells so good after it rains.	i especially love the night air when it rains.
i especially love the night air when it rains.	really? why?
really? why?	the stars look so much closer after it rains.
the stars look so much closer after it rains.	i really want it to rain today.
i really want it to rain today.	yeah, so do i.
don't you think it's nice out?	yes, i think so too.
yes, i think so too.	i think that it's going to rain.
i think that it's going to rain.	i hope that it does rain.
i hope that it does rain.	you like the rain?
you like the rain?	the sky looks so clean after it rains. i love it.
the sky looks so clean after it rains. i love it.	i understand. rain does make it smell cleaner.
i understand. rain does make it smell cleaner.	i love most how it is at night after it rains.
i love most how it is at night after it rains.	how come?
how come?	you can see the stars so much more clearly after it rains.
you can see the stars so much more clearly after it rains.	i would love for it to rain today.
i really want to go to the beach this weekend.	that sounds like fun. what's the weather going to be like?
that sounds like fun. what's the weather going to be like?	i heard that it's going to be warm this weekend.
i heard that it's going to be warm this weekend.	is it going to be perfect beach weather?
is it going to be perfect beach weather?	i believe so.
i believe so.	good. i hope it doesn't cool off this weekend.
good. i hope it doesn't cool off this weekend.	i know. i really want to go to the beach.
i know. i really want to go to the beach.	but you know that california weather is really unpredictable.
but you know that california weather is really unpredictable.	you're right. one minute it's hot, and then the next minute it's cold.
you're right. one minute it's hot, and then the next minute it's cold.	i really wish the weather would just stay the same.
i really wish the weather would just stay the same.	i do too. that way we can have our activities planned ahead of time.
i do too. that way we can have our activities planned ahead of time.	yeah, that would make things a lot easier.
i would like to take a trip to the beach this weekend.	a trip to the beach would be fun. how is the weather going to be?
a trip to the beach would be fun. how is the weather going to be?	the forecast says that it will be warm on the weekend.
the forecast says that it will be warm on the weekend.	so do you think it'll be perfect weather for the beach?
so do you think it'll be perfect weather for the beach?	it sounds like it will be.
it sounds like it will be.	i really hope it doesn't get cold.
i really hope it doesn't get cold.	that would ruin things, i want to go so badly.
that would ruin things, i want to go so badly.	the weather in california is unpredictable, so you never know.
the weather in california is unpredictable, so you never know.	that is true. the weather is constantly changing.
that is true. the weather is constantly changing.	it would be nice if the weather would never change.
it would be nice if the weather would never change.	that would be great, then we could plan things sooner.
that would be great, then we could plan things sooner.	true. predictable weather would make life easier.
it would be nice to go to the beach sometime this weekend.	what's the weather going to be like? i may want to go too.
what's the weather going to be like? i may want to go too.	the weather this weekend is supposed to be warm.
the weather this weekend is supposed to be warm.	will it be good beach weather?
will it be good beach weather?	i think it will be.
i think it will be.	it wouldn't be good if it got cold this weekend.
it wouldn't be good if it got cold this weekend.	i want this trip to be perfect, i hope it stays warm.
i want this trip to be perfect, i hope it stays warm.	this california weather is so uncertain, it's impossible to know what'll happen.
this california weather is so uncertain, it's impossible to know what'll happen.	i know. every day the weather seems different.
i know. every day the weather seems different.	i would love it if it wasn't always so unpredictable.
i would love it if it wasn't always so unpredictable.	that would make it easier for us to make plans.
hello, may i speak to alice please?	this is she. how's it going?
this is she. how's it going?	i've been trying to call you all day.
i've been trying to call you all day.	sorry about that. i was cleaning up.
sorry about that. i was cleaning up.	it's okay.
it's okay.	so what were you calling me about?
so what were you calling me about?	oh, i just wanted to see if you wanted to hang out tomorrow.
oh, i just wanted to see if you wanted to hang out tomorrow.	sure, what did you want to do?
sure, what did you want to do?	maybe we can go see a movie or something.
maybe we can go see a movie or something.	that sounds like fun. let's do it.
that sounds like fun. let's do it.	i'll see you tomorrow then.
i'll see you tomorrow then.	see you then. goodbye.
hi, how are you. is alice there?	speaking. what's up?
speaking. what's up?	why haven't you answered the phone?
why haven't you answered the phone?	my bad, i had chores to do.
my bad, i had chores to do.	that's all right.
that's all right.	what was the reason for your call?
what was the reason for your call?	i want to do something tomorrow with you.
i want to do something tomorrow with you.	sounds good. what did you have in mind?
sounds good. what did you have in mind?	i was thinking about seeing a movie.
i was thinking about seeing a movie.	okay, let's go see a movie.
okay, let's go see a movie.	until then.
until then.	talk to you later.
is alice available?	you're talking to her.
you're talking to her.	i've called you a hundred times today.
i've called you a hundred times today.	i was busy doing something. i apologize.
i was busy doing something. i apologize.	no problem.
no problem.	did you need something?
did you need something?	do you want to do something tomorrow?
do you want to do something tomorrow?	is there somewhere special you wanted to go?
is there somewhere special you wanted to go?	how about a movie?
how about a movie?	a movie sounds good.
a movie sounds good.	call me tomorrow then.
have you seen the new girl in school?	no, i haven't.
no, i haven't.	she's really pretty.
she's really pretty.	describe her to me.
describe her to me.	she's not too tall.
she's not too tall.	well, how tall is she?
well, how tall is she?	she's about five feet even.
she's about five feet even.	what does she look like, though?
what does she look like, though?	she has pretty light brown eyes.
she has pretty light brown eyes.	i may know which girl you're talking about.
i may know which girl you're talking about.	so you have seen her around?
so you have seen her around?	yes, i have.
there's a new girl in school, have you seen her yet?	i haven't seen her yet.
i haven't seen her yet.	i think that she is very pretty.
i think that she is very pretty.	tell me how she looks.
tell me how she looks.	she's kind of short.
she's kind of short.	what height is she?
what height is she?	she's probably about five feet.
she's probably about five feet.	that's nice, but tell me what she looks like.
that's nice, but tell me what she looks like.	the first thing i noticed was her beautiful brown eyes.
the first thing i noticed was her beautiful brown eyes.	i think i might've bumped into her before.
i think i might've bumped into her before.	are you telling me that you've seen her before?
are you telling me that you've seen her before?	i believe so.
have you met the new girl?	no. have you?
no. have you?	she's one of the prettiest girls at the school.
she's one of the prettiest girls at the school.	what does she look like?
what does she look like?	well, she's quite short.
well, she's quite short.	how tall would you say that she is?
how tall would you say that she is?	i would say she's only five feet.
i would say she's only five feet.	what about her facial features?
what about her facial features?	she has light brown eyes, absolutely beautiful.
she has light brown eyes, absolutely beautiful.	i think i know who you're talking about.
i think i know who you're talking about.	have you seen her?
why weren't you at school yesterday?	i wasn't really feeling well.
i wasn't really feeling well.	what was wrong with you?
what was wrong with you?	my stomach was upset.
my stomach was upset.	do you feel better now?
do you feel better now?	i don't really feel too well yet.
i don't really feel too well yet.	do you want anything to make you feel better?
do you want anything to make you feel better?	no, thanks. i already took some medicine.
no, thanks. i already took some medicine.	i hope you feel better.
i hope you feel better.	thank you.
what reason do you have for missing school?	i was sick.
i was sick.	how were you sick?
how were you sick?	i had a stomachache.
i had a stomachache.	did it get any better?
did it get any better?	i'm still feeling under the weather.
i'm still feeling under the weather.	would you like anything for your stomach?
would you like anything for your stomach?	i took something earlier.
i took something earlier.	get better.
get better.	thanks a lot.
why didn't you go to school yesterday?	i stayed home because i wasn't feeling well.
i stayed home because i wasn't feeling well.	what was your problem?
what was your problem?	my stomach was bothering me.
my stomach was bothering me.	are you feeling any better?
are you feeling any better?	i'm still feeling a little sick.
i'm still feeling a little sick.	i'm going to the store, would you like any pepto bismol?
i'm going to the store, would you like any pepto bismol?	that's okay.
that's okay.	i hope you feel better.
did you hear the good news?	no, i haven't.
no, i haven't.	i got a promotion at my job.
i got a promotion at my job.	did you really?
did you really?	seriously, i am so excited.
seriously, i am so excited.	well, congratulations.
well, congratulations.	thank you.
thank you.	i'm so happy for you.
i'm so happy for you.	really?
really?	yes. you really deserved this.
yes. you really deserved this.	you think so?
you think so?	yes. good for you.
have you heard my good news?	you haven't told me anything yet.
you haven't told me anything yet.	i got a promotion at work earlier this week.
i got a promotion at work earlier this week.	is that right?
is that right?	it's the truth. i am really happy.
it's the truth. i am really happy.	congratulations on your promotion.
congratulations on your promotion.	thank you very much.
thank you very much.	i am really excited for you.
i am really excited for you.	are you really?
are you really?	i'm serious. you deserved this promotion.
i'm serious. you deserved this promotion.	is that what you really think?
is that what you really think?	yes, i do.
i haven't told you what happened yet, have i?	i haven't heard anything.
i haven't heard anything.	my boss offered me a promotion, and i took it.
my boss offered me a promotion, and i took it.	are you serious?
are you serious?	yes, i am really excited.
yes, i am really excited.	that's great. congratulations.
that's great. congratulations.	i appreciate that.
i appreciate that.	you have no idea how happy i am for you.
you have no idea how happy i am for you.	for real?
you look really nice today. 	thank you. i just got this outfit the other day.
thank you. i just got this outfit the other day.	really, where did you get it?
really, where did you get it?	i got it from macy's.
i got it from macy's.	it's really nice.
it's really nice.	thanks again. you look nice today, too.
thanks again. you look nice today, too.	thank you. i just got these shoes today.
thank you. i just got these shoes today.	really? what kind of shoes are they?
really? what kind of shoes are they?	these are called all star chuck taylors.
these are called all star chuck taylors.	i really like those. how much did they cost?
i really like those. how much did they cost?	they were about forty dollars.
they were about forty dollars.	i think i'm going to go buy myself a pair.
i absolutely love what you're wearing today.	you do? i just bought this outfit a couple days ago.
you do? i just bought this outfit a couple days ago.	seriously, it looks really nice on you. where did you buy it from?
seriously, it looks really nice on you. where did you buy it from?	i bought it from the macy's at the santa anita mall.
i bought it from the macy's at the santa anita mall.	i really like that outfit.
i really like that outfit.	thanks. i think you look nice today, too.
thanks. i think you look nice today, too.	thank you. i just bought these new shoes earlier today.
thank you. i just bought these new shoes earlier today.	those are nice. what are they?
those are nice. what are they?	these are some chucks.
these are some chucks.	those are great. how much were they?
those are great. how much were they?	i got them for forty.
i got them for forty.	i think i might go and find me my own pair of chucks.
i think that you look very cute today.	is that right? this is a brand new outfit.
is that right? this is a brand new outfit.	what store did you get it from?
what store did you get it from?	i went to macy's and picked it out.
i went to macy's and picked it out.	i love your outfit right now.
i love your outfit right now.	well, i think you look nice today too.
well, i think you look nice today too.	thanks. i found these new shoes earlier at the store.
thanks. i found these new shoes earlier at the store.	i think that those are some really nice shoes. what kind are they?
i think that those are some really nice shoes. what kind are they?	these are chucks.
these are chucks.	your shoes look really nice. how much did you get them for?
your shoes look really nice. how much did you get them for?	they only cost me about forty dollars.
tell me, what do you enjoy doing in your spare time?	i enjoy drawing and painting.
i enjoy drawing and painting.	you know how to draw and paint?
you know how to draw and paint?	yes, i do.
yes, i do.	when did you learn how to do that?
when did you learn how to do that?	i learned back in high school.
i learned back in high school.	oh, so you took an art class?
oh, so you took an art class?	yeah, i loved that class.
yeah, i loved that class.	i see that you're pretty talented.
i see that you're pretty talented.	thank you very much.
thank you very much.	i wish i had a talent like that.
i wish i had a talent like that.	i'm sure you have a talent. it's just hidden.
what kinds of things do you like to do?	i've always liked to draw and paint.
i've always liked to draw and paint.	i didn't know you knew how to draw and paint.
i didn't know you knew how to draw and paint.	i do it every once in a while.
i do it every once in a while.	how long have you known how to do that?
how long have you known how to do that?	i first learned how to do it in high school.
i first learned how to do it in high school.	did you take some sort of art class or something?
did you take some sort of art class or something?	that was my favorite class.
that was my favorite class.	you have got to be talented.
you have got to be talented.	thanks.
thanks.	if only i was talented.
if only i was talented.	you have a talent. you just don't know what it is yet.
are there any hobbies you do?	when i have time, i sometimes draw and paint.
when i have time, i sometimes draw and paint.	oh, you actually do that?
oh, you actually do that?	every so often, i do.
every so often, i do.	did you always know how to draw and paint?
did you always know how to draw and paint?	i was taught in high school how to draw and paint.
i was taught in high school how to draw and paint.	you had an art class?
you had an art class?	exactly, it was my favorite class.
exactly, it was my favorite class.	well, it's good that you're so talented.
well, it's good that you're so talented.	i appreciate that.
i appreciate that.	talent is a great thing, i wish i had one.
what's your favorite movie?	my favorite movie is superbad.
my favorite movie is superbad.	oh, why is that?
oh, why is that?	it's the funniest movie that i've ever seen.
it's the funniest movie that i've ever seen.	that's true. it is a very funny movie.
that's true. it is a very funny movie.	you've seen it before? 
you've seen it before? 	yes, i saw that movie the first day it came out in theaters.
yes, i saw that movie the first day it came out in theaters.	didn't you laugh through the whole movie? i did.
didn't you laugh through the whole movie? i did.	me too. that movie brought tears to my eyes.
me too. that movie brought tears to my eyes.	mine too.
mine too.	i have it on dvd at my house if you want to come over and watch it.
i have it on dvd at my house if you want to come over and watch it.	sure, let's go.
which movie is your favorite to watch?	i have to say, my favorite movie is superbad.
i have to say, my favorite movie is superbad.	is that right? why?
is that right? why?	honestly, it is one of the funniest movies i've seen in a long time.
honestly, it is one of the funniest movies i've seen in a long time.	you're right. that movie is hilarious.
you're right. that movie is hilarious.	i didn't think you saw that movie.
i didn't think you saw that movie.	i went to see it the day it came out.
i went to see it the day it came out.	i was laughing through the whole movie.
i was laughing through the whole movie.	i couldn't help laughing, either. 
i couldn't help laughing, either. 	same here.
same here.	i bought the movie. would you like to come to my house and watch it?
i bought the movie. would you like to come to my house and watch it?	of course.
out of every movie that you've seen, which one is your favorite?	i'm going to have to say that superbad is the best movie ever.
i'm going to have to say that superbad is the best movie ever.	you think so, how come?
you think so, how come?	well, superbad is super funny.
well, superbad is super funny.	you're not lying, i found that movie absolutely hilarious.
you're not lying, i found that movie absolutely hilarious.	i didn't know that you saw superbad before.
i didn't know that you saw superbad before.	i made sure to be in line to see it the first day it came out.
i made sure to be in line to see it the first day it came out.	i couldn't keep from laughing throughout the whole movie.
i couldn't keep from laughing throughout the whole movie.	i was laughing hysterically the whole time; my stomach muscles hurt afterwards.
i was laughing hysterically the whole time; my stomach muscles hurt afterwards.	that's exactly how i felt.
that's exactly how i felt.	i got the movie when it came out on dvd, do you want to come over?
what type of music do you like to listen to?	i like listening to different kinds of music.
i like listening to different kinds of music.	like what, for instance?
like what, for instance?	i enjoy rock and r&b.
i enjoy rock and r&b.	why is that?
why is that?	i like the different instruments that they use.
i like the different instruments that they use.	that's a good reason to like something.
that's a good reason to like something.	yeah, i think so too.
what kind of music do you enjoy listening to?	i enjoy listening to all kinds of music.
i enjoy listening to all kinds of music.	what kind?
what kind?	i like to listen to rock and r&b.
i like to listen to rock and r&b.	why do you like that type of music?
why do you like that type of music?	i like the kinds of instruments that they use.
i like the kinds of instruments that they use.	i think that's an excellent reason to like something.
i think that's an excellent reason to like something.	thanks, i feel the same way.
what is your favorite kind of music?	i listen to various types of music.
i listen to various types of music.	what genres?
what genres?	i enjoy listening to both rock and r&b.
i enjoy listening to both rock and r&b.	what interests you in that type of music?
what interests you in that type of music?	i enjoy the different types of instruments that they use.
i enjoy the different types of instruments that they use.	that is a perfect reason to like a certain kind of music.
did you go to the basketball game on friday?	no, i couldn't make it.
no, i couldn't make it.	you missed a really good game.
you missed a really good game.	oh, really? who won?
oh, really? who won?	our school did. they played really well.
our school did. they played really well.	too bad i was busy. i really wanted to go.
too bad i was busy. i really wanted to go.	yeah, you should have. it was really exciting.
yeah, you should have. it was really exciting.	so what was the score?
so what was the score?	the score was 101-98.
the score was 101-98.	man, that was a really close game.
man, that was a really close game.	that's what made it so great.
that's what made it so great.	i'll make sure and make it to the next one.
were you able to attend friday night's basketball game?	i was unable to make it.
i was unable to make it.	you should have been there. it was intense.
you should have been there. it was intense.	is that right. who ended up winning?
is that right. who ended up winning?	our team was victorious.
our team was victorious.	i wish i was free that night. i'm kind of mad that i didn't go.
i wish i was free that night. i'm kind of mad that i didn't go.	it was a great game.
it was a great game.	what was the score at the end of the game?
what was the score at the end of the game?	our team won 101-98.
our team won 101-98.	sounds like it was a close game.
sounds like it was a close game.	that's the reason it was such a great game.
that's the reason it was such a great game.	the next game, i will definitely be there.
i was meaning to ask you if you saw the basketball game on friday.	i wanted to go, but i couldn't.
i wanted to go, but i couldn't.	it was a great game.
it was a great game.	it's too bad that i couldn't make it. who won?
it's too bad that i couldn't make it. who won?	our team played hard and won.
our team played hard and won.	i really wish i went to the game.
i really wish i went to the game.	it was the best game ever.
it was the best game ever.	so tell me the final score.
so tell me the final score.	the other team lost by three points, 101-98. 
the other team lost by three points, 101-98. 	it must've been a close game.
it must've been a close game.	it really was. you should've gone.
what are you doing this weekend?	i'm going to the movies with a friend. how about you?
i'm going to the movies with a friend. how about you?	i'm not sure yet.
i'm not sure yet.	well, did you want to go see a movie with me?
well, did you want to go see a movie with me?	what movie are you going to see?
what movie are you going to see?	i'm not sure yet. is there something you want to see?
i'm not sure yet. is there something you want to see?	there's nothing i can think of.
there's nothing i can think of.	so, did you want to go?
so, did you want to go?	no, thanks, maybe another time.
no, thanks, maybe another time.	okay, sounds good.
do you know what you're going to do this weekend?	i am going to see a movie with a friend of mine. what about you?
i am going to see a movie with a friend of mine. what about you?	i don't know.
i don't know.	would you like to see a movie with me and my friend?
would you like to see a movie with me and my friend?	do you know what movie you're going to watch?
do you know what movie you're going to watch?	i don't know, but was there a certain movie you wanted to see?
i don't know, but was there a certain movie you wanted to see?	none that i can think of.
none that i can think of.	well, would you like to go?
well, would you like to go?	thank you for inviting me, but i think i'll pass.
thank you for inviting me, but i think i'll pass.	all right. another time then.
you have any ideas as to what you want to do this weekend?	i'm going to the movie theater with my friend. what are you going to do?
i'm going to the movie theater with my friend. what are you going to do?	i'm not quite sure yet.
i'm not quite sure yet.	how about you see a movie with me and my friend?
how about you see a movie with me and my friend?	what movie are you and your friend planning on watching?
what movie are you and your friend planning on watching?	not sure. is there a movie out that catches your eye?
not sure. is there a movie out that catches your eye?	no good movies come to mind.
no good movies come to mind.	have you decided whether or not you would like to go?
have you decided whether or not you would like to go?	no, thanks. maybe another time.
did you go to school today?	yeah, i went to school today. were you there?
yeah, i went to school today. were you there?	no, i didn't go, i've been sick.
no, i didn't go, i've been sick.	that sucks. did you want the assignments from english class?
that sucks. did you want the assignments from english class?	that would be nice, thank you.
that would be nice, thank you.	no problem, you're welcome.
no problem, you're welcome.	i will be glad to do the same for you when you're sick.
i will be glad to do the same for you when you're sick.	well, thank you. i hope to see you at school tomorrow.
have you attended school today?	i attended school today. did you?
i attended school today. did you?	i wasn't able to attend school because i was feeling ill.
i wasn't able to attend school because i was feeling ill.	i'm sorry to hear that. would you like the assignments from english class?
i'm sorry to hear that. would you like the assignments from english class?	i would really appreciate that, thanks.
i would really appreciate that, thanks.	it's no trouble at all.
it's no trouble at all.	if you get sick, i'll return the favor.
if you get sick, i'll return the favor.	thanks. see you at school tomorrow if you feel better.
have you gone to school today?	i went to school today. did you go to school?
i went to school today. did you go to school?	i couldn't go to school today, i was sick.
i couldn't go to school today, i was sick.	that's horrible. i'd be happy to give you the assignments from english class.
that's horrible. i'd be happy to give you the assignments from english class.	thank you very much, that's kind of you.
thank you very much, that's kind of you.	don't mention it.
don't mention it.	when you miss a day of school, i'll be happy to give you the english assignments.
did you hear the news?	what happened?
what happened?	our cousin went into labor and had her baby last week.
our cousin went into labor and had her baby last week.	she did? why didn't anyone tell me?
she did? why didn't anyone tell me?	i would've thought that somebody would have told you.
i would've thought that somebody would have told you.	no, i had no idea.
no, i had no idea.	well, she did, her baby was 8 pounds 6 ounces.
well, she did, her baby was 8 pounds 6 ounces.	oh my god, that's great!
oh my god, that's great!	are you going to go and visit her and the baby?
are you going to go and visit her and the baby?	i think that i might.
i think that i might.	good! i just thought i'd let you know.
good! i just thought i'd let you know.	thanks for telling me.
have you heard what happened?	heard what?
heard what?	debrah already had her baby.
debrah already had her baby.	i didn't know that.
i didn't know that.	i thought you knew.
i thought you knew.	i honestly didn't know.
i honestly didn't know.	the baby was 8 pounds 6 ounces.
the baby was 8 pounds 6 ounces.	that's good to hear.
that's good to hear.	will you go and visit them?
will you go and visit them?	of course i will.
of course i will.	i just wanted to give you the good news.
i just wanted to give you the good news.	thanks for letting me know.
have you heard the news?	i haven't heard anything.
i haven't heard anything.	debrah had her baby last week.
debrah had her baby last week.	nobody told me.
nobody told me.	i thought you heard.
i thought you heard.	i really wasn't told anything.
i really wasn't told anything.	she was a cute 8 pounds 6 ounces.
she was a cute 8 pounds 6 ounces.	wow, how exciting.
wow, how exciting.	i know, you should really go and see her and the baby.
i know, you should really go and see her and the baby.	of course i will.
of course i will.	i just wanted to let you know what happened.
did you go to school today?	of course. did you?
of course. did you?	i didn't want to, so i didn't.
i didn't want to, so i didn't.	that's sad, but have you gone to the movies recently?
that's sad, but have you gone to the movies recently?	that's a switch.
that's a switch.	i'm serious, have you?
i'm serious, have you?	no, i haven't. why?
no, i haven't. why?	i really want to go to the movies this weekend.
i really want to go to the movies this weekend.	so go then.
so go then.	i really don't want to go by myself.
i really don't want to go by myself.	well anyway, do you plan on going to school tomorrow?
well anyway, do you plan on going to school tomorrow?	no, i think i'm going to go to the movies.
did you make it to school today?	i always do. did you go to school today?
i always do. did you go to school today?	no, i didn't.
no, i didn't.	you should have, but have you seen any movies lately?
you should have, but have you seen any movies lately?	that was an odd change of subject.
that was an odd change of subject.	maybe it was, but answer the question.
maybe it was, but answer the question.	no, not recently.
no, not recently.	i want to go to see a movie this weekend.
i want to go to see a movie this weekend.	what's stopping you then?
what's stopping you then?	i don't want to go alone.
i don't want to go alone.	so, will you be at school tomorrow?
so, will you be at school tomorrow?	no, i want to go to the movies instead.
did you even bother to go to school today?	yeah, i went. did you go?
yeah, i went. did you go?	no, i didn't feel like it.
no, i didn't feel like it.	that's nice, have you been to the movies lately?
that's nice, have you been to the movies lately?	no, but that was a random change of subject.
no, but that was a random change of subject.	it may have been random, but have you?
it may have been random, but have you?	i haven't lately.
i haven't lately.	i would love to catch a movie this weekend.
i would love to catch a movie this weekend.	so then, why don't you just go?
so then, why don't you just go?	i don't want to see a movie by myself.
i don't want to see a movie by myself.	okay, so are you going to school tomorrow?
thanks for coming to see me today.	it's no problem. i was really missing you anyway.
it's no problem. i was really missing you anyway.	i missed you too.
i missed you too.	why haven't you tried to come see me then?
why haven't you tried to come see me then?	i've been really busy.
i've been really busy.	doing what?
doing what?	working.
working.	i would've come to see you sooner, but i've been busy too.
i would've come to see you sooner, but i've been busy too.	what have you been doing?
what have you been doing?	i've been working too.
i've been working too.	well regardless, i'm very happy that you came to see me.
well regardless, i'm very happy that you came to see me.	i am too.
i'm really glad that you came to see me.	i had to. i was missing you a lot.
i had to. i was missing you a lot.	i was missing you too.
i was missing you too.	so, why haven't you visited me?
so, why haven't you visited me?	i've actually been busy lately.
i've actually been busy lately.	what have you been doing?
what have you been doing?	i've just been working really hard.
i've just been working really hard.	i've also been busy.
i've also been busy.	tell me what you've been doing.
tell me what you've been doing.	basically, i've been working too.
basically, i've been working too.	well whatever, i'm glad you came.
well whatever, i'm glad you came.	so am i.
i'm really happy that you came to visit me.	i really missed you a lot.
i really missed you a lot.	i've been missing you like crazy.
i've been missing you like crazy.	i don't understand why you haven't come to visit me.
i don't understand why you haven't come to visit me.	lately, i've been quite busy.
lately, i've been quite busy.	tell me what you've been up to.
tell me what you've been up to.	i've really been working a lot lately.
i've really been working a lot lately.	i've been pretty busy myself.
i've been pretty busy myself.	so what have you been up to?
so what have you been up to?	i've just been working a lot.
i've just been working a lot.	whatever the reason may be, i'm glad you visited me.
hey, did you hear about jessica's party this weekend?	yeah, but i'm still waiting for my invitation.
yeah, but i'm still waiting for my invitation.	oh really? she gave me mine earlier today.
oh really? she gave me mine earlier today.	well, she'll probably just give me my invitation later on today.
well, she'll probably just give me my invitation later on today.	yeah, so are you planning on going?
yeah, so are you planning on going?	i think so. it sounds like it's going to be a lot of fun.
i think so. it sounds like it's going to be a lot of fun.	it really does, i can't wait.
it really does, i can't wait.	what time does the party start?
what time does the party start?	it starts at 8 o'clock.
it starts at 8 o'clock.	oh, well, how many people has she given invites to so far?
oh, well, how many people has she given invites to so far?	i'm not sure, but i don't think she's given out that many.
i'm not sure, but i don't think she's given out that many.	well, hopefully she'll give me my invite later on today.
have you heard about jessica's party on saturday?	i've heard about it, but i'm still waiting for my invitation.
i've heard about it, but i'm still waiting for my invitation.	really? i got mine from her this morning.
really? i got mine from her this morning.	i'm guessing that she's going to give me my invite today or tomorrow.
i'm guessing that she's going to give me my invite today or tomorrow.	you're probably right, do you intend on going to the party?
you're probably right, do you intend on going to the party?	i want to. i heard it's going to be really fun.
i want to. i heard it's going to be really fun.	i know, it does sound pretty awesome.
i know, it does sound pretty awesome.	well, when does the party start?
well, when does the party start?	it's supposed to start at about eight.
it's supposed to start at about eight.	how many invitations has she given out?
how many invitations has she given out?	i really don't know, but i don't think she gave out that many yet.
i really don't know, but i don't think she gave out that many yet.	i really want to go, so i hope that she gives me my invite soon.
has anyone told you about jessica's party coming up?	i was told about it already. i'm just waiting for my invitation.
i was told about it already. i'm just waiting for my invitation.	is that right? i already got my invitation from her earlier.
is that right? i already got my invitation from her earlier.	i believe that she will give me the invitation today.
i believe that she will give me the invitation today.	are you even going to go?
are you even going to go?	yeah, it sounds like it's going to be the best party of the year.
yeah, it sounds like it's going to be the best party of the year.	exactly, it seems like it's going to be loads of fun.
exactly, it seems like it's going to be loads of fun.	when exactly does the party start?
when exactly does the party start?	the invitation says it starts at 8:00 p.m.
the invitation says it starts at 8:00 p.m.	has she given out a lot of invitations yet?
has she given out a lot of invitations yet?	i have no idea, she hasn't given out many though.
hey, what's up?	nothing really.
nothing really.	i'm throwing a party on friday.
i'm throwing a party on friday.	i didn't realize that.
i didn't realize that.	you didn't?
you didn't?	nobody has told me anything about your party.
nobody has told me anything about your party.	did you want to go?
did you want to go?	when does it start?
when does it start?	at 8:00 p.m.
at 8:00 p.m.	i'll be there.
i'll be there.	i'd better see you there.
i'd better see you there.	of course.
what's going on with you?	fine. what's going on with you?
fine. what's going on with you?	i'm having a party this friday.
i'm having a party this friday.	i had no idea.
i had no idea.	is that right?
is that right?	i didn't hear anything about it.
i didn't hear anything about it.	can you go?
can you go?	what time?
what time?	it starts at 8 o'clock.
it starts at 8 o'clock.	i'll go.
i'll go.	i hope that i'll see you there.
i hope that i'll see you there.	no doubt.
what's going on?	not much.
not much.	this friday, i'm throwing a party.
this friday, i'm throwing a party.	oh really? i didn't know that.
oh really? i didn't know that.	are you serious?
are you serious?	i haven't heard anything about it.
i haven't heard anything about it.	can you make it?
can you make it?	what time does it start?
what time does it start?	the party starts at 8.
the party starts at 8.	yeah, i think i'll go.
yeah, i think i'll go.	am i going to see you there?
what's going on?	nothing really, you?
nothing really, you?	i'm throwing a party next saturday.
i'm throwing a party next saturday.	is that right?
is that right?	yeah, are you going to come?
yeah, are you going to come?	i'm sorry, i can't.
i'm sorry, i can't.	why not?
why not?	i don't really want to.
i don't really want to.	well, why don't you?
well, why don't you?	i hate going to parties.
i hate going to parties.	well, that's okay.
well, that's okay.	yeah, sorry.
what's up?	nothing, how about you?
nothing, how about you?	next saturday, i'm going to have a party.
next saturday, i'm going to have a party.	oh, really?
oh, really?	you are coming?
you are coming?	probably not.
probably not.	why is that?
why is that?	i don't feel like going.
i don't feel like going.	why not?
why not?	i really can't stand going to parties.
i really can't stand going to parties.	i understand, i guess.
i understand, i guess.	sorry about that.
what's happening?	not a lot, what about you?
not a lot, what about you?	i'm having a party next saturday.
i'm having a party next saturday.	that's nice.
that's nice.	are you going to be there?
are you going to be there?	i don't think so.
i don't think so.	is there a reason why?
is there a reason why?	i just really don't want to go.
i just really don't want to go.	how come?
how come?	i don't really like parties.
i don't really like parties.	i wish you would go, but that's okay.
what's up?	nothing much, what's going on?
nothing much, what's going on?	i'm having a party this friday.
i'm having a party this friday.	oh, really? that's nice.
oh, really? that's nice.	i wanted to see if you wanted to come.
i wanted to see if you wanted to come.	this friday? sorry, i already have plans.
this friday? sorry, i already have plans.	doing what?
doing what?	i'm going to dinner with my family.
i'm going to dinner with my family.	i really wanted you to come, but i understand.
i really wanted you to come, but i understand.	yeah, maybe next time.
yeah, maybe next time.	i'll hold you to that.
i'll hold you to that.	sounds like a plan.
hey, what's good with you?	not a lot. what about you?
not a lot. what about you?	i'm throwing a party on friday.
i'm throwing a party on friday.	that sounds like fun.
that sounds like fun.	do you think you can come?
do you think you can come?	i'm sorry. i'm already doing something this friday.
i'm sorry. i'm already doing something this friday.	what are you going to be doing?
what are you going to be doing?	my family and i are going to dinner.
my family and i are going to dinner.	i was hoping you would come.
i was hoping you would come.	i'll definitely try to make it the next time.
i'll definitely try to make it the next time.	i'd better see you there.
i'd better see you there.	all right. i'll see you next time.
what's going on?	nothing really. how about you?
nothing really. how about you?	a lot, like the party i'm having on friday.
a lot, like the party i'm having on friday.	well, that's cool.
well, that's cool.	will you be able to make it?
will you be able to make it?	i'm busy this friday. i'm sorry.
i'm busy this friday. i'm sorry.	what do you have to do?
what do you have to do?	i'm having dinner with my family
i'm having dinner with my family	maybe you can come next time.
maybe you can come next time.	i'll make sure and come to your next party.
i'll make sure and come to your next party.	i'll look for you at my next party.
it was nice talking to you.	why are you trying to rush me off the phone?
why are you trying to rush me off the phone?	i really have to go.
i really have to go.	why? i still wanted to talk to you.
why? i still wanted to talk to you.	i have things to do.
i have things to do.	like what?
like what?	don't be nosey.
don't be nosey.	i'm not. i just want to know.
i'm not. i just want to know.	well, it's really none of your business.
well, it's really none of your business.	that's harsh.
that's harsh.	i'm sorry, but i have to go.
i'm sorry, but i have to go.	fine.
i've enjoyed conversing with you.	is there a reason why you're trying to get off the phone so fast?
is there a reason why you're trying to get off the phone so fast?	i've got to go.
i've got to go.	i wasn't done talking to you.
i wasn't done talking to you.	i have to do some things, and besides, it's not polite to be nosey.
i have to do some things, and besides, it's not polite to be nosey.	i'm not being nosey. i'm just asking.
i'm not being nosey. i'm just asking.	i really don't think it's any of your business.
i really don't think it's any of your business.	that's not nice.
that's not nice.	i apologize, but i'm getting off the phone now.
i apologize, but i'm getting off the phone now.	okay.
i'll talk to you later.	what's the rush?
what's the rush?	i have to get off the phone now.
i have to get off the phone now.	i'm not ready to get off the phone with you.
i'm not ready to get off the phone with you.	there are other things i need to take care of.
there are other things i need to take care of.	what is it that you need to do? 
what is it that you need to do? 	please don't be nosey.
please don't be nosey.	i'm not being nosey, it's just a question.
i'm not being nosey, it's just a question.	you don't need to worry about that.
you don't need to worry about that.	that was mean to say.
that was mean to say.	i am very sorry, but i must go.
well, it was nice talking to you.	it was nice talking to you too.
it was nice talking to you too.	we should really hang out again.
we should really hang out again.	that would be fun.
that would be fun.	where do you want to go?
where do you want to go?	i think we should go out to eat.
i think we should go out to eat.	that sounds good.
that sounds good.	all right, so i'll see you then.
all right, so i'll see you then.	i'll call you later.
i'll call you later.	okay, i'll talk to you later then.
okay, i'll talk to you later then.	see you later.
see you later.	bye.
i enjoyed talking to you.	i enjoyed talking to you too.
i enjoyed talking to you too.	we should hang out some time.
we should hang out some time.	i think that would be nice.
i think that would be nice.	is there anything you would like to do next time?
is there anything you would like to do next time?	do you want to go out to eat?
do you want to go out to eat?	i'd like that.
i'd like that.	so i'll see you next time.
so i'll see you next time.	i'm going to call you soon. 
i'm going to call you soon. 	i'll talk to you later.
i'll talk to you later.	see you soon.
see you soon.	goodbye.
i had fun talking to you.	it was really nice talking to you also.
it was really nice talking to you also.	i think we should really do something sometime.
i think we should really do something sometime.	that should be loads of fun.
that should be loads of fun.	what do you want to do next time?
what do you want to do next time?	would you like to go to dinner or something?
would you like to go to dinner or something?	yeah, let's do that.
yeah, let's do that.	okay, until next time then.
okay, until next time then.	i'll call you so we can set that up.
i'll call you so we can set that up.	talk to you then.
talk to you then.	all right, see you.
where do you live?	i live in pasadena.
i live in pasadena.	where is pasadena?
where is pasadena?	it's in california.
it's in california.	is it in northern california?
is it in northern california?	no. it's in southern california.
no. it's in southern california.	is pasadena a big city?
is pasadena a big city?	it's pretty big.
it's pretty big.	how big is "pretty big"?
how big is "pretty big"?	it has about 140,000 people.
it has about 140,000 people.	how big is los angeles?
how big is los angeles?	it has about 3 million people.
do you have a car?	yes, i do.
yes, i do.	what kind of car do you have?
what kind of car do you have?	i have a honda.
i have a honda.	is it new?
is it new?	it was new in 2003.
it was new in 2003.	so, it's pretty old now.
so, it's pretty old now.	yes, it is. but it still looks good.
yes, it is. but it still looks good.	do you take good care of it?
do you take good care of it?	oh, yes. i wash it once a week.
oh, yes. i wash it once a week.	do you change the oil?
do you change the oil?	my mechanic changes the oil twice a year.
do you have a girlfriend?	no, i don't. do you?
no, i don't. do you?	i don't have a girlfriend, either.
i don't have a girlfriend, either.	why not?
why not?	i don't know. maybe i'm not rich enough.
i don't know. maybe i'm not rich enough.	girls like guys with money.
girls like guys with money.	they sure do.
they sure do.	they like guys with new cars.
they like guys with new cars.	i don't have money or a new car.
i don't have money or a new car.	me, neither.
me, neither.	but girls like guys who are funny.
but girls like guys who are funny.	maybe we should learn some good jokes.
where are you going?	i have to walk the dog.
i have to walk the dog.	what kind of dog do you have?
what kind of dog do you have?	i have a little poodle.
i have a little poodle.	poodles bark a lot.
poodles bark a lot.	they sure do.
they sure do.	they bark at everything.
they bark at everything.	they never shut up.
they never shut up.	why did you get a poodle?
why did you get a poodle?	it's my mom's dog.
it's my mom's dog.	so she likes poodles.
so she likes poodles.	she says they're good watchdogs.
can i borrow $5?	sure. why do you need it?
sure. why do you need it?	i want to buy lunch.
i want to buy lunch.	where's your money?
where's your money?	it's not in my wallet.
it's not in my wallet.	your wallet is empty?
your wallet is empty?	i don't have even one dollar in it.
i don't have even one dollar in it.	being broke is no fun.
being broke is no fun.	even if it's only for a short while.
even if it's only for a short while.	it's always good to have friends.
it's always good to have friends.	friends will lend you money when you're broke.
friends will lend you money when you're broke.	as long as you pay them back.
let's go to the beach.	that's a great idea.
that's a great idea.	we haven't been in a while.
we haven't been in a while.	we haven't been in a month.
we haven't been in a month.	the last time we went, you almost drowned.
the last time we went, you almost drowned.	no, i didn't.
no, i didn't.	then why did the lifeguard dive into the water?
then why did the lifeguard dive into the water?	i think he wanted to cool off.
i think he wanted to cool off.	he swam right up to you.
he swam right up to you.	and then he turned right around.
and then he turned right around.	maybe you're right.
maybe you're right.	maybe we should get going.
are you married?	no. i'm divorced.
no. i'm divorced.	when did you get divorced?
when did you get divorced?	i got divorced two years ago.
i got divorced two years ago.	why did you get divorced?
why did you get divorced?	my wife left me.
my wife left me.	why did she leave you?
why did she leave you?	she said she didn't love me anymore.
she said she didn't love me anymore.	wow! that's terrible.
wow! that's terrible.	yes, it was.
yes, it was.	why didn't she love you anymore?
why didn't she love you anymore?	she fell in love with my best friend.
i'm bored.	what's on tv?
what's on tv?	nothing.
nothing.	there must be something on tv!
there must be something on tv!	nothing that's interesting.
nothing that's interesting.	what about that new game show?
what about that new game show?	which one?
which one?	"deal or no deal"
"deal or no deal"	tell me you're joking.
tell me you're joking.	i love that show.
i love that show.	i watched it once. that was enough.
i watched it once. that was enough.	it's on right now. let's watch it together.
i like living here.	i agree. pasadena is a nice city.
i agree. pasadena is a nice city.	it's not too big.
it's not too big.	and it's not too small.
and it's not too small.	it has great weather all year long.
it has great weather all year long.	it has the rose parade.
it has the rose parade.	it has beautiful houses.
it has beautiful houses.	it has wonderful restaurants.
it has wonderful restaurants.	it has great schools.
it has great schools.	it's close to the mountains.
it's close to the mountains.	the people are friendly.
the people are friendly.	i'm not ever going to leave.
we need a new mattress.	what's the matter with this one?
what's the matter with this one?	it's not comfortable.
it's not comfortable.	it seems fine to me.
it seems fine to me.	i toss and turn all night.
i toss and turn all night.	you should stop drinking coffee.
you should stop drinking coffee.	look at these marks on my arms.
look at these marks on my arms.	what are they?
what are they?	they are bites.
they are bites.	did the cat bite you?
did the cat bite you?	no. the bedbugs in that mattress bit me.
no. the bedbugs in that mattress bit me.	okay. let's get a new mattress.
my laptop is so slow.	buy a new one.
buy a new one.	i would if i had the money.
i would if i had the money.	why is it so slow?
why is it so slow?	that's a good question.
that's a good question.	did you take it to a computer shop?
did you take it to a computer shop?	i would if i had the money.
i would if i had the money.	well, i guess you have to live with it.
well, i guess you have to live with it.	sometimes i want to throw it out the window.
sometimes i want to throw it out the window.	you don't want to do that.
you don't want to do that.	why not?
why not?	you might hit someone in the head.
what's for dinner?	i'm not sure.
i'm not sure.	how about a pizza?
how about a pizza?	you had pizza for lunch.
you had pizza for lunch.	but i love pizza.
but i love pizza.	everybody loves pizza.
everybody loves pizza.	so why can't i have pizza for dinner?
so why can't i have pizza for dinner?	because you need variety.
because you need variety.	what's "variety?
what's "variety?	different thingsnot the same thing all the time.
different thingsnot the same thing all the time.	you mean, like a pepperoni pizza instead of a cheese pizza?
you mean, like a pepperoni pizza instead of a cheese pizza?	no, i mean a salad instead of a pizza.
we need to save money.	why do we need to save money?
why do we need to save money?	because we need to buy a house.
because we need to buy a house.	but a house is so expensive.
but a house is so expensive.	that's why we need to save money.
that's why we need to save money.	how much do we need to save?
how much do we need to save?	we need to save enough for a down payment.
we need to save enough for a down payment.	how much is that?
how much is that?	that's about $30,000.
that's about $30,000.	thirty thousand dollars! that will take forever.
thirty thousand dollars! that will take forever.	not if we save every penny.
not if we save every penny.	okay. here's seven pennies.
the ocean is so big.	you can't see the end of it.
you can't see the end of it.	it goes on and on forever.
it goes on and on forever.	and it's deep, too.
and it's deep, too.	i think it's five miles deep.
i think it's five miles deep.	are there fish at the bottom?
are there fish at the bottom?	there are fish at the top and the bottom.
there are fish at the top and the bottom.	are there more fish or more people?
are there more fish or more people?	i think there are more fish.
i think there are more fish.	i hope so. i love to eat fish.
i'm upset with my mom.	why is that?
why is that?	i warned her about her new boyfriend. she didn't listen to me.
i warned her about her new boyfriend. she didn't listen to me.	what happened?
what happened?	i gave her $1,000 for her birthday. i told her to spend it on herself.
i gave her $1,000 for her birthday. i told her to spend it on herself.	that was very nice of you.
that was very nice of you.	i found out that she gave it to her new boyfriend.
i found out that she gave it to her new boyfriend.	why did she do that?
why did she do that?	he said he would buy her a nice ring.
he said he would buy her a nice ring.	what's wrong with that?
what's wrong with that?	he went to las vegas. he lost it all gambling.
he went to las vegas. he lost it all gambling.	i hope your mom broke up with him.
do animals talk to each other?	of course they talk to each other.
of course they talk to each other.	what do they talk about?
what do they talk about?	they talk about other animals.
they talk about other animals.	what else do they talk about?
what else do they talk about?	they talk about food and the weather.
they talk about food and the weather.	do they talk about us?
do they talk about us?	of course they talk about us.
of course they talk about us.	what do they say about us?
what do they say about us?	they say that we are funny-looking.
they say that we are funny-looking.	ha! we're not funny-looking; animals are funny-looking.
ha! we're not funny-looking; animals are funny-looking.	we're funny-looking because we wear clothes.
i have to clean the house.	yes, it's very dirty.
yes, it's very dirty.	you can help me.
you can help me.	why me?
why me?	because you helped make it dirty.
because you helped make it dirty.	what do you want me to do?
what do you want me to do?	i want you to clean the bathroom.
i want you to clean the bathroom.	oh, that's easy.
oh, that's easy.	clean the sink, the tub, the counter, and the toilet.
clean the sink, the tub, the counter, and the toilet.	that's a lot of work.
that's a lot of work.	tell me when you finish.
tell me when you finish.	i don't think so. you'll just give me more work.
you're watching too much tv.	what do you mean?
what do you mean?	i mean you're wasting your life.
i mean you're wasting your life.	i'm having fun.
i'm having fun.	you're sitting there with your mouth open.
you're sitting there with your mouth open.	who cares?
who cares?	i care. do something.
i care. do something.	okay. i did something.
okay. i did something.	what did you do?
what did you do?	i turned up the volume.
i turned up the volume.	that's not what i meant by "do something."
that's not what i meant by "do something."	will you do something? leave me alone.
did you write a letter to grandma?	yes, i did.
yes, i did.	did you tell her about school?
did you tell her about school?	i told her that school is fun.
i told her that school is fun.	did you put the letter in an envelope?
did you put the letter in an envelope?	yes, and i sealed the envelope.
yes, and i sealed the envelope.	did you put a stamp on the envelope?
did you put a stamp on the envelope?	i couldn't find any stamps.
i couldn't find any stamps.	they're in the kitchen drawer.
they're in the kitchen drawer.	okay. i just put a stamp on the envelope.
okay. i just put a stamp on the envelope.	give me the envelope, and i'll mail it for you.
give me the envelope, and i'll mail it for you.	when is grandma going to learn about e-mail?
why are you yawning?	i'm sleepy.
i'm sleepy.	why don't you go to bed?
why don't you go to bed?	i want to watch this tv show.
i want to watch this tv show.	maybe you should record it.
maybe you should record it.	the tape recorder is broken.
the tape recorder is broken.	then you should watch the rerun.
then you should watch the rerun.	why? i'm watching the original.
why? i'm watching the original.	but you'll be asleep in about one minute.
but you'll be asleep in about one minute.	i'm just yawning because the commercials are on.
i'm just yawning because the commercials are on.	okay. i'll tell you how the show ends.
okay. i'll tell you how the show ends.	zzz.
it's sunday.	so?
so?	you know what that means.
you know what that means.	i forgot.
i forgot.	sunday means we go to church.
sunday means we go to church.	oh, yeah.
oh, yeah.	put on a coat and tie.
put on a coat and tie.	why?
why?	to show respect to god and others.
to show respect to god and others.	i'm glad sunday is only once a week.
i'm glad sunday is only once a week.	i hope god didn't hear that.
i hope god didn't hear that.	he'll forgive me.
did you feed the cat?	i'll do that in a minute.
i'll do that in a minute.	the cat is meowing. he's hungry.
the cat is meowing. he's hungry.	okay. i'll feed him right now.
okay. i'll feed him right now.	you shouldn't make him wait.
you shouldn't make him wait.	i was doing my homework.
i was doing my homework.	the cat doesn't care about your homework.
the cat doesn't care about your homework.	the cat doesn't care about anything.
the cat doesn't care about anything.	that's the way cats are.
that's the way cats are.	all they think about is themselves.
all they think about is themselves.	maybe we should get rid of him.
maybe we should get rid of him.	of course not! he's family.
i hate shaving.	me too.
me too.	i just cut myself again.
i just cut myself again.	did you use a new blade?
did you use a new blade?	it doesn't matter. old blades cut, new blades cut.
it doesn't matter. old blades cut, new blades cut.	maybe you should use an electric shaver.
maybe you should use an electric shaver.	they make a lot of noise, but they don't give a close shave.
they make a lot of noise, but they don't give a close shave.	maybe you should stop shaving.
maybe you should stop shaving.	and grow a beard?
and grow a beard?	sure. why not?
sure. why not?	because food and other stuff sticks in my beard.
because food and other stuff sticks in my beard.	hmm. here's an idea. put cream on your face and have the cat lick it off.
excuse me.	yes?
yes?	are you reading this paper?
are you reading this paper?	oh, no. help yourself.
oh, no. help yourself.	i asked because the paper is sitting next to you.
i asked because the paper is sitting next to you.	thank you. that's polite of you to ask.
thank you. that's polite of you to ask.	some people would just pick it up.
some people would just pick it up.	yes, i know. some people are rude.
yes, i know. some people are rude.	i always try to be polite.
i always try to be polite.	so do i.
so do i.	the world needs more polite people like us.
the world needs more polite people like us.	i agree 100 percent.
mom, i want a puppy.	let me think about it.
let me think about it.	why do you have to think about it?
why do you have to think about it?	because a puppy costs money.
because a puppy costs money.	no, it doesn't. puppies are free.
no, it doesn't. puppies are free.	yes, but a puppy needs shots.
yes, but a puppy needs shots.	shots for what?
shots for what?	so it won't get sick. just like you get shots.
so it won't get sick. just like you get shots.	i hate shots.
i hate shots.	and a puppy eats food. food costs money.
and a puppy eats food. food costs money.	no problem. i'll give him food off my plate.
no problem. i'll give him food off my plate.	oh, no you don't. puppies don't eat vegetables.
look at all these kittens!	how many are there?
how many are there?	eight.
eight.	they're all so cute.
they're all so cute.	yes, but i can't keep them.
yes, but i can't keep them.	what are you going to do with them?
what are you going to do with them?	i'm going to give them away. do you want one?
i'm going to give them away. do you want one?	yes, i would love one.
yes, i would love one.	which one do you want?
which one do you want?	that one. the one that's all black.
that one. the one that's all black.	yes, i like that one, too.
yes, i like that one, too.	i'll call him blacky.
my parents go to church every sunday.	they trust in god.
they trust in god.	they hope they will go to heaven.
they hope they will go to heaven.	they probably will.
they probably will.	but no one knows for sure.
but no one knows for sure.	that's for sure.
that's for sure.	no one knows what happens after we die.
no one knows what happens after we die.	if we are good, we will be happy in heaven with god.
if we are good, we will be happy in heaven with god.	that's what many people believe.
that's what many people believe.	if we are bad, we will be unhappy forever in hell.
if we are bad, we will be unhappy forever in hell.	i don't want to go to hell.
i don't want to go to hell.	let's go to church with your parents on sunday.
my husband died.	i'm sorry for you.
i'm sorry for you.	thank you.
thank you.	when did he die?
when did he die?	a couple of months ago.
a couple of months ago.	you still miss him.
you still miss him.	yes, but i talk to him almost every day.
yes, but i talk to him almost every day.	when you go to church?
when you go to church?	no, when i call him on his cell phone.
no, when i call him on his cell phone.	what do you mean?
what do you mean?	i buried him with his cell phone.
i buried him with his cell phone.	what will you do when the battery dies?
today is friday the thirteenth.	that's a bad day.
that's a bad day.	it's supposed to be unlucky.
it's supposed to be unlucky.	you're supposed to stay home all day.
you're supposed to stay home all day.	that's what i do.
that's what i do.	my friend stayed in a hotel on friday the thirteenth.
my friend stayed in a hotel on friday the thirteenth.	that was a mistake.
that was a mistake.	he stayed on the thirteenth floor.
he stayed on the thirteenth floor.	what happened?
what happened?	someone stole his laptop.
someone stole his laptop.	he was asking for it.
he was asking for it.	he learned his lesson. he's home today.
do you really love me?	of course.
of course.	prove it.
prove it.	how can i prove it?
how can i prove it?	take me to dinner.
take me to dinner.	that's it? that's all i have to do?
that's it? that's all i have to do?	take me to a nice restaurant, not to mcdonald's.
take me to a nice restaurant, not to mcdonald's.	but a nice restaurant costs money.
but a nice restaurant costs money.	yes, and you have to make a reservation.
yes, and you have to make a reservation.	that's such a hassle.
that's such a hassle.	i knew you didn't love me.
i knew you didn't love me.	okay, okay! i'll make a reservation right now.
my parents are divorced.	so are mine.
so are mine.	why did your parents get divorced?
why did your parents get divorced?	my father found a new girlfriend.
my father found a new girlfriend.	that's too bad.
that's too bad.	my mother was hurt and angry.
my mother was hurt and angry.	she had good reason. what did she do?
she had good reason. what did she do?	she told him to drop his girlfriend.
she told him to drop his girlfriend.	what did your father do?
what did your father do?	he moved out of our house.
he moved out of our house.	i guess he really liked his new girlfriend.
i guess he really liked his new girlfriend.	yes, but she left him a year later.
my grandma's apartment smells funny.	so does mine.
so does mine.	i think it's an old people's smell.
i think it's an old people's smell.	really?
really?	yes. i think when you get old, you begin to smell.
yes. i think when you get old, you begin to smell.	like fruit that is too ripe?
like fruit that is too ripe?	yes, just like fruit that is too ripe.
yes, just like fruit that is too ripe.	but the smell is different.
but the smell is different.	yes, old people don't smell like fruit.
yes, old people don't smell like fruit.	no, they smell like a thrift shop.
no, they smell like a thrift shop.	yes, a thrift shop has that same smell.
yes, a thrift shop has that same smell.	yes, an old smell.
the price of stamps goes up and up.	i think stamps used to cost a penny.
i think stamps used to cost a penny.	that was a long time ago.
that was a long time ago.	it was before i was born.
it was before i was born.	now a stamp is 42 cents.
now a stamp is 42 cents.	but in may it will be 44 cents.
but in may it will be 44 cents.	have you ever lost a letter in the mail?
have you ever lost a letter in the mail?	no, i haven't.
no, i haven't.	neither have i.
neither have i.	so, they do a good job for the money.
so, they do a good job for the money.	yes, they do.
yes, they do.	maybe we shouldn't complain.
a button came off my shirt.	what are you going to do?
what are you going to do?	first, i have to find the button.
first, i have to find the button.	where did you lose it?
where did you lose it?	i have no idea.
i have no idea.	a button is hard to find. did you look in your pant cuffs?
a button is hard to find. did you look in your pant cuffs?	that's a good idea.
that's a good idea.	i found a button in my pant cuffs one time.
i found a button in my pant cuffs one time.	let me look. no, it's not there.
let me look. no, it's not there.	many shirts come with an extra button.
many shirts come with an extra button.	you're right. this one does have an extra button.
you're right. this one does have an extra button.	now all you have to do is sew it on.
i have to go to the bathroom.	you drink too much coffee.
you drink too much coffee.	but i love coffee.
but i love coffee.	well, it's your life.
well, it's your life.	you eat too much chocolate.
you eat too much chocolate.	i don't think so.
i don't think so.	have you looked in the mirror?
have you looked in the mirror?	do you think i'm getting fat?
do you think i'm getting fat?	i didn't say that.
i didn't say that.	what did you say?
what did you say?	i said i have to go to the bathroom.
i said i have to go to the bathroom.	that's what i thought you said.
did you do the laundry?	yes, i did.
yes, i did.	what did you wash?
what did you wash?	i washed the sheets and towels.
i washed the sheets and towels.	what about the pillowcases?
what about the pillowcases?	yes, i took them off the pillows and washed them.
yes, i took them off the pillows and washed them.	did you dry everything in the dryer?
did you dry everything in the dryer?	yes, i dried everything in the dryer.
yes, i dried everything in the dryer.	then what did you do?
then what did you do?	i folded all the towels.
i folded all the towels.	did you put the sheets on the beds?
did you put the sheets on the beds?	yes, and i put the pillowcases on the pillows.
do you listen to the radio?	i listen day and night.
i listen day and night.	what do you listen to?
what do you listen to?	mostly talk radio.
mostly talk radio.	what's that?
what's that?	people talk about current events.
people talk about current events.	what do they say?
what do they say?	they say they want change.
they say they want change.	what kind of change?
what kind of change?	they want tax cuts.
they want tax cuts.	why do they want tax cuts?
why do they want tax cuts?	because tax cuts will save them money.
mom, i'm hungry.	look in the fridge.
look in the fridge.	i'm looking. there's nothing to eat.
i'm looking. there's nothing to eat.	are you sure?
are you sure?	it's almost empty.
it's almost empty.	i went to the market yesterday.
i went to the market yesterday.	i don't see anything.
i don't see anything.	i bought lots of oranges and apples.
i bought lots of oranges and apples.	i don't want fruit. i want something tasty.
i don't want fruit. i want something tasty.	eat the fruit. it's good for you.
eat the fruit. it's good for you.	next time you go to the market, let me go with you.
next time you go to the market, let me go with you.	no, thank you. all you want to eat are hot dogs and candy bars.
what is there to eat?	i don't know. look in the fridge.
i don't know. look in the fridge.	i think i'll make a sandwich.
i think i'll make a sandwich.	what kind?
what kind?	a ham sandwich.
a ham sandwich.	the bread is in the cabinet.
the bread is in the cabinet.	where's the mustard?
where's the mustard?	it's in the fridge, i think.
it's in the fridge, i think.	oh, yes, here it is. do you want a sandwich?
oh, yes, here it is. do you want a sandwich?	yes, that sounds nice.
yes, that sounds nice.	how about some potato chips?
how about some potato chips?	yes. and a pickle, if we have any.
it's time for your bath, young lady.	but, mom, i'm not dirty.
but, mom, i'm not dirty.	you need a bath every day.
you need a bath every day.	why?
why?	because you don't want to smell bad.
because you don't want to smell bad.	i don't smell bad.
i don't smell bad.	that's what you think.
that's what you think.	if i smelled bad, i could smell me.
if i smelled bad, i could smell me.	i can smell you.
i can smell you.	i can smell you, too.
i can smell you, too.	that's my perfume.
that's my perfume.	when can i wear perfume?
something's wrong with my computer.	exactly what?
exactly what?	all i get is a black screen.
all i get is a black screen.	what's the matter?
what's the matter?	i think i know, because this happened before.
i think i know, because this happened before.	what happened before?
what happened before?	my hard drive crashed.
my hard drive crashed.	oh, no. that's bad news.
oh, no. that's bad news.	it sure is, but i'm going to call hp first, just to make sure.
it sure is, but i'm going to call hp first, just to make sure.	will you lose all your files?
will you lose all your files?	no, i always back up my files.
no, i always back up my files.	you're smart.
i called hp about my computer.	what did they say?
what did they say?	they said i need a new hard drive.
they said i need a new hard drive.	that's too bad. how much is a new one?
that's too bad. how much is a new one?	it's not too much, only about $85.
it's not too much, only about $85.	plus installation?
plus installation?	no, my hard drive is easy to remove and replace.
no, my hard drive is easy to remove and replace.	really?
really?	yes, it's just a couple of screws.
yes, it's just a couple of screws.	that's nice.
that's nice.	it's a lot better than paying someone $60.
it's a lot better than paying someone $60.	if my hard drive crashes, i'll just call you.
what's your email address?	it's bluedog123.
it's bluedog123.	bluedog123. are you sure that's all?
bluedog123. are you sure that's all?	yes.
yes.	no. that's incomplete.
no. that's incomplete.	what do you mean?
what do you mean?	what's your mailing address?
what's your mailing address?	456 cherry drive, pasadena, ca 91170.
456 cherry drive, pasadena, ca 91170.	that's correct.
that's correct.	so what's the problem?
so what's the problem?	bluedog123 is just the street. you have to give me the city, state, and zip code.
bluedog123 is just the street. you have to give me the city, state, and zip code.	oh, i get it. my email address is bluedog123@yahoo.com.
i'm going to take a nap.	you should unplug the phone.
you should unplug the phone.	that's a good idea.
that's a good idea.	do you want me to wake you in an hour?
do you want me to wake you in an hour?	no, thanks. just let me sleep until i wake up.
no, thanks. just let me sleep until i wake up.	i'll start dinner at 6:00.
i'll start dinner at 6:00.	okay. i think i'll be awake by then.
okay. i think i'll be awake by then.	if not, your nose will wake you up.
if not, your nose will wake you up.	you mean i will smell the food cooking?
you mean i will smell the food cooking?	you might even dream about dinner.
you might even dream about dinner.	i don't think i'm going to dream about anything. i'm really tired.
i don't think i'm going to dream about anything. i'm really tired.	have a nice nap.
that was a nice funeral.	yes, dad, it was.
yes, dad, it was.	the son gave a nice speech about his father.
the son gave a nice speech about his father.	it was long, too.
it was long, too.	i think it was about 45 minutes long.
i think it was about 45 minutes long.	but it went by fast. it was interesting.
but it went by fast. it was interesting.	i liked it.
i liked it.	i'll give you a speech like that, too.
i'll give you a speech like that, too.	do you think anyone will come to my funeral?
do you think anyone will come to my funeral?	of course.
of course.	i think only the family will be there.
i think only the family will be there.	you have lots of friends. they will be there, too!
yikes! what was that noise?	i had to blow my nose.
i had to blow my nose.	did you have to blow right next to the phone?
did you have to blow right next to the phone?	did you hear that?
did you hear that?	of course i heard that. i thought a plane had crashed into your house.
of course i heard that. i thought a plane had crashed into your house.	it wasn't that loud.
it wasn't that loud.	i will blow my nose sometime for you, and you'll see.
i will blow my nose sometime for you, and you'll see.	okay. i'll take your word for it.
okay. i'll take your word for it.	i thought you had an elephant in your house.
i thought you had an elephant in your house.	you're funny.
you're funny.	what did you say? i think i've gone deaf.
what did you say? i think i've gone deaf.	i'm going into the bathroom to blow my nose. i'll be right back.
i have lots of friends.	really? how many do you have?
really? how many do you have?	i don't know, maybe one hundred.
i don't know, maybe one hundred.	that is a lot of friends. do you have a best friend?
that is a lot of friends. do you have a best friend?	of course. i have lots of best friends.
of course. i have lots of best friends.	how many best friends do you have?
how many best friends do you have?	i think about twenty-five.
i think about twenty-five.	hmm. i have only one best friend.
hmm. i have only one best friend.	i feel sorry for you.
i feel sorry for you.	i have only a few friends.
i have only a few friends.	you must be lonely. i will share my friends with you.
you must be lonely. i will share my friends with you.	that's very nice of you.
don't you ever cheat on me.	why would i do that?
why would i do that?	because men like to cheat.
because men like to cheat.	some men do, but not me.
some men do, but not me.	i'm watching you.
i'm watching you.	i'm an open book. watch me all you want.
i'm an open book. watch me all you want.	if i catch you, you'll be sorry.
if i catch you, you'll be sorry.	you won't catch me, because i love you. i'm not a cheater.
you won't catch me, because i love you. i'm not a cheater.	i will poke your eyes out. 
i will poke your eyes out. 	i don't want any other woman.
i don't want any other woman.	i will chop your toes off, one by one.
i will chop your toes off, one by one.	honey, please. you're the only woman for me, forever. i swear it.
i hate to go outside.	me too.
me too.	why do you hate to go outside?
why do you hate to go outside?	i meet too many jerks.
i meet too many jerks.	i agree.
i agree.	this city is full of jerks.
this city is full of jerks.	rude people are everywhere.
rude people are everywhere.	but what can you do?
but what can you do?	you can yell at them.
you can yell at them.	and they will yell back at you.
and they will yell back at you.	yelling doesn't do any good.
yelling doesn't do any good.	no. the best thing to do is just stay home.
will you look at this form?	are you having problems with it?
are you having problems with it?	i don't understand some things.
i don't understand some things.	let me help you.
let me help you.	what does "mi" mean?
what does "mi" mean?	"mi" stands for middle initial.
"mi" stands for middle initial.	what does "mm/dd/yy" mean?
what does "mm/dd/yy" mean?	that means month/day/year. use numbers.
that means month/day/year. use numbers.	i don't understand.
i don't understand.	for example, if your birth date is january 12, 1987, write 01/12/87.
for example, if your birth date is january 12, 1987, write 01/12/87.	oh. that's simple enough.
oh. that's simple enough.	always print clearly, and fill in the bubbles completely.
let's go to the animal shelter.	what do you want to do?
what do you want to do?	i want to get a puppy for my son.
i want to get a puppy for my son.	that will make him so happy.
that will make him so happy.	i'll get him one of those little dogs.
i'll get him one of those little dogs.	one that won't grow up too big.
one that won't grow up too big.	and eat too much.
and eat too much.	do you know which one he would like?
do you know which one he would like?	oh, yes, i took him there yesterday. he showed me one that he really liked.
oh, yes, i took him there yesterday. he showed me one that he really liked.	i bet you had to drag him away.
i bet you had to drag him away.	he wanted to take it home yesterday.
he wanted to take it home yesterday.	i wonder what he'll name it.
what's the weather like?	i don't know. i just woke up.
i don't know. i just woke up.	why don't you look outside?
why don't you look outside?	okay. it looks like rain.
okay. it looks like rain.	why do you say that?
why do you say that?	the sky is gray.
the sky is gray.	is it raining right now?
is it raining right now?	no.
no.	how do you know?
how do you know?	the street isn't wet.
the street isn't wet.	i have to go shopping today.
i have to go shopping today.	you'd better take an umbrella.
i can't believe how hot it is.	it's not even noon yet.
it's not even noon yet.	that means it will get hotter.
that means it will get hotter.	i am dying from the heat.
i am dying from the heat.	turn on the air conditioner.
turn on the air conditioner.	it doesn't work.
it doesn't work.	what happened?
what happened?	i don't know.
i don't know.	did you call the repairman?
did you call the repairman?	of course.
of course.	when is he coming?
when is he coming?	he's busy. he said next week.
i'll be glad when winter comes.	why is that?
why is that?	because i love the snow.
because i love the snow.	yes, the snow is fun.
yes, the snow is fun.	last year we made a big snowman.
last year we made a big snowman.	how big was it?
how big was it?	it was seven feet tall.
it was seven feet tall.	how long did it take?
how long did it take?	it took us all day.
it took us all day.	did you give him a nose?
did you give him a nose?	of course. we gave him a big carrot for a nose.
of course. we gave him a big carrot for a nose.	let me help you make one this year.
i'm going to the bank.	what do you need to do?
what do you need to do?	i need to withdraw some money.
i need to withdraw some money.	how are you going to do that?
how are you going to do that?	i'll just use the atm.
i'll just use the atm.	what's that?
what's that?	it's the automatic teller machine.
it's the automatic teller machine.	it gives you money?
it gives you money?	i just insert my debit card into the machine.
i just insert my debit card into the machine.	and it gives you money?
and it gives you money?	well, it gives me money, but it's my own money.
well, it gives me money, but it's my own money.	oh. what good is that? i thought it gave you free money.
did you put the blue bin out on the street?	oh, no. i forgot.
oh, no. i forgot.	well, you'd better take it out front.
well, you'd better take it out front.	what time does the recycle truck come by?
what time does the recycle truck come by?	it usually gets here at noon on tuesday, which is tomorrow.
it usually gets here at noon on tuesday, which is tomorrow.	i'll just take it out to the street tomorrow morning.
i'll just take it out to the street tomorrow morning.	oh, no, you don't.
oh, no, you don't.	what do you mean?
what do you mean?	every morning you get up late and rush off to work late.
every morning you get up late and rush off to work late.	do you think i'll forget to do it?
do you think i'll forget to do it?	you'll remember to do it, but you won't have time to do it.
you'll remember to do it, but you won't have time to do it.	okay, i'll take it out front right now.
are you ready?	ready for what?
ready for what?	ready for the big switch.
ready for the big switch.	what are you talking about?
what are you talking about?	the nation is switching to digital tv.
the nation is switching to digital tv.	oh. of course i'm ready.
oh. of course i'm ready.	did you buy the converter?
did you buy the converter?	no, i don't need a converter because i bought a digital tv.
no, i don't need a converter because i bought a digital tv.	how much was that?
how much was that?	it was only about $120 for a 13-inch screen.
it was only about $120 for a 13-inch screen.	does it pick up any digital channels?
does it pick up any digital channels?	oh, yes. i get six korean channels but nothing in english!
people are funny.	they sure are.
they sure are.	did you hear about the pilot?
did you hear about the pilot?	the one that stole a small plane?
the one that stole a small plane?	yes, he stole a plane in canada and flew into the u.s.
yes, he stole a plane in canada and flew into the u.s.	did they catch him?
did they catch him?	yes. after two u.s. fighter jets followed him for an hour, he landed on a highway.
yes. after two u.s. fighter jets followed him for an hour, he landed on a highway.	did he crash?
did he crash?	no, he just landed the plane and walked to a restaurant.
no, he just landed the plane and walked to a restaurant.	did the cops find out why he flew into the u.s.?
did the cops find out why he flew into the u.s.?	his life sucked. he was hoping a fighter jet would shoot him down.
his life sucked. he was hoping a fighter jet would shoot him down.	poor guy.
the police need our help finding a robber.	how do you know?
how do you know?	the tv news is reporting a bank robbery.
the tv news is reporting a bank robbery.	do they know what the robber looks like?
do they know what the robber looks like?	yes, he's 6 feet tall, 200 pounds, black hair, and about 30 years old.
yes, he's 6 feet tall, 200 pounds, black hair, and about 30 years old.	what race is he?
what race is he?	they didn't say.
they didn't say.	the tv news doesn't tell us the race anymore.
the tv news doesn't tell us the race anymore.	of course not. that would be racist.
of course not. that would be racist.	but how can we identify someone if we don't know their race?
but how can we identify someone if we don't know their race?	don't ask me.
don't ask me.	then they also shouldn't tell us if the robber is male or female, because that is sexist.
don't wipe your nose on your sleeve.	but i don't have a tissue.
but i don't have a tissue.	then go find a tissue in the bathroom.
then go find a tissue in the bathroom.	i didn't have time to get one from there.
i didn't have time to get one from there.	your sleeves are not tissues.
your sleeves are not tissues.	but mom, all my friends use their sleeves.
but mom, all my friends use their sleeves.	that doesn't make it right.
that doesn't make it right.	i saw dad wipe his nose on his sleeve yesterday.
i saw dad wipe his nose on his sleeve yesterday.	i will talk to your father about that.
i will talk to your father about that.	i bet dad did it all the time when he was my age.
i bet dad did it all the time when he was my age.	your daddy was a good little boy.
your daddy was a good little boy.	how do you know? were you his mommy, too?
i'm worried.	worried about what?
worried about what?	i'm getting married.
i'm getting married.	you should be happy, not worried.
you should be happy, not worried.	i am happy, but marriage is a lot of responsibility.
i am happy, but marriage is a lot of responsibility.	yes, you have to take care of your wife.
yes, you have to take care of your wife.	and i have to take care of our children.
and i have to take care of our children.	are you going to start a family?
are you going to start a family?	yes. we want to have a little boy and a little girl.
yes. we want to have a little boy and a little girl.	that sounds wonderful.
that sounds wonderful.	except we can't afford it!
except we can't afford it!	no wonder you're worried.
i don't get art.	or artists.
or artists.	they're in a different world.
they're in a different world.	i saw a painting of a jar that was full of pencils.
i saw a painting of a jar that was full of pencils.	the artist said the jar was both full and empty.
the artist said the jar was both full and empty.	but it was full of pencils! how could he say it was empty?
but it was full of pencils! how could he say it was empty?	artists see things differently.
artists see things differently.	did you ever see anything that picasso painted?
did you ever see anything that picasso painted?	of course! he's world famous.
of course! he's world famous.	did he ever take art lessons?
did he ever take art lessons?	i can't believe it. i drew paintings like that in third grade.
i can't believe it. i drew paintings like that in third grade.	where are they? maybe they are worth millions.
what's the point?	the point of what?
the point of what?	of living.
of living.	who knows? you live, and then you die.
who knows? you live, and then you die.	we must be here for some reason.
we must be here for some reason.	maybe we're here to have fun.
maybe we're here to have fun.	then why aren't i having fun?
then why aren't i having fun?	because you're thinking too much.
because you're thinking too much.	so i should stop thinking?
so i should stop thinking?	stop thinking about what the point is.
stop thinking about what the point is.	okay. i'll start thinking about having some fun.
okay. i'll start thinking about having some fun.	just be patient. fun doesn't come along every five minutes.
beer is a powerful drug.	so are cigarettes.
so are cigarettes.	which would you prefer?
which would you prefer?	what do you mean?
what do you mean?	when you die and go to heaven, they will offer you beer or cigarettes.
when you die and go to heaven, they will offer you beer or cigarettes.	i could pick only one or the other?
i could pick only one or the other?	yes. nothing's perfect, not even in heaven.
yes. nothing's perfect, not even in heaven.	boy, that's a tough one.
boy, that's a tough one.	what's so tough about it? of course, i would pick cigarettes.
what's so tough about it? of course, i would pick cigarettes.	but cigarettes taste much better when you have a cold beer.
but cigarettes taste much better when you have a cold beer.	well, you can't have everything.
well, you can't have everything.	i don't think i want to go to your heaven.
my pants have a hole in the front pocket.	you shouldn't carry pens in your pocket.
you shouldn't carry pens in your pocket.	yesterday a pen fell through my pants onto my shoe.
yesterday a pen fell through my pants onto my shoe.	lucky for you it wasn't a sharp knife.
lucky for you it wasn't a sharp knife.	who carries a sharp knife in their pocket?
who carries a sharp knife in their pocket?	criminals, of course.
criminals, of course.	anyway, i have to fix the hole.
anyway, i have to fix the hole.	you can sew it up or use an iron-on patch.
you can sew it up or use an iron-on patch.	tell me about this patch.
tell me about this patch.	the patch has glue. the hot iron melts the glue so the patch sticks on.
the patch has glue. the hot iron melts the glue so the patch sticks on.	that sounds a lot easier than sewing.
that sounds a lot easier than sewing.	it is. but after about ten washings, the glue washes off.
do you know any good jokes?	i can't remember jokes.
i can't remember jokes.	neither can i.
neither can i.	they go in one ear and out the other.
they go in one ear and out the other.	who makes up all these jokes?
who makes up all these jokes?	who knows? but there must be a hundred new ones every day.
who knows? but there must be a hundred new ones every day.	yes, just in english alone.
yes, just in english alone.	i wonder if every language has jokes.
i wonder if every language has jokes.	of course! people everywhere like good jokes.
of course! people everywhere like good jokes.	what do you think people joke about the most?
what do you think people joke about the most?	i think most jokes are about women.
i think most jokes are about women.	oh, really? i think most jokes are about men!
you're very lucky.	why do you say that?
why do you say that?	you speak two languages.
you speak two languages.	well, my english isn't perfect.
well, my english isn't perfect.	no one speaks perfect english.
no one speaks perfect english.	maybe i will be the first!
maybe i will be the first!	i've been thinking about learning spanish.
i've been thinking about learning spanish.	spanish is easy. i'll be happy to teach you.
spanish is easy. i'll be happy to teach you.	how long will it take me to learn?
how long will it take me to learn?	i think it will only take you a year or two.
i think it will only take you a year or two.	how soon can we begin?
how soon can we begin?	ahora! that means right now.
do you know what today is?	yes, it's april 22.
yes, it's april 22.	it's more than just a date.
it's more than just a date.	is it your birthday or anniversary?
is it your birthday or anniversary?	no, it's earth day.
no, it's earth day.	what's that?
what's that?	it's a yearly reminder to take care of our planet.
it's a yearly reminder to take care of our planet.	oh, you mean like reuse things and recycle stuff?
oh, you mean like reuse things and recycle stuff?	yes. we need to think green, save water, and stop using plastic bags.
yes. we need to think green, save water, and stop using plastic bags.	how about if i take shorter showers?
how about if i take shorter showers?	that's a good idea, because showers waste a lot of water.
that's a good idea, because showers waste a lot of water.	from now on i'll spend only 20 minutes in the shower.
poetry sucks.	i don't know anyone who likes it.
i don't know anyone who likes it.	some of it is okay, i guess.
some of it is okay, i guess.	yes, the poems that rhyme and are easy to remember.
yes, the poems that rhyme and are easy to remember.	like "one, two, buckle my shoe."
like "one, two, buckle my shoe."	but people still write poems.
but people still write poems.	no one makes any money at it.
no one makes any money at it.	shakespeare was a poet.
shakespeare was a poet.	did he get rich from his poetry?
did he get rich from his poetry?	probably not.
probably not.	poems are a little bit like songs.
poems are a little bit like songs.	yes, but songs have music. without music, songs would suck, too.
how smart are you?	i don't know. i think i'm average.
i don't know. i think i'm average.	did you ever take an iq test?
did you ever take an iq test?	no, i never did. all i know is that i got a's and b's in school.
no, i never did. all i know is that i got a's and b's in school.	i wish i was really smart.
i wish i was really smart.	don't be ridiculous.
don't be ridiculous.	what do you mean?
what do you mean?	if you're going to make a wish, wish that you were really rich or famous.
if you're going to make a wish, wish that you were really rich or famous.	don't you ever wonder what it's like to be super-smart?
don't you ever wonder what it's like to be super-smart?	it must be very lonely.
it must be very lonely.	why's that?
why's that?	because if you're super-smart, no one understands what you're saying.
i missed the tv news last night. what was on?	nothing that would pass as news.
nothing that would pass as news.	what's the weather going to be like this weekend?
what's the weather going to be like this weekend?	i don't know. whenever the weather comes on, i switch channels.
i don't know. whenever the weather comes on, i switch channels.	what was the lead story on the news?
what was the lead story on the news?	some actress was in court for driving without a license.
some actress was in court for driving without a license.	what was the second story?
what was the second story?	some actor married a woman young enough to be his daughter.
some actor married a woman young enough to be his daughter.	what was the third story?
what was the third story?	a bull chased a man in a supermarket.
a bull chased a man in a supermarket.	wasn't there anything about octo-mom?
wasn't there anything about octo-mom?	of course. she's going to hire a nanny for her eight infants.
what are you going to do about your death?	well, mostly i'll try to avoid it.
well, mostly i'll try to avoid it.	i mean, are you going to get buried or cremated?
i mean, are you going to get buried or cremated?	my wife and i will be cremated.
my wife and i will be cremated.	are you going to be buried next to each other?
are you going to be buried next to each other?	oh, no. our ashes will be shaken into the ocean.
oh, no. our ashes will be shaken into the ocean.	you're not going to be buried?
you're not going to be buried?	a coffin costs too much and takes up too much space.
a coffin costs too much and takes up too much space.	yes, but it will be in a cemetery where your children can visit you.
yes, but it will be in a cemetery where your children can visit you.	children seldom visit their parents in a cemetery.
children seldom visit their parents in a cemetery.	that's true. a cemetery is for dead people, not living people.
that's true. a cemetery is for dead people, not living people.	we figure our kids can visit us whenever they go to the beach.
did you wipe your feet? 	yes, of course i wiped my feet.
yes, of course i wiped my feet.	then why is there mud on the carpet?
then why is there mud on the carpet?	i don't know. it's not my mud.
i don't know. it's not my mud.	well, someone brought it into the house.
well, someone brought it into the house.	look at the bottom of my shoesthey're clean.
look at the bottom of my shoesthey're clean.	of course they're clean. you left all the mud on the carpet.
of course they're clean. you left all the mud on the carpet.	okay, i'll get the vacuum cleaner.
okay, i'll get the vacuum cleaner.	don't vacuum it now.
don't vacuum it now.	don't you want me to clean up the mud?
don't you want me to clean up the mud?	wait till it dries. it will be easier to vacuum.
wait till it dries. it will be easier to vacuum.	next time i will be more careful.
what are you getting for your mom?	what are you talking about?
what are you talking about?	sunday is mother's day.
sunday is mother's day.	this sunday?
this sunday?	of course. it's all over the news.
of course. it's all over the news.	i thought it was next sunday.
i thought it was next sunday.	well, you'd better get her something.
well, you'd better get her something.	i'll get her a nice card.
i'll get her a nice card.	is that it?
is that it?	yes. that's all i ever give her.
yes. that's all i ever give her.	she raised you, and all you ever give her is a card?
she raised you, and all you ever give her is a card?	it's okay. she knows that i love her.
i don't like our flag.	what's the matter with it?
what's the matter with it?	it's too much like other flags.
it's too much like other flags.	yes, a lot of flags have stripes.
yes, a lot of flags have stripes.	a flag should be pretty.
a flag should be pretty.	what should our flag look like?
what should our flag look like?	it should have a pretty woman on it.
it should have a pretty woman on it.	that's ridiculous!
that's ridiculous!	you don't like pretty women?
you don't like pretty women?	of course i do. but not on our flag!
of course i do. but not on our flag!	every nation should have a pretty woman on their flag.
every nation should have a pretty woman on their flag.	you can't go to war carrying a flag with a woman on it!
i had a busy morning.	what did you do?
what did you do?	i watered all the plants.
i watered all the plants.	you have a lot of plants.
you have a lot of plants.	then i did my laundry.
then i did my laundry.	that takes some time.
that takes some time.	i took the dog for a walk.
i took the dog for a walk.	i'll bet he enjoyed his walk.
i'll bet he enjoyed his walk.	i vacuumed the entire house.
i vacuumed the entire house.	that's a lot of work.
that's a lot of work.	and then i made lunch.
and then i made lunch.	i'll bet you were hungry!
i don't have long distance service with my home phone.	so how do you make long distance calls?
so how do you make long distance calls?	i use a calling card.
i use a calling card.	where do you get that?
where do you get that?	i buy it at the dollar store.
i buy it at the dollar store.	how much is it?
how much is it?	it's one dollar for 100 minutes.
it's one dollar for 100 minutes.	that's only a penny a minute!
that's only a penny a minute!	it's a great price. but you have to dial a lot of numbers.
it's a great price. but you have to dial a lot of numbers.	how many?
how many?	first you dial seven numbers, then ten numbers, then ten more numbers.
first you dial seven numbers, then ten numbers, then ten more numbers.	yikes. i think i'll keep my long distance service.
do you go to college?	yes, i do.
yes, i do.	what college do you go to?
what college do you go to?	i go to pasadena city college.
i go to pasadena city college.	do you like it?
do you like it?	oh, yes, i really like it.
oh, yes, i really like it.	why do you like it?
why do you like it?	because it has great teachers.
because it has great teachers.	what else?
what else?	i like all my classmates, too.
i like all my classmates, too.	anything else?
anything else?	yes. it's not expensive!
i lost my new pen.	where did you lose it?
where did you lose it?	i don't know.
i don't know.	when did you lose it?
when did you lose it?	i think i lost it today. i used it yesterday.
i think i lost it today. i used it yesterday.	did you check all your pockets?
did you check all your pockets?	i checked all my pockets.
i checked all my pockets.	did you look in your desk?
did you look in your desk?	yes. it isn't there, either.
yes. it isn't there, either.	it's probably around somewhere.
it's probably around somewhere.	oh, well, it only cost me a dollar.
oh, well, it only cost me a dollar.	only a dollar? don't even look for it.
gravity is very important.	what is gravity?
what is gravity?	it's the force that pulls everything down.
it's the force that pulls everything down.	i don't understand.
i don't understand.	if you pour water into a glass, the water goes down into the glass.
if you pour water into a glass, the water goes down into the glass.	of course it does.
of course it does.	without gravity, the water would go up.
without gravity, the water would go up.	you're joking.
you're joking.	without gravity, you would go up.
without gravity, you would go up.	what do you mean?
what do you mean?	you would float into the sky like a balloon.
you would float into the sky like a balloon.	that would be fun!
i can't read my book.	turn on the light.
turn on the light.	the light is on.
the light is on.	open the book.
open the book.	the book is open.
the book is open.	see an eye doctor.
see an eye doctor.	that's what i need to do.
that's what i need to do.	he'll give you a prescription for glasses.
he'll give you a prescription for glasses.	i'll make an appointment tomorrow.
i'll make an appointment tomorrow.	i'll get the yellow pages for an eye doctor.
i'll get the yellow pages for an eye doctor.	read the phone number to me.
read the phone number to me.	i'll read it very loud, in case your hearing is getting bad, too.
what do you need for school?	i need pencils.
i need pencils.	anything else?
anything else?	i need a notebook.
i need a notebook.	do you need a pen?
do you need a pen?	no. i already have a pen.
no. i already have a pen.	do you need a calculator?
do you need a calculator?	no. the teacher doesn't permit calculators.
no. the teacher doesn't permit calculators.	how about a dictionary?
how about a dictionary?	no, we have a big dictionary in the classroom.
no, we have a big dictionary in the classroom.	well, i guess that's it.
well, i guess that's it.	yes, that's all i need for now.
i like this magazine.	so do i.
so do i.	i read it once, and i subscribed.
i read it once, and i subscribed.	it gives you all the news.
it gives you all the news.	all the news in only 50 pages.
all the news in only 50 pages.	i like the political cartoons.
i like the political cartoons.	i like the beautiful photos of the houses for sale.
i like the beautiful photos of the houses for sale.	i always read the film reviews.
i always read the film reviews.	i never miss the food and drink section.
i never miss the food and drink section.	i gave a subscription to my parents.
i gave a subscription to my parents.	me too. they canceled their other news magazines.
me too. they canceled their other news magazines.	so did mine!
my pen is out of ink.	shake it a couple of times.
shake it a couple of times.	i shook it. there is no more ink.
i shook it. there is no more ink.	you can borrow mine.
you can borrow mine.	thank you. i'll buy a new one tomorrow.
thank you. i'll buy a new one tomorrow.	what were you doing?
what were you doing?	i was writing a letter.
i was writing a letter.	who were you writing to?
who were you writing to?	it's to my mom.
it's to my mom.	tell her i said hello.
tell her i said hello.	okay. i'll return your pen when i'm done.
okay. i'll return your pen when i'm done.	take your time.
have you done your homework?	not yet.
not yet.	then why are you watching tv?
then why are you watching tv?	this is my favorite show.
this is my favorite show.	go do your homework.
go do your homework.	but, mom!
but, mom!	you can watch tv after you do your homework.
you can watch tv after you do your homework.	but the show will be over.
but the show will be over.	there will be another show next week.
there will be another show next week.	please?
please?	you know the rules.
you know the rules.	i hate the rules! i can't wait till i grow up.
i can't wait until i graduate.	me too.
me too.	no more homework.
no more homework.	i hate homework.
i hate homework.	are you going to college?
are you going to college?	i can't afford it.
i can't afford it.	me neither.
me neither.	so what are you going to do?
so what are you going to do?	i'm joining the army.
i'm joining the army.	you're kidding. you might get killed.
you're kidding. you might get killed.	i don't think so. after i finish, i'll have enough money to go to college.
i don't think so. after i finish, i'll have enough money to go to college.	that's not a bad idea.
what is your major?	english.
english.	what are you going to do with an english major?
what are you going to do with an english major?	i'm going to be a teacher.
i'm going to be a teacher.	high school or middle school?
high school or middle school?	high school.
high school.	i teach high school english.
i teach high school english.	i didn't know that.
i didn't know that.	i started teaching five years ago.
i started teaching five years ago.	how do you like it?
how do you like it?	do you see all this gray hair? it was totally black five years ago.
do you see all this gray hair? it was totally black five years ago.	maybe i'll teach middle school.
parking at school is impossible.	i'll say.
i'll say.	i drove around for half an hour.
i drove around for half an hour.	did you find a spot?
did you find a spot?	i found a spot, but someone cut in and took it from me.
i found a spot, but someone cut in and took it from me.	did you yell at them?
did you yell at them?	yes, i did.
yes, i did.	and?
and?	and he yelled back at me.
and he yelled back at me.	how rude.
how rude.	but i got lucky a few minutes later.
but i got lucky a few minutes later.	you have to be lucky to find a parking space.
this is a huge library.	yes, it has lots of rooms and lots of space.
yes, it has lots of rooms and lots of space.	and lots of books.
and lots of books.	and lots of thieves.
and lots of thieves.	what do you mean?
what do you mean?	i mean, keep your belongings close to you.
i mean, keep your belongings close to you.	the only thing in my backpack is used books.
the only thing in my backpack is used books.	but thieves don't know that.
but thieves don't know that.	they might think that i've got an ipod or laptop in there.
they might think that i've got an ipod or laptop in there.	now you're thinking.
now you're thinking.	you'd think a library would be safe from thieves.
you'd think a library would be safe from thieves.	not even a church is safe from thieves.
how good is your math?	i can add two and two.
i can add two and two.	so you're not very good at math?
so you're not very good at math?	i'm terrible at math.
i'm terrible at math.	well, i need some help.
well, i need some help.	with what?
with what?	i'm taking a math course in school.
i'm taking a math course in school.	well, you should ask your teacher or your classmates for help.
well, you should ask your teacher or your classmates for help.	i can't do that.
i can't do that.	why not?
why not?	they might think i'm stupid.
they might think i'm stupid.	they're not going to think that! they'll be glad to help you.
do you believe in god?	of course.
of course.	do you pray to god?
do you pray to god?	occasionally.
occasionally.	when's that?
when's that?	when i need something.
when i need something.	like what?
like what?	well, if i have a big test at school.
well, if i have a big test at school.	does god answer your prayers?
does god answer your prayers?	yes, i've passed all my tests.
yes, i've passed all my tests.	do you ever pray for money?
do you ever pray for money?	not yet. i won't need to do that until i graduate from high school.
the cops finally found the husband.	what husband?
what husband?	the husband of the driver who ran over two college students at 3 a.m.
the husband of the driver who ran over two college students at 3 a.m.	oh, yeah. the girl died instantly, and the boy is still in the hospital.
oh, yeah. the girl died instantly, and the boy is still in the hospital.	the husband said he tried to help the boy.
the husband said he tried to help the boy.	yes, he pushed him off the hood of the car.
yes, he pushed him off the hood of the car.	no, he said he gently placed the boy on the street.
no, he said he gently placed the boy on the street.	so what? they still drove off.
so what? they still drove off.	the husband said a fire department was nearby.
the husband said a fire department was nearby.	so what? did he dial 911?
so what? did he dial 911?	he said he was thinking about it, but he didn't get around to it.
he said he was thinking about it, but he didn't get around to it.	he didn't get around to turning himself in, either.
i don't like riding the bus.	why not?
why not?	the seats and windows are dirty.
the seats and windows are dirty.	don't they clean the bus every night?
don't they clean the bus every night?	i think they do.
i think they do.	you should bring some wipes with you.
you should bring some wipes with you.	that's a good idea.
that's a good idea.	then you can wipe your seat and window.
then you can wipe your seat and window.	people will think i'm strange.
people will think i'm strange.	who cares? everyone is strange.
who cares? everyone is strange.	that's for sure.
that's for sure.	don't worry about what people think.
i don't like riding the bus.	why not?
why not?	number one, it's too slow.
number one, it's too slow.	you're right. a car is faster.
you're right. a car is faster.	number two, it's usually late.
number two, it's usually late.	you're right. the buses are never on time.
you're right. the buses are never on time.	number three, it doesn't run 24 hours.
number three, it doesn't run 24 hours.	you're right. buses don't run late at night.
you're right. buses don't run late at night.	number four, it's too crowded.
number four, it's too crowded.	you're right. you have to stand in the aisle.
you're right. you have to stand in the aisle.	number five, it's unsafe.
number five, it's unsafe.	you're right. bad guys might rob you.
we had a problem at school.	what was the problem?
what was the problem?	someone cut the tires.
someone cut the tires.	what tires?
what tires?	the tires on the cars.
the tires on the cars.	where were the cars?
where were the cars?	they were in the student parking lot.
they were in the student parking lot.	how many tires were cut?
how many tires were cut?	one or two tires were cut on each car.
one or two tires were cut on each car.	how many cars?
how many cars?	eleven cars.
eleven cars.	that's terrible. i hope they catch the person.
life isn't fair.	it sure isn't.
it sure isn't.	i got a ticket yesterday.
i got a ticket yesterday.	what for?
what for?	i was crossing the street.
i was crossing the street.	were you in a crosswalk?
were you in a crosswalk?	yes, but the red hand was blinking.
yes, but the red hand was blinking.	so? that's a ticket?
so? that's a ticket?	yes, it's a $140 ticket.
yes, it's a $140 ticket.	that's not right!
that's not right!	when i started to cross the street, the white walk sign was blinking.
when i started to cross the street, the white walk sign was blinking.	you need to walk faster.
you're driving too fast.	why do you say that?
why do you say that?	the speed limit is 65.
the speed limit is 65.	i know that.
i know that.	but you're doing 75.
but you're doing 75.	so is everyone else.
so is everyone else.	but a cop might stop you.
but a cop might stop you.	no, he won't. some cars are doing 85.
no, he won't. some cars are doing 85.	so the cop will stop those cars?
so the cop will stop those cars?	of course. he stops the fastest cars.
of course. he stops the fastest cars.	my friend got a ticket for doing 75.
my friend got a ticket for doing 75.	your friend was unlucky.
remember to put air in your tires.	how often do i have to do that?
how often do i have to do that?	once every two months.
once every two months.	that's a lot.
that's a lot.	what do you mean?
what do you mean?	that's six times a year!
that's six times a year!	yes, and it takes about five minutes each time.
yes, and it takes about five minutes each time.	i'll try.
i'll try.	check your tires or you'll get a flat.
check your tires or you'll get a flat.	oh. that's not good.
oh. that's not good.	no, it isn't. a flat costs you time and money.
no, it isn't. a flat costs you time and money.	and i don't have either.
you're driving too fast.	i'm in a hurry.
i'm in a hurry.	don't ever be in a hurry.
don't ever be in a hurry.	it's not my fault. you didn't wake me up.
it's not my fault. you didn't wake me up.	that's not my fault. you didn't tell me to wake you up.
that's not my fault. you didn't tell me to wake you up.	well, i meant to.
well, i meant to.	don't ever be in a hurry when you're driving.
don't ever be in a hurry when you're driving.	why not?
why not?	because you'll have an accident. most accidents are because people are in a hurry.
because you'll have an accident. most accidents are because people are in a hurry.	how do you know that?
how do you know that?	i read a lot.
i read a lot.	i thought drunks caused most accidents.
let's go for a ride.	where are we going?
where are we going?	into the mountains.
into the mountains.	that sounds nice.
that sounds nice.	i want to show you my new car.
i want to show you my new car.	you bought a new car?
you bought a new car?	yes. i bought a cadillac.
yes. i bought a cadillac.	a luxury car.
a luxury car.	luxury plus speed.
luxury plus speed.	what are we waiting for?
what are we waiting for?	let me get the keys.
let me get the keys.	let me get my camera.
i have to go to the bathroom.	why didn't you go before we left?
why didn't you go before we left?	i did, but i have to go again.
i did, but i have to go again.	well, hold on a little longer.
well, hold on a little longer.	i think i'm going to explode.
i think i'm going to explode.	just hold on.
just hold on.	oh! don't hit any more bumps!
oh! don't hit any more bumps!	we'll be at mcdonald's in just a few minutes.
we'll be at mcdonald's in just a few minutes.	i hope they are fast minutes.
i hope they are fast minutes.	think about something else. think about a hamburger.
think about something else. think about a hamburger.	i'm thinking, but i still have to go.
i'm thinking, but i still have to go.	it's the next exit. hold on!
where's the car?	what do you mean?
what do you mean?	the car isn't here.
the car isn't here.	where did you park it?
where did you park it?	i parked it right here.
i parked it right here.	are you sure?
are you sure?	yes. i remember this big tree.
yes. i remember this big tree.	maybe it's the wrong tree.
maybe it's the wrong tree.	no, this is the tree.
no, this is the tree.	did someone steal it?
did someone steal it?	i sure hope not.
i sure hope not.	maybe they towed it away.
look at this traffic.	i'd rather not.
i'd rather not.	it gets worse every year.
it gets worse every year.	why are you complaining? we're going almost 20 miles an hour.
why are you complaining? we're going almost 20 miles an hour.	the speed limit is 65!
the speed limit is 65!	well, that's between 2:00 and 4:00 a.m.
well, that's between 2:00 and 4:00 a.m.	where are all these people going?
where are all these people going?	they're all asking the same question.
they're all asking the same question.	when are they going to fix this problem?
when are they going to fix this problem?	they said they need more money.
they said they need more money.	they always need more money.
they always need more money.	it'll get worse before it gets better.
did you see that car?	yes, he went through the red light.
yes, he went through the red light.	can we call the police?
can we call the police?	no, the police don't care.
no, the police don't care.	why not?
why not?	they have to see it happen.
they have to see it happen.	they don't believe us?
they don't believe us?	no. they can only give a ticket if they see it happen.
no. they can only give a ticket if they see it happen.	so, what do we do?
so, what do we do?	we don't do anything.
we don't do anything.	maybe we should honk the horn next time.
maybe we should honk the horn next time.	the driver will just honk back at us.
my car is dirty.	why don't you wash it?
why don't you wash it?	that's what i'm going to do.
that's what i'm going to do.	are you going to wash it yourself?
are you going to wash it yourself?	of course. it's not a hard job.
of course. it's not a hard job.	i'll help you.
i'll help you.	okay, i'll get a bucket.
okay, i'll get a bucket.	i'll rinse the car first.
i'll rinse the car first.	then we can scrub it with a wet sponge and soap.
then we can scrub it with a wet sponge and soap.	after that, we can dry it with a towel.
after that, we can dry it with a towel.	then it will look like new
then it will look like new	and you save $10.
it sure is windy today.	paper is flying everywhere.
paper is flying everywhere.	this wind is dangerous for drivers.
this wind is dangerous for drivers.	especially for drivers of big trucks.
especially for drivers of big trucks.	the wind blows those trucks over.
the wind blows those trucks over.	it blows trees over, too.
it blows trees over, too.	a tree fell onto my dad's car.
a tree fell onto my dad's car.	was there much damage?
was there much damage?	my dad had to buy a new car.
my dad had to buy a new car.	wow! that's terrible.
wow! that's terrible.	never park your car under a tree.
never park your car under a tree.	the wind will get you, or the birds will get you.
when are we going to stop?	we'll stop at the next mcdonald's.
we'll stop at the next mcdonald's.	how far away is that?
how far away is that?	i think we'll be there in half an hour.
i think we'll be there in half an hour.	i hope so. i have to go to the bathroom.
i hope so. i have to go to the bathroom.	well, i can always pull over.
well, i can always pull over.	no, thank you, i'll just wait.
no, thank you, i'll just wait.	we can kill two birds with one stone.
we can kill two birds with one stone.	what do you mean?
what do you mean?	while you're using the bathroom, i'll order some food.
while you're using the bathroom, i'll order some food.	don't order for me. i'm not hungry.
don't order for me. i'm not hungry.	i'm very hungry. i'll order for you, and then i'll eat yours.
this is such a long light.	look how many cars are waiting in line.
look how many cars are waiting in line.	they need a left-turn arrow.
they need a left-turn arrow.	only two cars can make a left turn every three or four minutes.
only two cars can make a left turn every three or four minutes.	we'll be here forever.
we'll be here forever.	get out of this lane.
get out of this lane.	but we need to turn left.
but we need to turn left.	forget it. go straight.
forget it. go straight.	then what?
then what?	then we'll just make a u-turn.
then we'll just make a u-turn.	and then we can turn right at the light.
and then we can turn right at the light.	good idea. it will be so much quicker.
i need a cheap car.	how much money do you have?
how much money do you have?	$1,000.
$1,000.	well, that should get you something.
well, that should get you something.	but i need something that's reliable.
but i need something that's reliable.	you need a car with low mileage.
you need a car with low mileage.	a car that was owned by a little old lady.
a car that was owned by a little old lady.	where have you looked?
where have you looked?	i haven't looked anywhere yet.
i haven't looked anywhere yet.	why not?
why not?	because i'll never find one for such a low price.
because i'll never find one for such a low price.	you're right about that. keep saving your money.
good afternoon, officer.	your driver's license and registration, please.
your driver's license and registration, please.	here you go.
here you go.	do you know why i pulled you over?
do you know why i pulled you over?	i have no idea. all of a sudden i heard your siren.
i have no idea. all of a sudden i heard your siren.	you rolled through that stop sign back there.
you rolled through that stop sign back there.	but i stopped!
but i stopped!	no, you didn't. you slowed down, but you didn't come to a full stop.
no, you didn't. you slowed down, but you didn't come to a full stop.	well, nobody else does, so why should i?
well, nobody else does, so why should i?	that's not the attitude of a good driver.
that's not the attitude of a good driver.	but i am a good driver. i've never had a ticket in my life.
but i am a good driver. i've never had a ticket in my life.	well, you've got one now. here. have a nice day.
$140. i can't believe it.	what are you talking about?
what are you talking about?	i got a ticket downtown for $140.
i got a ticket downtown for $140.	were you speeding?
were you speeding?	no, i was crossing the street.
no, i was crossing the street.	were you jaywalking?
were you jaywalking?	no, i was in the crosswalk.
no, i was in the crosswalk.	so why did you get a ticket?
so why did you get a ticket?	the officer said the red hand was blinking.
the officer said the red hand was blinking.	was it blinking when you entered the crosswalk?
was it blinking when you entered the crosswalk?	no, the white walk sign was blinking.
no, the white walk sign was blinking.	you should fight that ticket. i'll be your witness.
they were in a crosswalk near school at 3 a.m.	who?
who?	two students from usc.
two students from usc.	what happened?
what happened?	a speeding car ran a red light, killing the girl.
a speeding car ran a red light, killing the girl.	what happened to the other student?
what happened to the other student?	he landed on the hood of the car.
he landed on the hood of the car.	did he get off the hood?
did he get off the hood?	no, the car stopped and the passenger pushed the injured student off the hood.
no, the car stopped and the passenger pushed the injured student off the hood.	i'll bet the car continued on its way.
i'll bet the car continued on its way.	of course it did. why stop after you've run over two people?
of course it did. why stop after you've run over two people?	i hope they find them and put them in jail for life.
what happened to your car?	i got a dent in the parking lot.
i got a dent in the parking lot.	how did you get it?
how did you get it?	i don't know. maybe it was from a shopping cart.
i don't know. maybe it was from a shopping cart.	those shopping carts are dangerous.
those shopping carts are dangerous.	especially the metal ones.
especially the metal ones.	i don't park at a store that uses metal shopping carts.
i don't park at a store that uses metal shopping carts.	that's a good idea, but there was a good sale at this store.
that's a good idea, but there was a good sale at this store.	did you save any money on the sale?
did you save any money on the sale?	yes, i did. i saved about $50.
yes, i did. i saved about $50.	that's great.
that's great.	yes, except this dent will cost about $150.
did you see "titanic"?	yes. it is a great movie.
yes. it is a great movie.	i saw it twelve times.
i saw it twelve times.	i saw it eight times.
i saw it eight times.	i have the dvd.
i have the dvd.	so do i.
so do i.	let's go to your home.
let's go to your home.	we can watch my dvd.
we can watch my dvd.	and then we can go to my home.
and then we can go to my home.	and watch your dvd.
and watch your dvd.	i always cry at the end.
i always cry at the end.	me too. it's so sad.
let's play cards.	i don't know any card games.
i don't know any card games.	i'll teach you one.
i'll teach you one.	okay. what will you teach me?
okay. what will you teach me?	it's called poker.
it's called poker.	is it easy to learn?
is it easy to learn?	yes, it will only take about 30 minutes.
yes, it will only take about 30 minutes.	okay. teach me how to play.
okay. teach me how to play.	we each get five cards.
we each get five cards.	oh, look. i have four tens.
oh, look. i have four tens.	that's great, but you're not supposed to tell me.
that's great, but you're not supposed to tell me.	oh. sorry. okay, i don't have four tens.
i'm a good card player.	why is that?
why is that?	because i watch the other players.
because i watch the other players.	what do you mean?
what do you mean?	people will tell you if they have a good hand.
people will tell you if they have a good hand.	how do they do that?
how do they do that?	for example, a friend of mine licks his lips.
for example, a friend of mine licks his lips.	when he licks his lips, you know he has a good hand?
when he licks his lips, you know he has a good hand?	i know he has a good hand, so i don't bet.
i know he has a good hand, so i don't bet.	he never wins your money?
he never wins your money?	nope, and it drives him crazy.
nope, and it drives him crazy.	he knows you can't read his mind. maybe he thinks you're cheating.
turn the radio down, please.	but i'm listening to it.
but i'm listening to it.	well, listen to it more quietly.
well, listen to it more quietly.	i can't wait till i grow up.
i can't wait till i grow up.	what will you do?
what will you do?	i will play the radio as loud as i want.
i will play the radio as loud as i want.	that's okay with me.
that's okay with me.	i will have a radio in every room of my house.
i will have a radio in every room of my house.	remind me to never visit you.
remind me to never visit you.	all the radios will be on extra loud.
all the radios will be on extra loud.	your neighbors will hate you.
your neighbors will hate you.	if they don't like it, they can move.
i hope i win the lotto.	your chances are very small.
your chances are very small.	but you can't win if you don't play.
but you can't win if you don't play.	ha! you can't win if you do play.
ha! you can't win if you do play.	someone has to win.
someone has to win.	that's what everyone says.
that's what everyone says.	it might as well be me.
it might as well be me.	that's what everyone says.
that's what everyone says.	you're trying to tell me something.
you're trying to tell me something.	that didn't take long.
that didn't take long.	you think i should quit playing.
you think i should quit playing.	save your money for school.
what's on tv?	nothing much.
nothing much.	what about the baseball game?
what about the baseball game?	it got rained out.
it got rained out.	rained out?
rained out?	yes, rained out.
yes, rained out.	how could that be?
how could that be?	well, you can't play baseball in a rainstorm.
well, you can't play baseball in a rainstorm.	i thought they were playing under a dome.
i thought they were playing under a dome.	the dome doesn't close.
the dome doesn't close.	why doesn't it close?
why doesn't it close?	who knows? they said they'll fix it before next season.
can i try your coffee?	sure. here you go.
sure. here you go.	hmm, that's not bad.
hmm, that's not bad.	there's nothing in it.
there's nothing in it.	what do you mean?
what do you mean?	i mean, it's just coffee.
i mean, it's just coffee.	i figured that.
i figured that.	it's not too bitter for you?
it's not too bitter for you?	it's a little bitter, but it's okay.
it's a little bitter, but it's okay.	there's no sugar or cream in it.
there's no sugar or cream in it.	no, it's a taste you have to get used to.
no, it's a taste you have to get used to.	sort of like beer.
let's take a walk.	what's the weather like?
what's the weather like?	let me step outside and see.
let me step outside and see.	it's a little chilly, right?
it's a little chilly, right?	yes, it is.
yes, it is.	i'll put on my cap.
i'll put on my cap.	wear a jacket, too.
wear a jacket, too.	i wonder if i should bring my gloves.
i wonder if i should bring my gloves.	maybe you should, just in case it gets colder.
maybe you should, just in case it gets colder.	i'll put a glove in each pocket.
i'll put a glove in each pocket.	we'll get warmer as we walk.
we'll get warmer as we walk.	yes, but it gets colder as the sun goes down.
look at the car chase on tv!	that driver is crazy.
that driver is crazy.	i can't believe he hasn't crashed.
i can't believe he hasn't crashed.	how fast is he going?
how fast is he going?	they say he's going 80 miles per hour.
they say he's going 80 miles per hour.	he's going to kill someone.
he's going to kill someone.	look! he just hit that car.
look! he just hit that car.	oh, my goodness. no one is safe on the streets.
oh, my goodness. no one is safe on the streets.	now he's slowing down.
now he's slowing down.	maybe he ran out of gas.
maybe he ran out of gas.	look! he just got out of the car and started running.
look! he just got out of the car and started running.	i hope the police catch him.
tv news is so stupid.	they shouldn't even call it news.
they shouldn't even call it news.	last night they told us about a cat in a sofa.
last night they told us about a cat in a sofa.	yesterday they told us about a dog in a pipe.
yesterday they told us about a dog in a pipe.	last week they told us about a bear in a back yard.
last week they told us about a bear in a back yard.	last month they told us about a mouse in a restaurant.
last month they told us about a mouse in a restaurant.	the weatherman tells us the temperature in every town.
the weatherman tells us the temperature in every town.	the sports guy shows us players fighting.
the sports guy shows us players fighting.	they always tell us "what's next."
they always tell us "what's next."	they always make "what's next" sound exciting, but it never is.
they always make "what's next" sound exciting, but it never is.	it's more like news for kids.
it's more like news for kids.	they should have kid reporters.
i love my computer.	computers are so cool.
computers are so cool.	i love to go online.
i love to go online.	the internet is amazing.
the internet is amazing.	you can travel all over the world.
you can travel all over the world.	i know. i went to china yesterday.
i know. i went to china yesterday.	what did you do?
what did you do?	i stood on the great wall and looked all around.
i stood on the great wall and looked all around.	what was it like?
what was it like?	it was like the real thing.
it was like the real thing.	it was like being there?
it was like being there?	yes, i felt like i was actually there.
the beatles are the best.	they are the best musical group ever.
they are the best musical group ever.	i love all their songs.
i love all their songs.	i don't know which one i like the best.
i don't know which one i like the best.	i like the ones i can sing along with.
i like the ones i can sing along with.	so do i, like "she loves you."
so do i, like "she loves you."	"she loves you, yeah, yeah, yeah!..."
"she loves you, yeah, yeah, yeah!..."	"and you know you should be glad!"
"and you know you should be glad!"	what a great song.
what a great song.	how about "let it be?"
how about "let it be?"	oh, yes! "let it be, let it be"
oh, yes! "let it be, let it be"	"there will be an answer, let it be!"
let's go to a movie.	i'd rather not.
i'd rather not.	why not?
why not?	you know i don't like crowds.
you know i don't like crowds.	let's go to an early movie.
let's go to an early movie.	okay, that won't be very crowded.
okay, that won't be very crowded.	what would you like to see?
what would you like to see?	oh, i don't care. you're the one who wants to go out.
oh, i don't care. you're the one who wants to go out.	well, i want to see "the pursuit of happyness."
well, i want to see "the pursuit of happyness."	what have you heard about it?
what have you heard about it?	it's based on a true story about a divorced man and his young son.
it's based on a true story about a divorced man and his young son.	well, i hope it has a happy ending.
what's your favorite thing to do?	i like to watch people.
i like to watch people.	that's your favorite thing to do?
that's your favorite thing to do?	well, it's one of them.
well, it's one of them.	where do you go to watch people?
where do you go to watch people?	my girlfriend and i sit outside starbucks.
my girlfriend and i sit outside starbucks.	that sounds like a good spot.
that sounds like a good spot.	we watch people walk by with their dogs.
we watch people walk by with their dogs.	i guess you see lots of different dogs.
i guess you see lots of different dogs.	we don't even know what kind most of them are.
we don't even know what kind most of them are.	there are lots of different kinds, but they all have one thing in common.
there are lots of different kinds, but they all have one thing in common.	yes, they love to sniff each other when they meet.
they call him father dollar bill.	yes, he was on the tv news today.
yes, he was on the tv news today.	every easter sunday he gives away money.
every easter sunday he gives away money.	is it his money?
is it his money?	no. movie stars give him money to give to homeless people.
no. movie stars give him money to give to homeless people.	how much money does he give away?
how much money does he give away?	this year he gave away $15,000.
this year he gave away $15,000.	that's a lot of money.
that's a lot of money.	he gave $100 to people in wheelchairs.
he gave $100 to people in wheelchairs.	what about the other homeless people?
what about the other homeless people?	they got $1 each.
they got $1 each.	people stood in line just to get one dollar?!
old movies are the best.	even though they're in black and white.
even though they're in black and white.	a good story is more important than color.
a good story is more important than color.	actors didn't curse back then.
actors didn't curse back then.	and there was no violence.
and there was no violence.	people today don't like that.
people today don't like that.	no, today people like lots of action.
no, today people like lots of action.	i like a good story.
i like a good story.	i like to see actors who are like real people.
i like to see actors who are like real people.	like real people with real problems.
like real people with real problems.	they still make movies like that.
they still make movies like that.	yes, but they never make much money.
do you get pbs on tv?	yes, everybody gets the public broadcasting system.
yes, everybody gets the public broadcasting system.	it puts me to sleep.
it puts me to sleep.	tell me about it.
tell me about it.	a gardening show follows a knitting show.
a gardening show follows a knitting show.	a cooking show follows a sewing show.
a cooking show follows a sewing show.	a travel show follows another travel show.
a travel show follows another travel show.	i'll say! i've gone around the world a dozen times already!
i'll say! i've gone around the world a dozen times already!	now they're adding old tv shows to the old movies.
now they're adding old tv shows to the old movies.	i sure would like to see something interesting for a change.
i sure would like to see something interesting for a change.	if more people donate money, pbs could offer new shows.
if more people donate money, pbs could offer new shows.	who wants to donate? public tv should be free.
i love to watch "judge judy."	is that a tv show?
is that a tv show?	yes. it's on every afternoon.
yes. it's on every afternoon.	what's so good about it?
what's so good about it?	they have interesting lawsuits.
they have interesting lawsuits.	such as?
such as?	yesterday, a woman complained about a cell phone she bought on ebay.
yesterday, a woman complained about a cell phone she bought on ebay.	was something wrong with the phone?
was something wrong with the phone?	it works only in canada.
it works only in canada.	did the seller know that?
did the seller know that?	yes, and he didn't tell the buyer.
yes, and he didn't tell the buyer.	i hope judge judy made the seller take the phone back.
that woman is a very good singer.	yes, but she looks like a man.
yes, but she looks like a man.	what difference does it make?
what difference does it make?	female singers are supposed to be pretty.
female singers are supposed to be pretty.	singers are supposed to sound good.
singers are supposed to sound good.	they should look good, too.
they should look good, too.	there are lots of ugly men singers.
there are lots of ugly men singers.	men singers don't have to look good.
men singers don't have to look good.	then neither do women singers.
then neither do women singers.	well, i would never buy her cd.
well, i would never buy her cd.	but you would buy her cd if she was pretty?
but you would buy her cd if she was pretty?	yes. i would buy all of her cds.
all the tv stations are going to go digital.	yes, that will occur next month.
yes, that will occur next month.	most of them are already broadcasting in digital.
most of them are already broadcasting in digital.	the digital signal is very clear.
the digital signal is very clear.	oh, no, it isn't!
oh, no, it isn't!	what do you mean?
what do you mean?	i can't get a single channel.
i can't get a single channel.	do you have a digital tv?
do you have a digital tv?	of course. but i don't have cable.
of course. but i don't have cable.	you don't need to have cable, but you do need a good antenna.
you don't need to have cable, but you do need a good antenna.	but i have rabbit ears.
but i have rabbit ears.	rabbit ears aren't strong enough. buy a digital antenna.
i've got a date for you.	oh, really?
oh, really?	are you interested?
are you interested?	maybe. what is she like?
maybe. what is she like?	she's got a great personality.
she's got a great personality.	uh-oh. that means that she's fat and ugly.
uh-oh. that means that she's fat and ugly.	she's cute.
she's cute.	okay, so she's not ugly; she's just fat.
okay, so she's not ugly; she's just fat.	she weighs 98 pounds.
she weighs 98 pounds.	okay, she's not fat. so what's the problem with her?
okay, she's not fat. so what's the problem with her?	who said there is a problem with her?
who said there is a problem with her?	the problem is she has no problemsshe's too good for me!
i think you're very pretty.	thank you.
thank you.	would you have dinner with me?
would you have dinner with me?	i would like to.
i would like to.	can i pick you up friday night?
can i pick you up friday night?	what time?
what time?	eight o'clock.
eight o'clock.	that sounds great.
that sounds great.	we'll go to a french restaurant.
we'll go to a french restaurant.	i've never been to a french restaurant.
i've never been to a french restaurant.	i think you'll love the food.
i think you'll love the food.	i'm not going to eat any snails!
you have pretty eyes.	thank you. so do you.
thank you. so do you.	i wish my eyes were blue.
i wish my eyes were blue.	what's the matter with green eyes?
what's the matter with green eyes?	nothing, except my favorite color is blue.
nothing, except my favorite color is blue.	maybe in your next life you'll have blue eyes.
maybe in your next life you'll have blue eyes.	but what if i'm a fish in my next life?
but what if i'm a fish in my next life?	i think some fish have blue eyes.
i think some fish have blue eyes.	i hope i don't come back as a fish.
i hope i don't come back as a fish.	i hope i come back as a cat.
i hope i come back as a cat.	cats have beautiful eyes.
cats have beautiful eyes.	i would love to have blue cat-eyes.
i love you.	i love you, too.
i love you, too.	i loved you the first day i saw you.
i loved you the first day i saw you.	it was love at first sight?
it was love at first sight?	yes, it was love at first sight.
yes, it was love at first sight.	i didn't love you at first.
i didn't love you at first.	i know. i had to chase you for a while.
i know. i had to chase you for a while.	yes, you chased me and then you caught me.
yes, you chased me and then you caught me.	now you're mine forever.
now you're mine forever.	and you're mine forever.
and you're mine forever.	we'll grow old together.
we'll grow old together.	and be happy together.
i'm in love with that girl.	have you told her?
have you told her?	of course not.
of course not.	why not?
why not?	she would laugh at me.
she would laugh at me.	how do you know?
how do you know?	because they always do.
because they always do.	maybe she's different.
maybe she's different.	they're all the same.
they're all the same.	just ask her out to dinner.
just ask her out to dinner.	and then what?
and then what?	and then she'll know that you like her.
give me a hug.	i'm not in the mood.
i'm not in the mood.	what's the matter?
what's the matter?	i saw you looking at that woman.
i saw you looking at that woman.	what woman?
what woman?	you know, that woman with the big boobs.
you know, that woman with the big boobs.	i was not looking at her.
i was not looking at her.	you were, too.
you were, too.	i'm not interested in her.
i'm not interested in her.	then why were you looking at her?
then why were you looking at her?	i was looking at something else.
i was looking at something else.	oh, really? then spend tonight looking at the sofa.
would you like to go on a blind date?	you must be joking.
you must be joking.	no, i'm serious.
no, i'm serious.	i don't want to date a blind woman.
i don't want to date a blind woman.	a blind date doesn't mean that she is blind!
a blind date doesn't mean that she is blind!	what does it mean?
what does it mean?	a blind date is a date with someone you don't know.
a blind date is a date with someone you don't know.	why would i date someone i don't even know?
why would i date someone i don't even know?	to try something new and exciting.
to try something new and exciting.	what if i don't like her?
what if i don't like her?	then you don't date her again.
i have a date tomorrow night.	really? who with?
really? who with?	a girl i met at the market.
a girl i met at the market.	you met a girl at the supermarket?
you met a girl at the supermarket?	she was standing behind me in a really slow line at the checkout counter.
she was standing behind me in a really slow line at the checkout counter.	what did you say to her?
what did you say to her?	i had two pineapples in my cart, and she asked where i had found them.
i had two pineapples in my cart, and she asked where i had found them.	she asked you about your pineapples?
she asked you about your pineapples?	i told her i had gotten the last two on the shelf, but i offered her one of mine.
i told her i had gotten the last two on the shelf, but i offered her one of mine.	that was nice of you.
that was nice of you.	she asked me how she could return the favor, so i asked her out.
she asked me how she could return the favor, so i asked her out.	sometimes a slow line can be a good thing.
did you have a date friday night?	yes, in fact, i did.
yes, in fact, i did.	who did you go out with?
who did you go out with?	a man i met in a coffee shop.
a man i met in a coffee shop.	where did you go?
where did you go?	we went to a nice restaurant.
we went to a nice restaurant.	anywhere else?
anywhere else?	then we went to a jazz club.
then we went to a jazz club.	that sounds like a nice date.
that sounds like a nice date.	yes, it was pleasant.
yes, it was pleasant.	but you won't date him again?
but you won't date him again?	no. he was nice, but there was no chemistry.
i had the worst date the other night.	what happened?
what happened?	first of all, he was half an hour late.
first of all, he was half an hour late.	that's not a good start.
that's not a good start.	then he didn't bother to apologize.
then he didn't bother to apologize.	that's rude.
that's rude.	then he drove too fast to the restaurant.
then he drove too fast to the restaurant.	that's dangerous.
that's dangerous.	i thought about getting out and taking a taxi home.
i thought about getting out and taking a taxi home.	what happened at the restaurant?
what happened at the restaurant?	we had a $40 meal, and he left a $1 tip!
we had a $40 meal, and he left a $1 tip!	i guess you can't go back to that restaurant.
i don't like that man.	why not?
why not?	he's a dirty old man.
he's a dirty old man.	what do you mean?
what do you mean?	he's old enough to be my father, yet he asked me out.
he's old enough to be my father, yet he asked me out.	well, you can't blame a man for asking.
well, you can't blame a man for asking.	he should act his age.
he should act his age.	but a lot of old people are still interested in dating.
but a lot of old people are still interested in dating.	they should find a nice hobby.
they should find a nice hobby.	just wait until you're 50 years old.
just wait until you're 50 years old.	dating will be the furthest thing from my mind.
dating will be the furthest thing from my mind.	that's what you say now. wait till you're 50.
does your girlfriend ever make you angry?	sometimes.
sometimes.	what does she do?
what does she do?	just yesterday, i told her i wouldn't trade her for all the money in the world.
just yesterday, i told her i wouldn't trade her for all the money in the world.	that was a nice thing to say.
that was a nice thing to say.	that's what i thought.
that's what i thought.	what did she say?
what did she say?	she laughed! she didn't believe me.
she laughed! she didn't believe me.	that wasn't very nice of her.
that wasn't very nice of her.	she said that nothing is more important to me than money.
she said that nothing is more important to me than money.	what did you say?
what did you say?	i told her i wouldn't trade her for any other woman in the world.
some people have good noses.	i wish i had a good nose. mine is way too big.
i wish i had a good nose. mine is way too big.	i don't mean good-looking. i mean good-smelling.
i don't mean good-looking. i mean good-smelling.	oh. but that can be a curse.
oh. but that can be a curse.	yes, because you can be too sensitive to odors.
yes, because you can be too sensitive to odors.	i'll say. my girlfriend has a nose like a drug dog.
i'll say. my girlfriend has a nose like a drug dog.	did she catch you using drugs?
did she catch you using drugs?	sort of. she knows whenever i sneak a cigarette.
sort of. she knows whenever i sneak a cigarette.	you don't need a good nose for thatcigarettes stink.
you don't need a good nose for thatcigarettes stink.	but when i sneak just one cigarette in the morning, she can smell it that evening!
but when i sneak just one cigarette in the morning, she can smell it that evening!	boy, that is a good nose.
boy, that is a good nose.	i told her she should apply for a job at customs.
let's go out to eat.	that sounds like fun.
that sounds like fun.	where do you want to go?
where do you want to go?	let me think a minute.
let me think a minute.	i feel like chinese.
i feel like chinese.	that sounds delicious.
that sounds delicious.	i know a good chinese restaurant.
i know a good chinese restaurant.	how far away is it?
how far away is it?	it's only 10 minutes from here.
it's only 10 minutes from here.	do we need reservations?
do we need reservations?	oh, no. we can walk right in.
oh, no. we can walk right in.	let's go now. i'm hungry!
i can't believe how long this line is.	this is a popular restaurant, isn't it?
this is a popular restaurant, isn't it?	yes, but it isn't a fast-food restaurant, is it?
yes, but it isn't a fast-food restaurant, is it?	it's the slowest hamburger in town.
it's the slowest hamburger in town.	that's because they cook it while you wait.
that's because they cook it while you wait.	yes. that's why it's also the best hamburger in town.
yes. that's why it's also the best hamburger in town.	a great burger and great service.
a great burger and great service.	yes, the workers are very polite.
yes, the workers are very polite.	and they're clean.
and they're clean.	i've been coming here for years.
i've been coming here for years.	me too.
me too.	excuse me. they just called my number.
lunch was delicious.	thank you.
thank you.	what kind of soup was that?
what kind of soup was that?	it was tomato soup.
it was tomato soup.	that tasted so good.
that tasted so good.	i put lemon and butter in it.
i put lemon and butter in it.	the sandwich was good, too.
the sandwich was good, too.	everyone likes bacon and tomato sandwiches.
everyone likes bacon and tomato sandwiches.	especially on toast.
especially on toast.	and the pickles were great, too.
and the pickles were great, too.	tomorrow we'll have rice and fish for lunch.
tomorrow we'll have rice and fish for lunch.	i can't wait.
i'm calling the waiter.	what's the matter?
what's the matter?	this steak has too much fat.
this steak has too much fat.	what do you want the waiter to do?
what do you want the waiter to do?	bring me a better steak.
bring me a better steak.	i wouldn't do that.
i wouldn't do that.	why not?
why not?	they will drop the new steak on the floor, step on it, and then spit on it.
they will drop the new steak on the floor, step on it, and then spit on it.	you're crazy.
you're crazy.	then the waiter will give you a big smile as he brings you the new steak.
then the waiter will give you a big smile as he brings you the new steak.	where do you get these crazy ideas?
where do you get these crazy ideas?	i used to cook in a restaurant!
let's leave.	but we just got here.
but we just got here.	did you see the waiter's hands?
did you see the waiter's hands?	no.
no.	he had dirty fingernails.
he had dirty fingernails.	really?
really?	his nails were black!
his nails were black!	that's disgusting.
that's disgusting.	and he poured water into our glasses.
and he poured water into our glasses.	yuck! no water for me.
yuck! no water for me.	i wonder if the cooks' nails are dirty, too.
i wonder if the cooks' nails are dirty, too.	who cares? let's get out of here.
this hot bread is delicious.	i like this restaurant because they give you free bread.
i like this restaurant because they give you free bread.	well, i think we are paying for it.
well, i think we are paying for it.	no. look at the bill when we get it. there's no charge for the bread.
no. look at the bill when we get it. there's no charge for the bread.	it is delicious, especially with butter.
it is delicious, especially with butter.	i think we should just leave after we fill up on the bread.
i think we should just leave after we fill up on the bread.	they probably wouldn't like that.
they probably wouldn't like that.	i'm eating so much bread that i'm getting full.
i'm eating so much bread that i'm getting full.	then stop eating the bread!
then stop eating the bread!	okay, just one more piece. pass the butter, please.
okay, just one more piece. pass the butter, please.	if i owned a restaurant, i would never serve hot bread before the main course.
if i owned a restaurant, i would never serve hot bread before the main course.	that's terrible. i would never go to your restaurant.
is this a clean restaurant?	well, the tables and chairs look okay.
well, the tables and chairs look okay.	okay, let's sit down.
okay, let's sit down.	check out the silverware.
check out the silverware.	it passes inspection.
it passes inspection.	here comes the waiter. see if his hands and nails are clean.
here comes the waiter. see if his hands and nails are clean.	well, the waiter looked clean, so i guess it's okay to eat here.
well, the waiter looked clean, so i guess it's okay to eat here.	you're forgetting about the bathroom.
you're forgetting about the bathroom.	i'm going to just hope that the bathroom is clean.
i'm going to just hope that the bathroom is clean.	you're not going to examine it before we order dinner?
you're not going to examine it before we order dinner?	no, i'd rather not find out that it's dirty, because i'm pretty hungry right now.
no, i'd rather not find out that it's dirty, because i'm pretty hungry right now.	me, too. let's forget about germs and focus on food.
have you seen our waiter?	here he comes now.
here he comes now.	we've been sitting here for almost 10 minutes.
we've been sitting here for almost 10 minutes.	oops, i guess i was wrong. that isn't our waiter.
oops, i guess i was wrong. that isn't our waiter.	we can give him five more minutes, and then leave.
we can give him five more minutes, and then leave.	i'll go up front and talk to the manager.
i'll go up front and talk to the manager.	that's a good idea.
that's a good idea.	maybe they'll give us free drinks for waiting so long.
maybe they'll give us free drinks for waiting so long.	maybe he'll send us our waiter immediately.
maybe he'll send us our waiter immediately.	every time we eat out, it's an adventure.
every time we eat out, it's an adventure.	last time, we got seats next to the kitchen.
last time, we got seats next to the kitchen.	we'll never go there again.
is this table okay?	no, it's too close to the kitchen door.
no, it's too close to the kitchen door.	how about this table?
how about this table?	no, it's too close to the front door.
no, it's too close to the front door.	this looks like a nice table.
this looks like a nice table.	no, it's too close to the salad bar.
no, it's too close to the salad bar.	okay, i give up.
okay, i give up.	well, there is one good table.
well, there is one good table.	great. which one?
great. which one?	that one. a group of eight just sat down at it.
i don't believe the art world.	what is it this time?
what is it this time?	an andy warhol drawing.
an andy warhol drawing.	he's a famous artist.
he's a famous artist.	he drew two butterflies and a flower on a napkin in a restaurant.
he drew two butterflies and a flower on a napkin in a restaurant.	did he sign it?
did he sign it?	yes.
yes.	is it beautiful?
is it beautiful?	it's just black ink on a white napkin. and the napkin has food stains!
it's just black ink on a white napkin. and the napkin has food stains!	so it's not worth much?
so it's not worth much?	only about $30,000.
only about $30,000.	without the food stains, it would probably be worth more.
can we go to the baseball game?	of course.
of course.	i love baseball.
i love baseball.	so do i.
so do i.	i love to eat the peanuts.
i love to eat the peanuts.	i love to eat the hot dogs.
i love to eat the hot dogs.	i hope we'll see a home run.
i hope we'll see a home run.	i hope we'll catch a foul ball.
i hope we'll catch a foul ball.	bring a jacket.
bring a jacket.	yes. it gets a little cool at night.
yes. it gets a little cool at night.	bring a glove to catch a foul ball.
bring a glove to catch a foul ball.	no. i'll just use my cap to catch a foul ball.
golf is a silly game.	it certainly is.
it certainly is.	you hit a white ball.
you hit a white ball.	and then you chase it.
and then you chase it.	and then you hit it again.
and then you hit it again.	finally, you put the ball into a hole in the ground.
finally, you put the ball into a hole in the ground.	you do this 18 times, because there are 18 holes.
you do this 18 times, because there are 18 holes.	what's the point?
what's the point?	how can it be fun?
how can it be fun?	they pay money to play this silly game!
they pay money to play this silly game!	i think golfers have a mental problem.
i think golfers have a mental problem.	i think they're nuts.
do you want to go fishing?	yes. that's a good idea.
yes. that's a good idea.	where do you want to go?
where do you want to go?	we can go to the river.
we can go to the river.	or we can go to the lake.
or we can go to the lake.	or we can go to the ocean.
or we can go to the ocean.	let's go to the lake.
let's go to the lake.	yes. the lake is only 10 miles away.
yes. the lake is only 10 miles away.	we can be there in 20 minutes.
we can be there in 20 minutes.	i'll get our fishing rods.
i'll get our fishing rods.	i'll get the bait.
i'll get the bait.	we'll have fresh fish for dinner!
baseball is fun.	i like to hit the ball.
i like to hit the ball.	i like to run around the bases.
i like to run around the bases.	i like to slide into the bases.
i like to slide into the bases.	yeah. it's a lot of fun to slide.
yeah. it's a lot of fun to slide.	i want to be a baseball player when i grow up.
i want to be a baseball player when i grow up.	me too. i want to play for the yankees.
me too. i want to play for the yankees.	not me. i want to play for the dodgers.
not me. i want to play for the dodgers.	we have to practice every day.
we have to practice every day.	i don't like practice.
i don't like practice.	me neither. it's boring.
me neither. it's boring.	but practice makes perfect.
let's go jogging.	that's a good idea.
that's a good idea.	i bought some new shoes.
i bought some new shoes.	are they comfortable?
are they comfortable?	they're very comfortable.
they're very comfortable.	how much were they?
how much were they?	they were on sale for $80.
they were on sale for $80.	do they help you run faster?
do they help you run faster?	no, but my feet don't hurt anymore.
no, but my feet don't hurt anymore.	then they're worth every penny.
then they're worth every penny.	you might want to buy a pair.
you might want to buy a pair.	i'll wait until i wear this pair out.
tiger is the greatest golfer in the world.	you can say that again.
you can say that again.	but i'm worried about tiger.
but i'm worried about tiger.	why is that?
why is that?	because he likes to scuba dive.
because he likes to scuba dive.	what's wrong with that?
what's wrong with that?	it can be dangerous.
it can be dangerous.	you mean he could drown.
you mean he could drown.	he shouldn't scuba dive until he retires.
he shouldn't scuba dive until he retires.	but he dives to relax.
but he dives to relax.	he might relax, but it makes me nervous.
he might relax, but it makes me nervous.	if his wife doesn't mind, you shouldn't mind.
did you watch that golf tournament?	the one that tiger won?
the one that tiger won?	how did he do it?
how did he do it?	it was nothing for him.
it was nothing for him.	he sank a 20-foot putt on the last hole to win by one stroke!
he sank a 20-foot putt on the last hole to win by one stroke!	he sank a 25-footer last year at the same tournament to win by one stroke.
he sank a 25-footer last year at the same tournament to win by one stroke.	i think he is from outer space.
i think he is from outer space.	no human could possibly play golf that well.
no human could possibly play golf that well.	whenever he needs a shot to win a tournament, he makes that shot.
whenever he needs a shot to win a tournament, he makes that shot.	no human can do that.
no human can do that.	somebody should check his birth record.
somebody should check his birth record.	i bet it says he was born on mars.
who's the greatest baseball player?	there are so many great players.
there are so many great players.	yes, but who is the greatest?
yes, but who is the greatest?	i'd have to say babe ruth.
i'd have to say babe ruth.	most people would say that.
most people would say that.	he changed the game.
he changed the game.	yes, he made the home run popular.
yes, he made the home run popular.	everybody loved him, all over the nation.
everybody loved him, all over the nation.	he helped make the yankees the best team ever.
he helped make the yankees the best team ever.	and ruth was a good person, too.
and ruth was a good person, too.	he always visited hospitals to cheer up sick kids.
he always visited hospitals to cheer up sick kids.	there will never be another babe.
did you hear what happened at the baseball game?	no, please tell me.
no, please tell me.	someone punched out someone.
someone punched out someone.	that's not nice.
that's not nice.	it's worse than that.
it's worse than that.	how so?
how so?	two guys got into an argument.
two guys got into an argument.	i'll bet they were drinking.
i'll bet they were drinking.	a third guy punched one of the two guys.
a third guy punched one of the two guys.	i'll bet he was drinking, too.
i'll bet he was drinking, too.	the victim hit his head on the concrete steps and died.
the victim hit his head on the concrete steps and died.	that's terrible. can't people just have fun at a baseball game?
i want to go to the ball game.	is there a game tonight?
is there a game tonight?	yes, it starts at 7 p.m.
yes, it starts at 7 p.m.	can we get tickets?
can we get tickets?	yes, but only the cheap tickets.
yes, but only the cheap tickets.	how much are they?
how much are they?	they're only $5 each.
they're only $5 each.	that's a good price.
that's a good price.	yes, it's cheaper than a hot dog or a beer.
yes, it's cheaper than a hot dog or a beer.	where are the seats?
where are the seats?	they're behind the outfield.
they're behind the outfield.	maybe we can catch a home run ball.
golf is so hard.	what's so hard about hitting a little white ball?
what's so hard about hitting a little white ball?	it's hard if you want to do it right.
it's hard if you want to do it right.	you mean like tiger?
you mean like tiger?	no, like a good amateur golfer.
no, like a good amateur golfer.	what's so hard about golf?
what's so hard about golf?	there are so many things you have to do right.
there are so many things you have to do right.	like what?
like what?	like keep your left arm straight, keep your head down, and follow through.
like keep your left arm straight, keep your head down, and follow through.	yikes! who can remember all that?
yikes! who can remember all that?	you need to get a lot of lessons when you're really young.
you need to get a lot of lessons when you're really young.	forget it. golf sounds more like work than fun.
did you hear about the ball player?	the home run hitter on drugs?
the home run hitter on drugs?	he said a doctor helped him with a personal problem.
he said a doctor helped him with a personal problem.	he said he wasn't using drugs.
he said he wasn't using drugs.	he apologized to the fans.
he apologized to the fans.	the league suspended him for 50 games.
the league suspended him for 50 games.	that will cost him some money.
that will cost him some money.	yes, about $7 million.
yes, about $7 million.	that will teach him a good lesson.
that will teach him a good lesson.	he probably won't use drugs anymore.
he probably won't use drugs anymore.	but it won't stop other players from using drugs.
but it won't stop other players from using drugs.	no. everyone always figures that they won't get caught.
why is there so much crime?	because parents don't teach their kids right from wrong.
because parents don't teach their kids right from wrong.	is that it?
is that it?	also, there aren't enough police.
also, there aren't enough police.	but there are a lot of police.
but there are a lot of police.	there's only one police officer per 100 criminals.
there's only one police officer per 100 criminals.	can't we hire more police?
can't we hire more police?	no. it costs too much money.
no. it costs too much money.	doesn't crime cost more than police?
doesn't crime cost more than police?	yes, it does.
yes, it does.	so it would be cheaper to hire more police?
so it would be cheaper to hire more police?	yes, it would.
this is a great neighborhood.	yes, it is.
yes, it is.	people are friendly.
people are friendly.	yes, they are.
yes, they are.	the streets and sidewalks are clean.
the streets and sidewalks are clean.	yes, they are.
yes, they are.	there's a real nice park nearby.
there's a real nice park nearby.	yes, there is.
yes, there is.	i feel safe here.
i feel safe here.	there is no crime here.
there is no crime here.	i wish i could move here.
i wish i could move here.	maybe you can, if someone moves out.
the house burned down.	what happened?
what happened?	the man fell asleep.
the man fell asleep.	was he smoking?
was he smoking?	yes, he was smoking a cigarette.
yes, he was smoking a cigarette.	did he die?
did he die?	yes, he did. his cat died, too.
yes, he did. his cat died, too.	that's too bad. what about his smoke alarm?
that's too bad. what about his smoke alarm?	the battery was dead.
the battery was dead.	a good battery would have saved his life.
a good battery would have saved his life.	he had cigarettes, but no battery.
he had cigarettes, but no battery.	it happens all the time.
they say he has started fifteen big fires.	he's been in jail three times already.
he's been in jail three times already.	why did they ever let him out?
why did they ever let him out?	it's the law. they can't keep him in jail forever.
it's the law. they can't keep him in jail forever.	why not? everyone knows he's a firebug. he loves to start fires.
why not? everyone knows he's a firebug. he loves to start fires.	i don't know. sometimes the law doesn't make sense.
i don't know. sometimes the law doesn't make sense.	but his latest fire killed someone.
but his latest fire killed someone.	this time they have charged him with murder.
this time they have charged him with murder.	so maybe he'll go to jail forever?
so maybe he'll go to jail forever?	i sure hope so.
i sure hope so.	someone should set him on fire.
someone should set him on fire.	that would teach him a good lesson.
put your seatbelt on.	why?
why?	because it will protect you in case of an accident.
because it will protect you in case of an accident.	but it's uncomfortable.
but it's uncomfortable.	it's the law.
it's the law.	it's so much trouble.
it's so much trouble.	it's common sense.
it's common sense.	it's so tight that it's hard for me to breathe.
it's so tight that it's hard for me to breathe.	hold your breath till we get there.
hold your breath till we get there.	okay, my seatbelt is on.
okay, my seatbelt is on.	i'm glad you don't complain very much.
i'm glad you don't complain very much.	i'm ready for an accident.
what are you doing?	i'm going to change the light bulb. it burnt out.
i'm going to change the light bulb. it burnt out.	what are you standing on?
what are you standing on?	a couple of dictionaries and some textbooks.
a couple of dictionaries and some textbooks.	are you crazy?
are you crazy?	what's the matter?
what's the matter?	those books will slip and you'll fall.
those books will slip and you'll fall.	it's only a couple of feet.
it's only a couple of feet.	what if you fall while you're holding the light bulb, and it breaks and pieces go into your eyes?
what if you fall while you're holding the light bulb, and it breaks and pieces go into your eyes?	i never thought about that.
i never thought about that.	you'd be blind for the rest of your life!
you'd be blind for the rest of your life!	i'll get the stepladder.
did you see that puddle of water on the floor?	yes. i called for a clean-up.
yes. i called for a clean-up.	a puddle of water is very dangerous.
a puddle of water is very dangerous.	it isn't easy to see.
it isn't easy to see.	but it's real easy to slip on.
but it's real easy to slip on.	especially on these slick floors.
especially on these slick floors.	someone who slips could hurt their back.
someone who slips could hurt their back.	they could even crack their head open.
they could even crack their head open.	we should stand here till the clean-up person gets here.
we should stand here till the clean-up person gets here.	we can leave if we put an orange cone here.
we can leave if we put an orange cone here.	yes, but i don't know where the orange cones are.
yes, but i don't know where the orange cones are.	 it doesn't matter. here he comes now with the mop.
what happens when the fire alarm rings?	we tell our students to leave the classroom.
we tell our students to leave the classroom.	can they take their belongings?
can they take their belongings?	yes, if they do it quickly.
yes, if they do it quickly.	where do the students go?
where do the students go?	they go out to the north parking lot.
they go out to the north parking lot.	what do the teachers do?
what do the teachers do?	we take our rosters to the parking lot and take roll.
we take our rosters to the parking lot and take roll.	why do you do that?
why do you do that?	we want to make sure all the students are out of the building.
we want to make sure all the students are out of the building.	if they are all outside, then what?
if they are all outside, then what?	then we just wait outside for a fireman to tell us to go back in.
i have to go back upstairs.	why? we're already late.
why? we're already late.	i have to check the stove.
i have to check the stove.	what's the matter?
what's the matter?	maybe i left the burner on.
maybe i left the burner on.	no, you didn't. i checked the stove before we left.
no, you didn't. i checked the stove before we left.	are you sure?
are you sure?	of course i'm sure.
of course i'm sure.	well, i have to go back upstairs anyway.
well, i have to go back upstairs anyway.	it's getting later every minute.
it's getting later every minute.	i think i left the water running.
i think i left the water running.	no, you didn't. let's go! the only thing running is the clock!
the city is buying guns.	what are they paying?
what are they paying?	up to $200 for each gun, no questions asked.
up to $200 for each gun, no questions asked.	why are they doing this?
why are they doing this?	they want to get guns off the street.
they want to get guns off the street.	who would turn in a gun for $200?
who would turn in a gun for $200?	that isn't a good deal?
that isn't a good deal?	a good gun costs $400 or more.
a good gun costs $400 or more.	well, if you bring your receipt, maybe they'll give you $400.
well, if you bring your receipt, maybe they'll give you $400.	i'll keep my receipt and my gun.
i'll keep my receipt and my gun.	i didn't know you had a gun.
i didn't know you had a gun.	everyone in america should have a gun.
you're yawning.	i sure am.
i sure am.	you should go to bed.
you should go to bed.	i will as soon as i finish this article.
i will as soon as i finish this article.	what are you reading?
what are you reading?	it's about crime in los angeles.
it's about crime in los angeles.	what does it say?
what does it say?	the mayor says the crime rate is going down.
the mayor says the crime rate is going down.	then why does everyone lock their doors?
then why does everyone lock their doors?	i guess they haven't read this article.
i guess they haven't read this article.	no one believes that the crime rate is going down.
no one believes that the crime rate is going down.	maybe the mayor is just talking about his own neighborhood.
people who live in california are crazy.	why is that?
why is that?	because of all the earthquakes and fires.
because of all the earthquakes and fires.	but big earthquakes happen only once in a while.
but big earthquakes happen only once in a while.	once in a while is once too many.
once in a while is once too many.	but you're right. there are a lot of fires.
but you're right. there are a lot of fires.	a recent fire destroyed 85 homes.
a recent fire destroyed 85 homes.	still, it's safer than florida.
still, it's safer than florida.	florida doesn't have earthquakes or fires.
florida doesn't have earthquakes or fires.	no, florida just has hurricanes every year from june to october.
no, florida just has hurricanes every year from june to october.	but most of those hurricanes are harmless.
but most of those hurricanes are harmless.	excuse me. hurricane andrew destroyed 30,000 homes!
i went to hawaii on vacation.	did you like it?
did you like it?	i loved it. i want to live there.
i loved it. i want to live there.	what did you like?
what did you like?	the island is so green, and the water is so blue.
the island is so green, and the water is so blue.	did you go swimming?
did you go swimming?	i went to the beach every day.
i went to the beach every day.	how was the weather?
how was the weather?	it was hot and sunny every day.
it was hot and sunny every day.	what did you do at night?
what did you do at night?	at night i went out to eat. the food was delicious.
at night i went out to eat. the food was delicious.	people who live in hawaii are lucky.
i like this hotel.	what do you like about it?
what do you like about it?	we get a free breakfast.
we get a free breakfast.	coffee and a roll?
coffee and a roll?	no, a real breakfast.
no, a real breakfast.	bacon and eggs?
bacon and eggs?	with toast, ham, sausage, fresh fruit, and juice.
with toast, ham, sausage, fresh fruit, and juice.	wow! that is nice. let's stay for two nights.
wow! that is nice. let's stay for two nights.	and the rooms are clean, too.
and the rooms are clean, too.	do they allow pets?
do they allow pets?	no pets, no smoking.
no pets, no smoking.	i like that. let's stay three nights.
i'm not sleeping here tonight.	what's the matter? this is a nice room.
what's the matter? this is a nice room.	maybe the room is nice, but not the bed.
maybe the room is nice, but not the bed.	what's wrong with the bed?
what's wrong with the bed?	look at this sheet.
look at this sheet.	yes?
yes?	see those stains?
see those stains?	i sure do.
i sure do.	i'm not sleeping on that sheet.
i'm not sleeping on that sheet.	well, just call the front desk. they'll give us new sheets.
well, just call the front desk. they'll give us new sheets.	i want sheets without stains on them.
i want sheets without stains on them.	from now on, let's bring our own sheets.
what time does your plane leave?	it leaves at 12:15.
it leaves at 12:15.	when do you have to be at the airport?
when do you have to be at the airport?	i have to be there two hours early.
i have to be there two hours early.	so we have to be at the airport at 10:15.
so we have to be at the airport at 10:15.	that means we have to leave the house at 9:15.
that means we have to leave the house at 9:15.	well, it's an hour to get there, if there are no traffic problems.
well, it's an hour to get there, if there are no traffic problems.	so maybe we better leave at 8:15?
so maybe we better leave at 8:15?	yes, it's better to get there too early than too late.
yes, it's better to get there too early than too late.	i agree.
i agree.	you never know what might happen on these freeways.
you never know what might happen on these freeways.	there's at least one huge accident every day.
i need to fly to new york.	when are you going?
when are you going?	during the christmas holidays.
during the christmas holidays.	you'd better buy your ticket now.
you'd better buy your ticket now.	you must be kidding.
you must be kidding.	no, i'm not. it's march. time is running out. seats are selling out right now.
no, i'm not. it's march. time is running out. seats are selling out right now.	i thought i would wait until october.
i thought i would wait until october.	i'll bet this is the first time you've ever flown during christmas.
i'll bet this is the first time you've ever flown during christmas.	you're right.
you're right.	well, listen to me. you need to buy a ticket now.
well, listen to me. you need to buy a ticket now.	but maybe prices will be cheaper in october.
but maybe prices will be cheaper in october.	cheaper prices won't do you any good if there are no seats.
i hate flying.	so do i.
so do i.	a long time ago, flying used to be okay.
a long time ago, flying used to be okay.	now it's like riding a bus.
now it's like riding a bus.	you're jammed in with people all around you.
you're jammed in with people all around you.	half of them are coughing, and the other half are sneezing.
half of them are coughing, and the other half are sneezing.	you don't have any elbow room or knee room.
you don't have any elbow room or knee room.	people are always getting up to use the bathroom.
people are always getting up to use the bathroom.	kids are crying or climbing over you.
kids are crying or climbing over you.	it's a flying zoo!
it's a flying zoo!	i wish i could afford first class seats.
i wish i could afford first class seats.	doesn't everybody?
some guy rowed across the atlantic ocean.	good for him.
good for him.	why would he do that?
why would he do that?	did he set a new record?
did he set a new record?	yes, i think he did.
yes, i think he did.	well, i guess that's why he did it.
well, i guess that's why he did it.	what's the point?
what's the point?	now he has the world record!
now he has the world record!	but someone's going to break it, so what good is it?
but someone's going to break it, so what good is it?	well, he can enjoy it while it lasts.
well, he can enjoy it while it lasts.	i don't think he even got paid for it.
i don't think he even got paid for it.	some people do it just to do it.
i want to go on a cruise ship.	that sounds like fun. where do you want to go?
that sounds like fun. where do you want to go?	i want to cruise to hawaii.
i want to cruise to hawaii.	that should be a nice trip. lots of fun, and lots of food.
that should be a nice trip. lots of fun, and lots of food.	i have no idea how much it will cost.
i have no idea how much it will cost.	i think it depends on the season and on your cabin.
i think it depends on the season and on your cabin.	well, of course i want to go when the weather is nice.
well, of course i want to go when the weather is nice.	yes, you don't want to travel in winter storms.
yes, you don't want to travel in winter storms.	and i want to get a big cabin with a view.
and i want to get a big cabin with a view.	are you going to travel alone?
are you going to travel alone?	no, my sister and i will travel together.
no, my sister and i will travel together.	well, you should go online and try to find a good deal.
i hate to fly.	because of all the security?
because of all the security?	no, because it hurts my ears.
no, because it hurts my ears.	what do you mean?
what do you mean?	every time we land or take off, my ears hurt so much.
every time we land or take off, my ears hurt so much.	that's just the altitude change, i think.
that's just the altitude change, i think.	whatever it is, it hurts.
whatever it is, it hurts.	can't you take medicine or something for it?
can't you take medicine or something for it?	i've tried everything, but nothing works.
i've tried everything, but nothing works.	have you tried earplugs?
have you tried earplugs?	they don't work, either.
they don't work, either.	well, be glad you're not a pilot.
spring break starts tomorrow.	are you going to go anywhere?
are you going to go anywhere?	i was thinking of driving to arizona.
i was thinking of driving to arizona.	to the grand canyon?
to the grand canyon?	yes. i've never been there.
yes. i've never been there.	i was there when i was a kid.
i was there when i was a kid.	how did you like it?
how did you like it?	i loved it. i still remember how amazing it was.
i loved it. i still remember how amazing it was.	i'm sure i'll like it, too.
i'm sure i'll like it, too.	you should try riding a mule on a trail to the bottom.
you should try riding a mule on a trail to the bottom.	no way! i don't want to fall to my death.
no way! i don't want to fall to my death.	don't worry. only one person has ever fallen off a mule.
that hotel was terrible.	the worst in the whole world.
the worst in the whole world.	the walls were so thin.
the walls were so thin.	all day long we heard tvs or telephones.
all day long we heard tvs or telephones.	all night long we heard people snoring.
all night long we heard people snoring.	housekeeping didn't give us fresh towels.
housekeeping didn't give us fresh towels.	room service brought us a cold dinner.
room service brought us a cold dinner.	our nonsmoking room stunk of cigarette smoke.
our nonsmoking room stunk of cigarette smoke.	our room was right next to the elevator and the ice machine.
our room was right next to the elevator and the ice machine.	they added phony charges to our bill.
they added phony charges to our bill.	how did we end up in that terrible hotel?
how did we end up in that terrible hotel?	the travel agent gave us a 50-percent discount!
i have to hang up. i'm so sleepy.	it's not even 10 o'clock.
it's not even 10 o'clock.	i'm falling asleep on the phone.
i'm falling asleep on the phone.	you got up real early.
you got up real early.	i had to take my friend to the airport.
i had to take my friend to the airport.	why didn't you take a nap when you got home?
why didn't you take a nap when you got home?	i didn't get home until 30 minutes ago.
i didn't get home until 30 minutes ago.	why is that?
why is that?	there was a bomb threat at the airport.
there was a bomb threat at the airport.	only a threat?
only a threat?	yes, but i was stuck there all day while they looked for the bomb.
yes, but i was stuck there all day while they looked for the bomb.	someday the bomb is going to be for real.
my dad went to washington, d.c.	why did he do that?
why did he do that?	he was invited, along with about 90 other veterans.
he was invited, along with about 90 other veterans.	who invited them?
who invited them?	some private organization.
some private organization.	why did they invite him?
why did they invite him?	to thank him and all the other soldiers who served in world war ii.
to thank him and all the other soldiers who served in world war ii.	that's very nice.
that's very nice.	my dad got to see the beautiful new world war ii monument.
my dad got to see the beautiful new world war ii monument.	that trip must have cost a lot of money. 
that trip must have cost a lot of money. 	he said all the money came from private donations.
that was a great trip to washington, d.c.	tell me about it, dad.
tell me about it, dad.	about 90 of us world war ii veterans got on the plane at 8 a.m.
about 90 of us world war ii veterans got on the plane at 8 a.m.	how long was the flight?
how long was the flight?	it only took about two hours.
it only took about two hours.	did you take pictures at the world war ii monument?
did you take pictures at the world war ii monument?	oh, yes. we all took lots of pictures.
oh, yes. we all took lots of pictures.	then you flew back home that evening?
then you flew back home that evening?	yes. when we landed, tv reporters and the army band were there.
yes. when we landed, tv reporters and the army band were there.	that must have made you feel really special.
that must have made you feel really special.	oh, it did. there were about 300 people there to honor us.
oh, it did. there were about 300 people there to honor us.	well, you all deserve it. you helped save our country.
i need a job.	i thought you had a job.
i thought you had a job.	i did.
i did.	what happened?
what happened?	i got laid off.
i got laid off.	that's terrible! when did it happen?
that's terrible! when did it happen?	i got laid off last week.
i got laid off last week.	just you?
just you?	no, ten of my coworkers got laid off, too.
no, ten of my coworkers got laid off, too.	what are you going to do?
what are you going to do?	i'm looking in the newspaper for a job.
i'm looking in the newspaper for a job.	good luck!
before you go to that interview, check yourself.	what's to check?
what's to check?	are your nails clean?
are your nails clean?	yes, they are.
yes, they are.	did you double-check your nose and teeth?
did you double-check your nose and teeth?	they are clean, too.
they are clean, too.	did you shine your shoes?
did you shine your shoes?	my shoes are shined.
my shoes are shined.	do your socks match?
do your socks match?	of course they match.
of course they match.	no, they don't. one is black and one is dark blue.
no, they don't. one is black and one is dark blue.	yikes! thank you.
life is hard.	it sure is.
it sure is.	i thought school was hard.
i thought school was hard.	me, too. i couldn't wait to graduate.
me, too. i couldn't wait to graduate.	but now work is hard, too.
but now work is hard, too.	i agree. work is just as hard as school.
i agree. work is just as hard as school.	sometimes i wish i was back in school.
sometimes i wish i was back in school.	me, too. school was fun.
me, too. school was fun.	and it was only 12 years.
and it was only 12 years.	it went by pretty fast.
it went by pretty fast.	but work goes on forever!
but work goes on forever!	we have to work for 30 years!
i'm sleepy.	so am i.
so am i.	i had a long day.
i had a long day.	so did i.
so did i.	i didn't even have lunch.
i didn't even have lunch.	neither did i.
neither did i.	i was busy the whole day.
i was busy the whole day.	so was i.
so was i.	i had to bring work home with me.
i had to bring work home with me.	i did too.
i did too.	your day was just like mine.
your day was just like mine.	of course it was. we work together!
i don't like my job.	what do you do?
what do you do?	i'm a babysitter.
i'm a babysitter.	is that a lot of work?
is that a lot of work?	babies cry all the time.
babies cry all the time.	you have to change their diapers.
you have to change their diapers.	i have to feed them.
i have to feed them.	are you looking for another job?
are you looking for another job?	no, i'm looking for another family.
no, i'm looking for another family.	another family?
another family?	a family with only one baby.
a family with only one baby.	that's a good idea.
i need a job.	what was your last job?
what was your last job?	i was a painter.
i was a painter.	what happened?
what happened?	i got laid off because there was no work.
i got laid off because there was no work.	what else can you do?
what else can you do?	i'm a handyman.
i'm a handyman.	can you fix a dripping faucet in a kitchen sink?
can you fix a dripping faucet in a kitchen sink?	of course.
of course.	then i have a job for you in my kitchen.
then i have a job for you in my kitchen.	it will cost you only $20 plus parts.
it will cost you only $20 plus parts.	okay. that sounds like a fair price.
what would you do if you lost your job?	i have no idea. i've been here for 20 years.
i have no idea. i've been here for 20 years.	do you have any other skills?
do you have any other skills?	well, i know how to flip hamburgers.
well, i know how to flip hamburgers.	no one would hire you to flip hamburgers.
no one would hire you to flip hamburgers.	have you heard something that you're not telling me?
have you heard something that you're not telling me?	what do you mean?
what do you mean?	are there going to be layoffs at this place?
are there going to be layoffs at this place?	i certainly hope not!
i certainly hope not!	if you got laid off, you'd be flipping hamburgers, too.
if you got laid off, you'd be flipping hamburgers, too.	oh great, we could both work at burger king.
oh great, we could both work at burger king.	maybe we'd get laid off there, too.
do your students ever talk about their jobs?	yes, and they ask me what jobs are the best.
yes, and they ask me what jobs are the best.	i tell my students to become a teacher.
i tell my students to become a teacher.	teaching is a great job.
teaching is a great job.	it's the best job i've ever had.
it's the best job i've ever had.	what makes it so good?
what makes it so good?	for me, it's the students.
for me, it's the students.	what do you mean?
what do you mean?	i mean i have wonderful students.
i mean i have wonderful students.	that must be nice.
that must be nice.	teaching is the best part of my whole day.
teaching is the best part of my whole day.	you're a lucky man to have a job you love.
boy, i'm glad that job is finished.	how long did it take?
how long did it take?	four hours, without a break.
four hours, without a break.	it's always nice to finish a job.
it's always nice to finish a job.	well, it's good and bad.
well, it's good and bad.	what's bad about it?
what's bad about it?	when you finish, all you do is start another job!
when you finish, all you do is start another job!	yes, that's right. it does get boring.
yes, that's right. it does get boring.	especially if it's the same work, over and over.
especially if it's the same work, over and over.	but that's what most people do.
but that's what most people do.	yes, i guess most of us are stuck in a routine.
yes, i guess most of us are stuck in a routine.	i wonder if there is any job that you don't repeat over and over.
i think i have the worst boss in the world.	what makes him so bad?
what makes him so bad?	he's rude and he yells a lot.
he's rude and he yells a lot.	that's hard to take.
that's hard to take.	i've never heard him say please or thank you.
i've never heard him say please or thank you.	he sounds like a real jerk.
he sounds like a real jerk.	no one at work likes him.
no one at work likes him.	can't you report him to his supervisor?
can't you report him to his supervisor?	of course not. if i do that, i'll lose my job.
of course not. if i do that, i'll lose my job.	yes, they don't like troublemakers or complainers.
yes, they don't like troublemakers or complainers.	i can't quit, because i'm making a good salary.
i can't quit, because i'm making a good salary.	you shouldn't choose money over happiness.
what are we going to do?	about what?
about what?	about finding a job for me.
about finding a job for me.	you don't need a job. i make enough money for both of us.
you don't need a job. i make enough money for both of us.	that doesn't matter. i don't want to sit around.
that doesn't matter. i don't want to sit around.	okay, what kind of job do you want?
okay, what kind of job do you want?	i'm not sure.
i'm not sure.	well, you should do something that you enjoy.
well, you should do something that you enjoy.	i enjoy selling. i was born to sell.
i enjoy selling. i was born to sell.	okay, what do you want to sell?
okay, what do you want to sell?	cigarette lighters. i'll make a fortune.
cigarette lighters. i'll make a fortune.	but you hate cigarettes and you hate smoking!
a new hotel is looking for workers.	yes, i saw it on the tv news.
yes, i saw it on the tv news.	they need 300 new workers.
they need 300 new workers.	and 4,000 people showed up.
and 4,000 people showed up.	so many people are out of work.
so many people are out of work.	i still have my job, thank goodness.
i still have my job, thank goodness.	so do i, but i'm worried.
so do i, but i'm worried.	me too. there are no guarantees.
me too. there are no guarantees.	if you lose your job, you can move in with me.
if you lose your job, you can move in with me.	oh, thank you. that's very nice of you.
oh, thank you. that's very nice of you.	you would do the same for me.
you would do the same for me.	of course. what are friends for?
i think i did something real stupid.	what did you do?
what did you do?	i bought some stock.
i bought some stock.	everybody buys stock.
everybody buys stock.	i bought it on a hunch.
i bought it on a hunch.	you didn't read about the company first?
you didn't read about the company first?	i didn't have to. it's been in business for 60 years.
i didn't have to. it's been in business for 60 years.	so what's the problem?
so what's the problem?	i used all my savings on this one company.
i used all my savings on this one company.	you put all your eggs into one basket.
you put all your eggs into one basket.	if the company goes out of business, i'll have nothing.
if the company goes out of business, i'll have nothing.	oh, you'll have somethingyou'll have a lesson you'll never forget!
i was going to be a doctor.	what happened to your plans?
what happened to your plans?	i got a d in college chemistry.
i got a d in college chemistry.	well, a d is better than an f.
well, a d is better than an f.	a tutor helped me get the d!
a tutor helped me get the d!	so, you didn't become a doctor.
so, you didn't become a doctor.	and now i'm glad that i didn't.
and now i'm glad that i didn't.	why's that?
why's that?	a hospital is the most dangerous place in the world.
a hospital is the most dangerous place in the world.	oh, yes, because of all the killer germs.
oh, yes, because of all the killer germs.	if you're a smart doctor, you stay away from hospitals.
if you're a smart doctor, you stay away from hospitals.	yes, the smart doctors are those tv news doctorsno hospitals, no patients.
i want to be a mail carrier when i grow up.	why?
why?	because you get to meet a lot of people.
because you get to meet a lot of people.	you sure do.
you sure do.	and you get a lot of exercise every day.
and you get a lot of exercise every day.	that's the truth.
that's the truth.	and you get to play with a lot of dogs.
and you get to play with a lot of dogs.	well, you're supposed to be working.
well, you're supposed to be working.	yes, but i will always pet the friendly dogs.
yes, but i will always pet the friendly dogs.	what about the unfriendly dogs?
what about the unfriendly dogs?	i think if you are friendly to dogs, they are friendly to you.
i think if you are friendly to dogs, they are friendly to you.	dogs are like peoplenot all of them are friendly.
i want to move to new york.	to the state or the city?
to the state or the city?	to the city, of course.
to the city, of course.	why do you want to move there?
why do you want to move there?	because i want to make a lot of money.
because i want to make a lot of money.	there are a lot of poor people in new york.
there are a lot of poor people in new york.	there sure areat least a million.
there sure areat least a million.	so how do you plan to become rich?
so how do you plan to become rich?	i will knock on the doors of all the corporations.
i will knock on the doors of all the corporations.	that won't make you rich. nobody will talk to you.
that won't make you rich. nobody will talk to you.	i will keep knocking on doors.
i will keep knocking on doors.	all you will get is sore knuckles.
i love salads.	me too.
me too.	i usually eat a simple salad.
i usually eat a simple salad.	what do you put in it?
what do you put in it?	just lettuce, tomato, and celery.
just lettuce, tomato, and celery.	that's it?
that's it?	i add some pepper and salt.
i add some pepper and salt.	i always put cheese in my salads.
i always put cheese in my salads.	yes, cheese is nice.
yes, cheese is nice.	what kind of dressing do you use?
what kind of dressing do you use?	i pour lots of french dressing on top.
i pour lots of french dressing on top.	me too. french dressing is so delicious! who cares about calories?
i love cheese.	me too.
me too.	where does cheese come from?
where does cheese come from?	it comes from cows.
it comes from cows.	so we get cheese from cows, and we get milk, too?
so we get cheese from cows, and we get milk, too?	yes, we do.
yes, we do.	what else do we get from cows?
what else do we get from cows?	we get hamburgers and steak.
we get hamburgers and steak.	oh, that's so delicious.
oh, that's so delicious.	we also get leather.
we also get leather.	we get a lot of things from cows, don't we?
we get a lot of things from cows, don't we?	yes. a cow is man's best friend.
i used to work in a deli.	how did you like it?
how did you like it?	i loved it!
i loved it!	did you get free food?
did you get free food?	i ate free cheese and meat every day.
i ate free cheese and meat every day.	that sounds like a great job.
that sounds like a great job.	whatever a customer ordered, i sliced off a little more for me.
whatever a customer ordered, i sliced off a little more for me.	did you get fat?
did you get fat?	no, but i did put on a few pounds.
no, but i did put on a few pounds.	that sounds like a dream job.
that sounds like a dream job.	it was, until one day my manager caught me.
it was, until one day my manager caught me.	no more free cheese for you, huh?
i'm on a new diet.	what are you eating now?
what are you eating now?	i switched from pasta to potatoes.
i switched from pasta to potatoes.	why did you do that?
why did you do that?	pasta is processed food. potatoes are natural food.
pasta is processed food. potatoes are natural food.	natural food has more vitamins.
natural food has more vitamins.	and it's just as easy to prepare.
and it's just as easy to prepare.	how do you prepare the potatoes?
how do you prepare the potatoes?	i wash them, and then steam them for 15 minutes.
i wash them, and then steam them for 15 minutes.	that's pretty simple.
that's pretty simple.	then i add butter, salt, and pepper.
then i add butter, salt, and pepper.	can i have all those cans of tomato sauce you bought for your pasta?
my girlfriend's mom got mad at me at the dinner table.	why was that?
why was that?	i sprinkled salt and pepper on the food before i tasted it.
i sprinkled salt and pepper on the food before i tasted it.	what's the matter with that?
what's the matter with that?	her mom is a great cook.
her mom is a great cook.	so, a little salt and pepper never hurt anything.
so, a little salt and pepper never hurt anything.	it hurt her feelings.
it hurt her feelings.	oh.
oh.	i apologized to her, but i could tell she was still upset.
i apologized to her, but i could tell she was still upset.	maybe you shouldn't eat there again.
maybe you shouldn't eat there again.	i'm sure everything will be okay in a day or two.
i'm sure everything will be okay in a day or two.	it's your girlfriend's fault. she should have warned you.
i eat the same thing every day.	you're kidding.
you're kidding.	no, i'm serious.
no, i'm serious.	doesn't that get old?
doesn't that get old?	no, because i'm eating food that i like.
no, because i'm eating food that i like.	but the same thing day after day gets old.
but the same thing day after day gets old.	well, i guess if it ever does get old, i'll change to something different.
well, i guess if it ever does get old, i'll change to something different.	do you eat fruits and vegetables every day?
do you eat fruits and vegetables every day?	no, i hate vegetables.
no, i hate vegetables.	but you eat fruits.
but you eat fruits.	i eat two apples, one banana, and one orange every day.
i eat two apples, one banana, and one orange every day.	well, there's nothing wrong with that.
there's something wrong with my orange.	what's wrong?
what's wrong?	it's not orange!
it's not orange!	your orange isn't orange?
your orange isn't orange?	no, it's dark pink!
no, it's dark pink!	are you sure? i never heard of such a thing.
are you sure? i never heard of such a thing.	i just peeled it, and i'm looking at it right now.
i just peeled it, and i'm looking at it right now.	let me see. yes, you're right. your orange is pink.
let me see. yes, you're right. your orange is pink.	who ever heard of such a thing?
who ever heard of such a thing?	oh, look. here's the little sticker that was on it. it's called a pink navel.
oh, look. here's the little sticker that was on it. it's called a pink navel.	what is this world coming to?
what is this world coming to?	who knows? maybe soon we'll have pink bananas.
i love peanuts.	me, too. i love them roasted and salted.
me, too. i love them roasted and salted.	i love boiled peanuts.
i love boiled peanuts.	boiled? i never heard of that.
boiled? i never heard of that.	just boil raw peanuts in salt water until the shells are soft.
just boil raw peanuts in salt water until the shells are soft.	i'll have to try them sometime.
i'll have to try them sometime.	they're best when they're hot.
they're best when they're hot.	my brother is allergic to peanuts.
my brother is allergic to peanuts.	that's not good.
that's not good.	no, it isn't. he almost died when he was little.
no, it isn't. he almost died when he was little.	i guess he has to be very careful about what he eats.
i guess he has to be very careful about what he eats.	he has a very strict diet.
i'm gaining weight.	how much have you gained?
how much have you gained?	three pounds just this month.
three pounds just this month.	do you know why?
do you know why?	i think it's the ice cream.
i think it's the ice cream.	you started eating ice cream?
you started eating ice cream?	it was on sale.
it was on sale.	how much did you buy?
how much did you buy?	i filled up my freezer with ice cream.
i filled up my freezer with ice cream.	well, it won't last forever.
well, it won't last forever.	no, i figure i'll finish it all by next week.
no, i figure i'll finish it all by next week.	then you can start losing weight, if there isn't another sale.
i'm stuffed.	of course you are. you ate everything on the table.
of course you are. you ate everything on the table.	i don't like to eat leftovers.
i don't like to eat leftovers.	i'm glad to hear there's something you don't like to eat.
i'm glad to hear there's something you don't like to eat.	i like my food hot and fresh.
i like my food hot and fresh.	you like to see it disappear.
you like to see it disappear.	i don't like it reheated.
i don't like it reheated.	well, you'll have hot fresh food tomorrow night.
well, you'll have hot fresh food tomorrow night.	i'm so full i'm going to burst.
i'm so full i'm going to burst.	you should loosen your belt.
you should loosen your belt.	i already loosened my belt and unbuttoned my pants.
i already loosened my belt and unbuttoned my pants.	well, don't stand up, please.
i saw what you did.	i didn't do anything.
i didn't do anything.	oh yes, you did.
oh yes, you did.	what are you talking about?
what are you talking about?	you know what i'm talking about.
you know what i'm talking about.	i don't have any idea.
i don't have any idea.	you know what you did.
you know what you did.	maybe i know, but how could you know?
maybe i know, but how could you know?	because i was watching you.
because i was watching you.	okay, i'm sorry i did it.
okay, i'm sorry i did it.	don't drink milk out of the carton. use a glass!
don't drink milk out of the carton. use a glass!	i promise i'll never drink out of the carton again.
i like that shirt.	so do i.
so do i.	how much is it?
how much is it?	i don't know. the tag is missing.
i don't know. the tag is missing.	ask the clerk.
ask the clerk.	i will.
i will.	oh, look. here's another shirt just like it.
oh, look. here's another shirt just like it.	does it have a price tag?
does it have a price tag?	yes, it does. it's only $20.
yes, it does. it's only $20.	that's a great price.
that's a great price.	i think i'll buy both of them.
i think i'll buy both of them.	you'd better try them on first.
i bought you a pair of pants.	thank you.
thank you.	i hope they fit.
i hope they fit.	i hope you kept the receipt.
i hope you kept the receipt.	you think they won't fit?
you think they won't fit?	i think i've put on some weight.
i think i've put on some weight.	you think?
you think?	maybe a pound or two.
maybe a pound or two.	maybe four or five pounds?
maybe four or five pounds?	my waist is bigger than it was.
my waist is bigger than it was.	no problem. these pants have an elastic waistband.
no problem. these pants have an elastic waistband.	you are so smart!
what do we need to buy?	let me look at our list.
let me look at our list.	i know that we need milk.
i know that we need milk.	nonfat.
nonfat.	of course. what else?
of course. what else?	we need cheese, bread, and ham.
we need cheese, bread, and ham.	what kind of cheese?
what kind of cheese?	swiss.
swiss.	of course, the cheese with holes in it.
of course, the cheese with holes in it.	i never used to buy swiss cheese.
i never used to buy swiss cheese.	why not?
why not?	i didn't want to pay for the holes.
i need some pants.	i thought you just bought a pair.
i thought you just bought a pair.	i did.
i did.	what's wrong with them so soon?
what's wrong with them so soon?	the pants are fine, but the pocket has a huge hole in it.
the pants are fine, but the pocket has a huge hole in it.	you shouldn't carry your keys and pens in your pocket.
you shouldn't carry your keys and pens in your pocket.	but that's what pockets are for.
but that's what pockets are for.	you should carry them in a purse.
you should carry them in a purse.	i'm a man, and men don't carry purses!
i'm a man, and men don't carry purses!	well, you should buy pants with stronger pockets.
well, you should buy pants with stronger pockets.	i would if i could find someone who makes strong pockets.
i would if i could find someone who makes strong pockets.	try a google search online.
what are those wipes for?	you use them to wipe the handle of the shopping cart.
you use them to wipe the handle of the shopping cart.	that's a great idea.
that's a great idea.	yes, all the markets just started offering wipes to shoppers.
yes, all the markets just started offering wipes to shoppers.	i'm going to take five wipes.
i'm going to take five wipes.	what do you need five of them for?
what do you need five of them for?	one to wipe the handle, and the others to wipe the produce.
one to wipe the handle, and the others to wipe the produce.	what's the matter with the produce?
what's the matter with the produce?	do you think the bananas fell from the sky?
do you think the bananas fell from the sky?	what do you mean?
what do you mean?	i mean, someone used their dirty hands to pick the bananas, the apples, and the oranges.
i mean, someone used their dirty hands to pick the bananas, the apples, and the oranges.	well, you better save a wipe for the dirty dollar bills you're going to pay with.
did you go to the 99 cents store?	yes, i did.
yes, i did.	what did you buy?
what did you buy?	well, i got a lot of good deals, as usual.
well, i got a lot of good deals, as usual.	like what?
like what?	well, a dozen large eggs were only 99 cents.
well, a dozen large eggs were only 99 cents.	that's a good deal.
that's a good deal.	and a one-pound tub of soft butter was the same price.
and a one-pound tub of soft butter was the same price.	another good deal.
another good deal.	but the best deal was five pounds of potatoes for 99 cents.
but the best deal was five pounds of potatoes for 99 cents.	i don't know how that store makes money.
i don't know how that store makes money.	neither do i, but they're doing something right.
i need a new computer.	what's the matter with yours?
what's the matter with yours?	it's six years old.
it's six years old.	that's pretty old.
that's pretty old.	it still works, but i'm going to give it to a charity.
it still works, but i'm going to give it to a charity.	are you going to buy a desktop or laptop?
are you going to buy a desktop or laptop?	oh, a laptop, of course.
oh, a laptop, of course.	a pc or a mac?
a pc or a mac?	i haven't decided yet.
i haven't decided yet.	more and more people are using macs.
more and more people are using macs.	but 90 percent of the world uses pcs.
but 90 percent of the world uses pcs.	and that's not going to change anytime soon.
i got ripped off.	what happened?
what happened?	i had a car problem, so i went online.
i had a car problem, so i went online.	did you find a solution?
did you find a solution?	yes, i did. a site i went to said they would send me the solution.
yes, i did. a site i went to said they would send me the solution.	so, what's the problem?
so, what's the problem?	i sent them $20 using my credit card, but they never sent me the solution.
i sent them $20 using my credit card, but they never sent me the solution.	what are you going to do?
what are you going to do?	i sent them an email asking for my money back.
i sent them an email asking for my money back.	have you heard from them?
have you heard from them?	not yet. it's been a week.
not yet. it's been a week.	well, i guess that's a $20 lesson for you.
where's the pencil sharpener?	which one?
which one?	any one. i need to sharpen this pencil.
any one. i need to sharpen this pencil.	i think there's one on the dining room table.
i think there's one on the dining room table.	i already looked there.
i already looked there.	did you look in the desk drawer?
did you look in the desk drawer?	yes, i looked there, too.
yes, i looked there, too.	don't we have about five sharpeners?
don't we have about five sharpeners?	yes, but they seem to have legs.
yes, but they seem to have legs.	tomorrow i'm going to buy an electric sharpener.
tomorrow i'm going to buy an electric sharpener.	get one with the rubber suction cups on the bottom.
get one with the rubber suction cups on the bottom.	yes. that way it will stay where i put it.
i'm trying to stretch my dollars.	how are you doing that?
how are you doing that?	i started shopping at the dollar store.
i started shopping at the dollar store.	that saves a lot of money.
that saves a lot of money.	i bought three pounds of potatoes for a dollar.
i bought three pounds of potatoes for a dollar.	that's a good deal.
that's a good deal.	yes, even though some of the potatoes had eyes.
yes, even though some of the potatoes had eyes.	just put them in the fridge.
just put them in the fridge.	also, i bought a can of cheap coffee and a bag of good coffee.
also, i bought a can of cheap coffee and a bag of good coffee.	why did you do that?
why did you do that?	i mixed them together.
i mixed them together.	if the coffee still tastes okay, that's a good idea.
i really like this house.	can we afford it?
can we afford it?	they want 20 percent down.
they want 20 percent down.	that's a lot of money.
that's a lot of money.	but the house is so nice.
but the house is so nice.	it's in a great neighborhood.
it's in a great neighborhood.	it's close to the beach.
it's close to the beach.	it's close to the freeways.
it's close to the freeways.	it's got a big yard.
it's got a big yard.	the kids love the house, too.
the kids love the house, too.	if we don't buy it, someone else will.
if we don't buy it, someone else will.	you're right. let's buy it now. we can worry later.
we can't afford this house.	are you sure?
are you sure?	we will be house rich, but cash poor.
we will be house rich, but cash poor.	what do you mean?
what do you mean?	our monthly payments will be too high.
our monthly payments will be too high.	we won't have any money for other things?
we won't have any money for other things?	no, we won't have money for gas or food.
no, we won't have money for gas or food.	we'll be eating peanut butter sandwiches?
we'll be eating peanut butter sandwiches?	without the peanut butter!
without the peanut butter!	that's no good!
that's no good!	we have to find a cheaper house.
we have to find a cheaper house.	of course. we can't live without gas or peanut butter.
that is a beautiful house.	i don't like it.
i don't like it.	what's the matter with it?
what's the matter with it?	it's on the corner.
it's on the corner.	so?
so?	that means it gets twice as much traffic.
that means it gets twice as much traffic.	you're right.
you're right.	when you're inside, you will always hear cars stopping and stopping at the intersection.
when you're inside, you will always hear cars stopping and stopping at the intersection.	or you'll hear the collision if someone doesn't stop.
or you'll hear the collision if someone doesn't stop.	or you'll see the collision if they crash into the house.
or you'll see the collision if they crash into the house.	let's find a house that's at the end of a dead end.
let's find a house that's at the end of a dead end.	that's perfect. the less traffic, the better.
i hate looking for an apartment.	me, too.
me, too.	we have a 2 o'clock appointment to see the one on main street.
we have a 2 o'clock appointment to see the one on main street.	we'd better get ready to go.
we'd better get ready to go.	it's an upstairs unit.
it's an upstairs unit.	that's good, because i don't want to live under people with loud feet.
that's good, because i don't want to live under people with loud feet.	and it's a corner unit.
and it's a corner unit.	that's great. we won't have neighbors on both sides of us.
that's great. we won't have neighbors on both sides of us.	no pets are allowed.
no pets are allowed.	perfect. we don't have to listen to barking dogs.
perfect. we don't have to listen to barking dogs.	and there are only six units in the whole building.
and there are only six units in the whole building.	where's the checkbook? i'm ready to rent it without even seeing it.
did you call the manager?	yes. he said he'd come over tomorrow.
yes. he said he'd come over tomorrow.	did he say what time?
did he say what time?	yes. he said he'd be here at 9 o'clock.
yes. he said he'd be here at 9 o'clock.	did he understand what the problem is?
did he understand what the problem is?	yes. i told him our doorbell doesn't work.
yes. i told him our doorbell doesn't work.	it shouldn't take him long to fix it.
it shouldn't take him long to fix it.	i don't even know why we need to fix it.
i don't even know why we need to fix it.	in case we have visitors.
in case we have visitors.	but they can just knock on the door.
but they can just knock on the door.	actually, i want him to look at our carpet, too.
actually, i want him to look at our carpet, too.	yes, it would be nice if he'd give us a new carpet.
do you like this house?	yes, it's beautiful.
yes, it's beautiful.	it's perfect for us and the kids.
it's perfect for us and the kids.	three bedrooms, three bathrooms, and a big back yard.
three bedrooms, three bathrooms, and a big back yard.	and we can afford it!
and we can afford it!	so are we going to buy it?
so are we going to buy it?	i'm afraid not.
i'm afraid not.	it's too far from your job, isn't it?
it's too far from your job, isn't it?	i can't spend four hours on the road every day.
i can't spend four hours on the road every day.	by the time you get home, you'll be too tired to even eat.
by the time you get home, you'll be too tired to even eat.	i won't be able to play with the kids.
i won't be able to play with the kids.	no, we have to find something closer to your job.
boy, it's chilly outside, isn't it?	it sure is.
it sure is.	in fact, it's chilly in the apartment, too.
in fact, it's chilly in the apartment, too.	let's turn on the heat.
let's turn on the heat.	i'll check to make sure that all the windows are shut.
i'll check to make sure that all the windows are shut.	it should be warmer in a few minutes.
it should be warmer in a few minutes.	it's so nice to have a heated apartment.
it's so nice to have a heated apartment.	how did they survive in the old days?
how did they survive in the old days?	they had fireplaces.
they had fireplaces.	someone had to chop the wood.
someone had to chop the wood.	and carry it into the house.
and carry it into the house.	all we have to do is flip a switch.
this is a nice neighborhood.	the streets are clean and quiet.
the streets are clean and quiet.	the neighbors don't party on the weekends.
the neighbors don't party on the weekends.	people take care of their lawns.
people take care of their lawns.	no rusty old cars are sitting in the front yards.
no rusty old cars are sitting in the front yards.	we never have to call the police about anything.
we never have to call the police about anything.	our kids are completely safe.
our kids are completely safe.	so why are we selling our house?
so why are we selling our house?	they're building a 3-story apartment building on the corner.
they're building a 3-story apartment building on the corner.	so we've got to sell before property values go down?
so we've got to sell before property values go down?	yes. i still can't believe our city council allowed this building.
yes. i still can't believe our city council allowed this building.	they're probably getting something under the table.
that was a huge fire in santa barbara.	yes, it was.
yes, it was.	they said about 30 houses burned to the ground.
they said about 30 houses burned to the ground.	and they were expensive houses.
and they were expensive houses.	i feel so sorry for those people.
i feel so sorry for those people.	why feel sorry for rich people?
why feel sorry for rich people?	i feel sorry for anyone who loses their home.
i feel sorry for anyone who loses their home.	so do i, but not if they're rich.
so do i, but not if they're rich.	what does that have to do with it?
what does that have to do with it?	rich people think they're better than us.
rich people think they're better than us.	how many rich people do you know?
how many rich people do you know?	none.
bears are invading our neighborhoods.	of course they are. they're starving to death.
of course they are. they're starving to death.	they should stay in the woods where they belong.
they should stay in the woods where they belong.	there's no food in the woods.
there's no food in the woods.	can't they eat grass?
can't they eat grass?	do you think a bear is a cow?
do you think a bear is a cow?	well, i've seen them eating berries.
well, i've seen them eating berries.	berries aren't in season all year round.
berries aren't in season all year round.	it's too dangerous for kids and pets.
it's too dangerous for kids and pets.	people need to cover their trash cans.
people need to cover their trash cans.	the police need to shoot all the bears.
the police need to shoot all the bears.	you don't solve a problem by shooting it.
who did you vote for?	i voted for obama.
i voted for obama.	me too.
me too.	he will be a great president.
he will be a great president.	everyone likes him.
everyone likes him.	he's a good speaker.
he's a good speaker.	and he's really smart.
and he's really smart.	he will solve our problems.
he will solve our problems.	he will end the war.
he will end the war.	the next four years will be good years.
the next four years will be good years.	i'll vote for him next time, too.
i'll vote for him next time, too.	i think everyone will.
the election is next week.	who are you voting for?
who are you voting for?	i'm not voting for the mayor.
i'm not voting for the mayor.	why not?
why not?	he made promises that he didn't keep.
he made promises that he didn't keep.	like what?
like what?	he promised to hire 1,000 more police officers.
he promised to hire 1,000 more police officers.	how many did he hire?
how many did he hire?	one hundred!
one hundred!	maybe he had a good reason.
maybe he had a good reason.	maybe he's just a liar.
maybe he's just a liar.	maybe i'll vote for someone else, too.
i can't believe he won the election.	only 15 percent of the voters turned out.
only 15 percent of the voters turned out.	that is a joke.
that is a joke.	voting is so important, but people don't bother.
voting is so important, but people don't bother.	many people think their vote doesn't matter.
many people think their vote doesn't matter.	the mayor won by only 2,000 votes.
the mayor won by only 2,000 votes.	we're stuck with him for four more years.
we're stuck with him for four more years.	voting is so easy. you can even mail your ballot in.
voting is so easy. you can even mail your ballot in.	all you have to do is vote and put a stamp on it.
all you have to do is vote and put a stamp on it.	how easy is that?
how easy is that?	i guess people just don't care.
i guess people just don't care.	they'll care when they see their taxes go up.
well, we have a new president.	but we have the same old problems.
but we have the same old problems.	well, he's made a few changes.
well, he's made a few changes.	like what?
like what?	i think he closed the bowling alley in the white house.
i think he closed the bowling alley in the white house.	oh, yeah. he's changing it to a basketball court.
oh, yeah. he's changing it to a basketball court.	who's paying for that?
who's paying for that?	i think we are!
i think we are!	well, that's okay, as long as it helps him relax and think more clearly.
well, that's okay, as long as it helps him relax and think more clearly.	yes, we need a relaxed president who thinks clearly.
yes, we need a relaxed president who thinks clearly.	do any other world leaders have a basketball court?
do any other world leaders have a basketball court?	they will. you know america always leads the way.
people say that everybody loves obama.	well, more than 50 million people voted for mccain.
well, more than 50 million people voted for mccain.	that's 50 million people who don't love obama.
that's 50 million people who don't love obama.	obama's got four years to make everyone happy.
obama's got four years to make everyone happy.	he's never going to make everyone happy.
he's never going to make everyone happy.	can you imagine being president?
can you imagine being president?	everyone wants you to solve their problems.
everyone wants you to solve their problems.	i have enough stress from trying to solve my own problems.
i have enough stress from trying to solve my own problems.	you and everybody else.
you and everybody else.	i would never want to be president.
i would never want to be president.	but think about all the power you'd have.
but think about all the power you'd have.	i prefer my quiet little life to all the power in the world.
did you read this article?	what article?
what article?	it says the mayor spends only 11 percent of his time on city duties.
it says the mayor spends only 11 percent of his time on city duties.	only 11 percent?
only 11 percent?	about 50 percent of the time he's traveling.
about 50 percent of the time he's traveling.	where does he travel to?
where does he travel to?	oh, all over the world.
oh, all over the world.	but he's supposed to be making our city a better place.
but he's supposed to be making our city a better place.	he's visiting other cities to get ideas.
he's visiting other cities to get ideas.	can't he just go online?
can't he just go online?	the rest of the time he's raising money for his reelection.
the rest of the time he's raising money for his reelection.	well, he'll never get reelected once this news gets out.
who did you vote for for president?	i voted for ralph nader.
i voted for ralph nader.	who in the world is ralph nader?
who in the world is ralph nader?	he's the best man for president.
he's the best man for president.	why's that?
why's that?	he hates corporations.
he hates corporations.	well, most corporations do think only about money.
well, most corporations do think only about money.	he hates democrats and republicans.
he hates democrats and republicans.	well, they do put their party before their country.
well, they do put their party before their country.	he's the only candidate that i trust.
he's the only candidate that i trust.	but he didn't have a chance. nobody voted for him!
but he didn't have a chance. nobody voted for him!	sooner or later, voters will wake up.
i don't know why i bother to vote.	why's that?
why's that?	what good does it do?
what good does it do?	you get to put someone in power that you like.
you get to put someone in power that you like.	only if my candidate wins.
only if my candidate wins.	well, he can't win unless you and others vote for him.
well, he can't win unless you and others vote for him.	but even if my candidate wins, he'll break his promises.
but even if my candidate wins, he'll break his promises.	that's true. they promise anything just so they get elected.
that's true. they promise anything just so they get elected.	and when elected, they go their own way.
and when elected, they go their own way.	they forget who put them in power.
they forget who put them in power.	they forget where they came from.
they forget where they came from.	maybe you should run for office.
that election for u.s. senator stunk.	what do you mean?
what do you mean?	there were more votes than voters!
there were more votes than voters!	but that's impossible.
but that's impossible.	officials said that it's possible.
officials said that it's possible.	did they explain how it's possible?
did they explain how it's possible?	no. they said there are some things you can't explain.
no. they said there are some things you can't explain.	so are they going to hold another election?
so are they going to hold another election?	no. that will cost too much money.
no. that will cost too much money.	so it's better to save money than to have an honest election?
so it's better to save money than to have an honest election?	well, the democratic party says it was an honest election.
well, the democratic party says it was an honest election.	of course they say thattheir man won!
i see that former president bush is at a conference.	yes. he's telling jokes about his eight years as president.
yes. he's telling jokes about his eight years as president.	yes, those eight years were a lot of fun for everyone.
yes, those eight years were a lot of fun for everyone.	only 4,000 american soldiers were killed overseas.
only 4,000 american soldiers were killed overseas.	not to mention 40,000 wounded soldiers.
not to mention 40,000 wounded soldiers.	but bush visited some of them in the hospital once.
but bush visited some of them in the hospital once.	that's nice that he found the time to make a visit.
that's nice that he found the time to make a visit.	he spoke to them and made them feel better.
he spoke to them and made them feel better.	did he speak to every family that lost a soldier?
did he speak to every family that lost a soldier?	no, he didn't have time to do that.
no, he didn't have time to do that.	well, he's got plenty of time now!
well, he's got plenty of time now!	no, he's too busy writing a book about how hard it was to be president.
did you get your official sample ballot?	yes, with the voter instructions.
yes, with the voter instructions.	how are you going to vote?
how are you going to vote?	same as ever, by mail. all it costs me is a 42-cent stamp.
same as ever, by mail. all it costs me is a 42-cent stamp.	i meant, are you going to vote for or against the new taxes?
i meant, are you going to vote for or against the new taxes?	against all of them, of course.
against all of them, of course.	but we need new taxes to pay for highways, schools, and prisons.
but we need new taxes to pay for highways, schools, and prisons.	we've already voted for new taxes to pay for all that stuff!
we've already voted for new taxes to pay for all that stuff!	that's true. where did that money go?
that's true. where did that money go?	our legislators spent it on first-class travel all over the world.
our legislators spent it on first-class travel all over the world.	they are having a good time with our money.
they are having a good time with our money.	so when are we going to stop giving them more?
have you decided how you are going to vote?	do you mean on measures 1, 2, and 3?
do you mean on measures 1, 2, and 3?	yes. the ones that will improve our schools, roads, and hospitals.
yes. the ones that will improve our schools, roads, and hospitals.	you mean the measures that will raise our taxes.
you mean the measures that will raise our taxes.	but the tv ads say that our taxes will not increase.
but the tv ads say that our taxes will not increase.	do you believe the tv ads?
do you believe the tv ads?	i like the one where the fireman tells us why we should vote yes.
i like the one where the fireman tells us why we should vote yes.	don't believe him! whatever the tv ads tell you, the opposite is true.
don't believe him! whatever the tv ads tell you, the opposite is true.	but the title of measure 1 is "better schools at no cost."
but the title of measure 1 is "better schools at no cost."	the title should be "better schools at huge cost."
the title should be "better schools at huge cost."	i can't believe that they would lie to us.
i can't believe that they would lie to us.	of course they liethat's what politicians do!
i have a stomachache.	is it something you ate?
is it something you ate?	maybe. i'm not sure.
maybe. i'm not sure.	what did you have for breakfast?
what did you have for breakfast?	the usual, cereal with milk and a banana.
the usual, cereal with milk and a banana.	maybe the milk was bad.
maybe the milk was bad.	it didn't smell bad.
it didn't smell bad.	maybe the banana was bad.
maybe the banana was bad.	no, the banana was delicious.
no, the banana was delicious.	maybe you just need to go to the bathroom.
maybe you just need to go to the bathroom.	no, that's not the problem.
no, that's not the problem.	maybe it will go away in a little while.
what's this stain?	i don't know.
i don't know.	it looks like blood.
it looks like blood.	i think my nose was bleeding.
i think my nose was bleeding.	you should wet your shirt immediately.
you should wet your shirt immediately.	why?
why?	because that gets the blood out of the shirt.
because that gets the blood out of the shirt.	what's a little blood?
what's a little blood?	your white shirt is ruined.
your white shirt is ruined.	so, i'll just buy another one.
so, i'll just buy another one.	you can wear this one around the house.
you can wear this one around the house.	next time i'll soak it immediately.
my fingers hurt.	why do they hurt?
why do they hurt?	i type too much.
i type too much.	you should take a break.
you should take a break.	i need to type to make money.
i need to type to make money.	but typing is causing you pain.
but typing is causing you pain.	maybe i should see a doctor.
maybe i should see a doctor.	doctors are too expensive.
doctors are too expensive.	he might tell me to rest for a while.
he might tell me to rest for a while.	he might want to cut you open.
he might want to cut you open.	he might say i'm okay.
he might say i'm okay.	he might say you have bone cancer.
what did the doctor say?	he thinks i have too much stress.
he thinks i have too much stress.	stress causes your stomachaches?
stress causes your stomachaches?	stress causes different problems with different people.
stress causes different problems with different people.	so what did he tell you to do?
so what did he tell you to do?	he said i need to think positive.
he said i need to think positive.	he didn't give you any medication?
he didn't give you any medication?	i hate medication. it makes me feel different.
i hate medication. it makes me feel different.	so how do you think positive?
so how do you think positive?	i think about nice things.
i think about nice things.	like what?
like what?	like a day at the beach, with my toes in the sand.
i cut my finger.	how did you do that?
how did you do that?	it's a paper cut.
it's a paper cut.	paper can be dangerous.
paper can be dangerous.	it hurts, too.
it hurts, too.	paper cuts can hurt a lot.
paper cuts can hurt a lot.	where are the band-aids?
where are the band-aids?	i think they're in the medicine cabinet.
i think they're in the medicine cabinet.	it's on the tip of my finger.
it's on the tip of my finger.	a band-aid might not work.
a band-aid might not work.	i must not use this finger until the cut heals.
i must not use this finger until the cut heals.	it might take a day or two to heal.
do you smell that?	oh, yes.
oh, yes.	i can't stand cigarette smoke.
i can't stand cigarette smoke.	it smells so bad.
it smells so bad.	one cigarette stinks up the whole sidewalk.
one cigarette stinks up the whole sidewalk.	smokers think they are so cool.
smokers think they are so cool.	they are so weak.
they are so weak.	a little cigarette controls them.
a little cigarette controls them.	they look so stupid taking a puff.
they look so stupid taking a puff.	and then they blow smoke out of their mouth.
and then they blow smoke out of their mouth.	they think it's cool.
they think it's cool.	cigarettes stink.
do you have a cold?	yes, i do.
yes, i do.	how did you get it?
how did you get it?	my sister had a cold. she gave it to me.
my sister had a cold. she gave it to me.	have you taken anything for your cold?
have you taken anything for your cold?	no, i just blow my nose a lot.
no, i just blow my nose a lot.	your nose is stopped up?
your nose is stopped up?	yes. i have to breathe through my mouth.
yes. i have to breathe through my mouth.	have you tried nose drops?
have you tried nose drops?	no, i don't like nose drops.
no, i don't like nose drops.	they work great.
they work great.	i don't care. i don't like to put drops in my nose.
would you put suntan lotion on my back, please?	sure.
sure.	thank you.
thank you.	you shouldn't lie in the sun for too long.
you shouldn't lie in the sun for too long.	i want to get a tan. i don't want to look so pale.
i want to get a tan. i don't want to look so pale.	what's wrong with looking pale?
what's wrong with looking pale?	people think you might be sick.
people think you might be sick.	who thinks that?
who thinks that?	i don't know.
i don't know.	it's better to be pale than to have skin cancer.
it's better to be pale than to have skin cancer.	i know that.
i know that.	so why are you arguing with me? don't lie in the sun too long!
i can't quit smoking.	of course you can.
of course you can.	i don't have enough will power.
i don't have enough will power.	of course you do.
of course you do.	i wish i had never started.
i wish i had never started.	so does every smoker.
so does every smoker.	i've tried to quit so many times.
i've tried to quit so many times.	so has everyone else.
so has everyone else.	nothing seems to work.
nothing seems to work.	all it takes is will power, and you have it.
all it takes is will power, and you have it.	then why can't i quit?
then why can't i quit?	you have to believe in yourself.
my back is killing me.	what did you do?
what did you do?	i got out of my car.
i got out of my car.	that's it?
that's it?	i injured my back one time just by sneezing.
i injured my back one time just by sneezing.	you should see a doctor.
you should see a doctor.	my doctor said i need surgery.
my doctor said i need surgery.	so?
so?	so, forget it.
so, forget it.	you don't have the money?
you don't have the money?	i have no insurance.
i have no insurance.	maybe a back rub would help.
my brother smokes three packs a day.	three packs of what?
three packs of what?	cigarettes, of course.
cigarettes, of course.	how can he do that?
how can he do that?	when he is almost finished with one cigarette, he uses it to light another.
when he is almost finished with one cigarette, he uses it to light another.	he's a chain smoker.
he's a chain smoker.	he's been a chain smoker for 30 years.
he's been a chain smoker for 30 years.	that's unbelievable. can he still breathe?
that's unbelievable. can he still breathe?	he can, but the people around him can't.
he can, but the people around him can't.	how can he still be alive?
how can he still be alive?	his doctor says his heart and lungs are strong and healthy.
his doctor says his heart and lungs are strong and healthy.	maybe i should start smoking.
i hate brushing my teeth.	it's such a chore.
it's such a chore.	brush, brush. spit, spit.
brush, brush. spit, spit.	what did they do in the old days?
what did they do in the old days?	they brushed with their fingers.
they brushed with their fingers.	they also ate with their fingers!
they also ate with their fingers!	why do they call it the good old days?
why do they call it the good old days?	maybe because they didn't have to brush and floss.
maybe because they didn't have to brush and floss.	who invented flossing?
who invented flossing?	a dentist, i'm sure.
a dentist, i'm sure.	i hate flossing more than brushing!
i hate flossing more than brushing!	i can't wait till all my teeth fall out.
let's stop for a while. i need a break and some water.	this trail is hard to climb.
this trail is hard to climb.	especially on a hot day like this.
especially on a hot day like this.	i can't believe we haven't seen any animals.
i can't believe we haven't seen any animals.	thank goodness! i don't want to see any wild animals.
thank goodness! i don't want to see any wild animals.	all we've seen so far is a couple of lizards.
all we've seen so far is a couple of lizards.	we're hiking to lose weight, not to see goats and bears.
we're hiking to lose weight, not to see goats and bears.	i bet i've lost a couple of pounds already.
i bet i've lost a couple of pounds already.	all you've lost is some sweat.
all you've lost is some sweat.	i haven't even lost one pound of fat?
i haven't even lost one pound of fat?	if you want to lose fat, you've got to do this hike every day.
if you want to lose fat, you've got to do this hike every day.	okay, but let's hike in town. at least there are cats and dogs to see.
oh no, another pimple on my face.	pimples suck.
pimples suck.	it seems like i get a new pimple almost every day.
it seems like i get a new pimple almost every day.	maybe it's something in your diet.
maybe it's something in your diet.	no, i eat the same things day after day.
no, i eat the same things day after day.	then maybe it's in your genes.
then maybe it's in your genes.	you might be right.
you might be right.	do pimples run in your family?
do pimples run in your family?	not that i've noticed.
not that i've noticed.	well, maybe it's from the pollution in the air.
well, maybe it's from the pollution in the air.	whatever the cause, i hate seeing them on my face.
whatever the cause, i hate seeing them on my face.	well, on the bright side, they're fun to pop.
do you believe everything you hear?	i don't believe anything i don't see with my own eyes.
i don't believe anything i don't see with my own eyes.	you can't believe what you hear on tv or radio.
you can't believe what you hear on tv or radio.	you can't believe what you read in the newspapers.
you can't believe what you read in the newspapers.	everyone tells you a different story about the same thing.
everyone tells you a different story about the same thing.	three different people will give you three different stories.
three different people will give you three different stories.	and the government will give you a fourth story.
and the government will give you a fourth story.	yes, like the government says not to worry about the swine flu.
yes, like the government says not to worry about the swine flu.	but the swine flu just killed 20 people in mexico.
but the swine flu just killed 20 people in mexico.	the government says we have nothing to worry about.
the government says we have nothing to worry about.	then why are some schools telling the kids to stay home?
then why are some schools telling the kids to stay home?	the government says to wash our hands frequently, and we'll all be okay.
don't pick your nose.	i wasn't picking my nose.
i wasn't picking my nose.	what were you doing?
what were you doing?	i was scratching my nose.
i was scratching my nose.	i think i know the difference between picking and scratching.
i think i know the difference between picking and scratching.	okay, mom, maybe i was picking it a little bit.
okay, mom, maybe i was picking it a little bit.	use a tissue next time.
use a tissue next time.	i didn't have a tissue.
i didn't have a tissue.	then wait till you find a tissue.
then wait till you find a tissue.	i couldn't wait. it was an emergency.
i couldn't wait. it was an emergency.	oh, really? maybe you should have called 911.
oh, really? maybe you should have called 911.	it wasn't that kind of emergency.
our tv remote is filthy.	yes, it's covered with crud.
yes, it's covered with crud.	i'm going to clean it.
i'm going to clean it.	don't use water on it!
don't use water on it!	i'll use a damp cloth.
i'll use a damp cloth.	don't let water get into any of the cracks.
don't let water get into any of the cracks.	i'll squeeze the cloth so it's almost dry.
i'll squeeze the cloth so it's almost dry.	don't rub the numbers off the remote.
don't rub the numbers off the remote.	i will rub gently but firmly.
i will rub gently but firmly.	do it quickly, please, so i can change channels during commercials.
do it quickly, please, so i can change channels during commercials.	i'll give it back to you in a couple of minutes.
i'll give it back to you in a couple of minutes.	maybe we should put it in a plastic bag to keep it clean.
my ear is killing me.	what's the matter?
what's the matter?	i was on a plane.
i was on a plane.	so?
so?	so, every time the plane goes up, my ear starts to hurt.
so, every time the plane goes up, my ear starts to hurt.	that's no good.
that's no good.	sometimes the pain goes away, and sometimes it doesn't.
sometimes the pain goes away, and sometimes it doesn't.	have you seen a doctor?
have you seen a doctor?	i've been to two doctors.
i've been to two doctors.	and they couldn't fix your problem?
and they couldn't fix your problem?	they both said i have to live with it.
they both said i have to live with it.	or you can stay off planes.
did you see the woman with the new face?	did she get a nice job?
did she get a nice job?	she got an "everything" job!
she got an "everything" job!	what do you mean?
what do you mean?	a team of doctors gave her a whole new face.
a team of doctors gave her a whole new face.	why did they do that?
why did they do that?	a mad dog bit most of her face off.
a mad dog bit most of her face off.	oh, that's terrible. what does she look like now?
oh, that's terrible. what does she look like now?	her face is really fat, but they say the swelling will go down.
her face is really fat, but they say the swelling will go down.	and then will she look normal again?
and then will she look normal again?	i guess so.
i guess so.	god bless modern medicine.
there's something wrong with my right hand.	what's wrong with it?
what's wrong with it?	it aches most of the time.
it aches most of the time.	what do you think it is?
what do you think it is?	i don't know. i think it's old age.
i don't know. i think it's old age.	if it's old age, why don't both of your hands hurt?
if it's old age, why don't both of your hands hurt?	that's a good question. maybe it's not old age.
that's a good question. maybe it's not old age.	are you right-handed?
are you right-handed?	yes. all my life.
yes. all my life.	you're wearing out your right hand. stop using it so much.
you're wearing out your right hand. stop using it so much.	but i do all my writing with my right hand.
but i do all my writing with my right hand.	start typing instead. that way your left hand will do half the work.
"""




for i in a.split("\n"):
    print(i)
    with open('datas.txt','a') as fs:
        data = i.split("\t")
        fs.write(str(data)+",")